// invoked in master

/**
 * 通用脚本库
 * @马少博 (1030809514@qq.com)
 * @date    2016-12-09 16:26:17
 * @version 1.0
 */

$(function () {

    //$(".start_end_time").datetimepicker();
    /// <summary>悬浮于一级菜单时显示二级菜单的内容</summary>
    $("#mainMenu>li>a").each(function (index) {
    $(this).hover(function () {
        var position = $(this).offset();
        var selector = $(this).attr("data-SecondMenu");
        var marginleft = position.left - $(selector).find("li").size() * 45 + 45;
        $("#mainMenu>li").removeClass("active");
        $(this).parent().addClass("active");
        $(selector).toggleClass("active").css("padding-left", marginleft + 'px');
    }); 
    }); 

}); 

$(function ()
{
    /// <summary>表格排序功能</summary>

    var isdesc = false;//定义一个全局变量，用来确定升序还是降序
    $("[data-type]").click(function ()
    {
        //  点击列表的表头进行排序，图标操作部分start
        $(this).find("span").addClass("glyphicon").end().siblings("th").find("span").removeClass();

        //添加正序或倒序图标
        if (isdesc) {
            isdesc = false;
            $(this).find("span").removeClass("glyphicon-chevron-up").addClass("glyphicon-chevron-down").attr("title", "降序");
        } else {
            isdesc = true;
            $(this).find("span").removeClass("glyphicon-chevron-down").addClass("glyphicon-chevron-up").attr("title", "升序");
        }
        //图标操作部分 end

        //当前TH的行数以及列数序号
        var trlength = $(".fixed-table-container tr").length - 1,
               colunindex = $(this).index();
        //获取需要进行比对的数据行
        var tablearr = $.makeArray($("tbody tr:lt(" + trlength + ")"));

        //排序规则三种：1、时间；2、字符串；3、数字
        if ($(this).attr("data-type") === "time")
        {//时间类型值排序操作
            tablearr.sort(function (a, b)
            {
                return isdesc ? timescompare($(a).find('td').eq(colunindex).text(), $(b).find('td').eq(colunindex).text()) : timescompare($(b).find('td').eq(colunindex).text(), $(a).find('td').eq(colunindex).text());
            });
        }

        else if ($(this).attr("data-type") === "str")
        {//字符串类型值排序操作
            tablearr.sort(function (a, b)
            {
                var avalue = $(a).find("td").eq(colunindex).text().trim();
                var bvalue = $(b).find("td").eq(colunindex).text().trim();
                return isdesc ? avalue.localeCompare(bvalue) : bvalue.localeCompare(avalue);
                //return avalue < bvalue;

                var ass = 0;
                ass = ass > 0 ? 1 : 2;

            });
        }

        else if ($(this).attr("data-type") === "num")
        {//数字类型值排序操作
            tablearr.sort(function (a, b)
            {
                var avalue = parseInt($(a).find("td").eq(colunindex).text())-0;
                var bvalue = parseInt($(b).find("td").eq(colunindex).text())-0;
                return isdesc ? avalue - bvalue : bvalue - avalue;
            });
        }

        //重新添加到页面中
        var tbody = $("<tbody></tbody>").append($(tablearr));
        $("tbody").prepend($(tbody).html());
    });
});

//时间比较函数（直接提取数字进行比较）
function timescompare(a, b){
    return a.replace(/[^0-9]+/g, "") - b.replace(/[^0-9]+/g, "");
}

//分隔获取各个参数
function UrlSearch() {
    var name, value;
    var str = location.href; //取得整个地址栏
    var num = str.indexOf("?");
    str = str.substr(num + 1);
    var arr = str.split("&"); //各个参数放到数组里
    for (var i = 0; i < arr.length; i++) {
        num = arr[i].indexOf("=");
        if (num > 0) {
            name = arr[i].substring(0, num);
            value = arr[i].substr(num + 1);
            this[name] = value;
        }
    }
}


﻿namespace 酷狗无损音乐下载
{
    class KugouResult
    {
        public string filename { get; set; }
        public string sqhash { get; set; }
        public string key { get; set; }
    }
}

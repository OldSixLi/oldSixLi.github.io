/**
 * Created by Administrator on 2016/11/25.
 */
export default [{
  "title": "帝都",
  "desp": "萌萌哒天团 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/dailyring02/2015/07/2015%E5%B9%B407%E6%9C%8816%E6%97%A5%E5%8D%8E%E5%BC%BA%E8%87%B4%E8%BF%9C%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A53%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E5%B8%9D%E9%83%BD-%E8%90%8C%E8%90%8C%E5%93%92%E5%A4%A9%E5%9B%A2.mp3?channelid=08&msisdn=eb32f44d-ea82-4802-a0b1-b9fd1bb5ac3c",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=b3031e881b8faf3261ed460fa0e71cc9"
}, {
  "title": "See You Again(速度与激情7主题曲)",
  "desp": "Wiz Khalifa,Charlie Puth | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/dailyring02/2015/04/2015%E5%B9%B44%E6%9C%8817%E6%97%A5%E7%B4%A7%E6%80%A5%E5%87%86%E5%85%A5%E5%8D%8E%E7%BA%B3%E9%9F%B3%E4%B9%901%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/See+You+Again%28%E3%80%8A%E9%80%9F%E5%BA%A6%E4%B8%8E%E6%BF%80%E6%83%857%E3%80%8B%E4%B8%BB%E9%A2%98%E6%9B%B2%29-Wiz+Khalifa%2BCharlie+Puth.mp3?channelid=08&msisdn=1625fe09-55d0-491c-85da-675813e0deac",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=760d5d1f6fc92400b72118d6591cc11a"
}, {
  "title": "对不起您拨打的电话已停机",
  "desp": "辣笔小妖 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/n2/Product/2010/06/2010%E5%B9%B46%E6%9C%884%E6%97%A5%E9%A2%84%E5%AE%A1%E4%B8%9C%E6%96%B9%E4%BC%A0%E9%9F%B575%E9%A6%96/%E5%BD%A9%E9%93%83/7_mp3-128kbps/%E5%AF%B9%E4%B8%8D%E8%B5%B7%E6%82%A8%E6%8B%A8%E6%89%93%E7%9A%84%E7%94%B5%E8%AF%9D%E5%B7%B2%E5%81%9C%E6%9C%BA-%E8%BE%A3%E7%AC%94%E5%B0%8F%E5%A6%96.mp3?channelid=08&msisdn=dad03578-c13e-4ac3-beae-cf8ad1f4924a",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=67b2798035cb0a85b8d1f01fa24f9560"
}, {
  "title": "我们不该这样的(北上广不相信眼泪电视剧片尾曲)",
  "desp": "张赫宣 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/n15/2016/07/2015%E5%B9%B411%E6%9C%8817%E6%97%A516%E7%82%B902%E5%88%86%E7%B4%A7%E6%80%A5%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A5%E5%A4%A9%E7%BF%BC%E7%88%B1%E9%9F%B3%E4%B9%903%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E6%88%91%E4%BB%AC%E4%B8%8D%E8%AF%A5%E8%BF%99%E6%A0%B7%E7%9A%84%28%E5%8C%97%E4%B8%8A%E5%B9%BF%E4%B8%8D%E7%9B%B8%E4%BF%A1%E7%9C%BC%E6%B3%AA%E7%94%B5%E8%A7%86%E5%89%A7%E7%89%87%E5%B0%BE%E6%9B%B2%29-%E5%BC%A0%E8%B5%AB%E5%AE%A3.mp3?channelid=08&msisdn=2847a8ac-3f91-4a01-b759-55f38b24e016",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=e4ec0e655e562b35833e40f9bb60cac8"
}, {
  "title": "有个傻瓜爱过你",
  "desp": "唐古 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/dailyring/karakalupload/2014/08/2014%E5%B9%B408%E6%9C%8806%E6%97%A5%E5%8D%8E%E5%BC%BA%E8%87%B4%E8%BF%9C%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A52%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E6%9C%89%E4%B8%AA%E5%82%BB%E7%93%9C%E7%88%B1%E8%BF%87%E4%BD%A0-%E5%94%90%E5%8F%A4.mp3?channelid=08&msisdn=4110b776-8b41-43e6-b75f-a486d927cba6",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=b3031e881b8faf326564ce1258640956"
}, {
  "title": "走着走着就散了",
  "desp": "庄心妍 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/dailyring03/vsftp/ywq/public/ringmaker01/dailyring03/2015/11/2015%E5%B9%B411%E6%9C%8811%E6%97%A517%E7%82%B908%E5%88%86%E7%B4%A7%E6%80%A5%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A5%E8%87%B4%E5%8A%9B%E6%96%87%E5%8C%961%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E8%B5%B0%E7%9D%80%E8%B5%B0%E7%9D%80%E5%B0%B1%E6%95%A3%E4%BA%86-%E5%BA%84%E5%BF%83%E5%A6%8D.mp3?channelid=08&msisdn=161252b5-62d0-4f0b-b025-8077657239e9",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=4cbcc1b5f4ca08ca510487f6c0941cb8"
}, {
  "title": "小幸运(电影我的少女时代主题曲)",
  "desp": "田馥甄 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/dailyring02/2015/08/2015%E5%B9%B408%E6%9C%8806%E6%97%A514%E7%82%B933%E5%88%86%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A5%E5%8D%8E%E8%8D%A3%E6%96%87%E5%8C%96%E9%A2%84%E7%95%991%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E5%B0%8F%E5%B9%B8%E8%BF%90%28%E7%94%B5%E5%BD%B1%E6%88%91%E7%9A%84%E5%B0%91%E5%A5%B3%E6%97%B6%E4%BB%A3%E4%B8%BB%E9%A2%98%E6%9B%B2%29-%E7%94%B0%E9%A6%A5%E7%94%84.mp3?channelid=08&msisdn=bc6b35ba-2ccf-4b07-819f-12a5251ec2d2",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=49cacac4b6cced46cb6607afd1a15615"
}, {
  "title": "您拨打的用户在美国",
  "desp": "可米儿 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/dailyring/karakalupload/2015/03/2015%E5%B9%B403%E6%9C%8823%E6%97%A5%E4%B9%90%E6%96%B0%E6%96%87%E5%8C%96%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A57%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E6%82%A8%E6%8B%A8%E6%89%93%E7%9A%84%E7%94%A8%E6%88%B7%E5%9C%A8%E7%BE%8E%E5%9B%BD-%E5%8F%AF%E7%B1%B3%E5%84%BF.mp3?channelid=08&msisdn=f5f25222-33cd-4b8a-b072-10059ecf10d6",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=eaf1b0559975b22e78c61793e66009f6"
}, {
  "title": "一亿个伤心(新版)",
  "desp": "彭清,蒙面哥 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/dailyring02/2015/06/2015%E5%B9%B406%E6%9C%8817%E6%97%A5%E5%B9%BF%E5%B7%9E%E5%BF%97%E8%88%AA%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A52%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E4%B8%80%E4%BA%BF%E4%B8%AA%E4%BC%A4%E5%BF%83%28%E6%96%B0%E7%89%88%29-%E8%92%99%E9%9D%A2%E5%93%A5%2B%E5%BD%AD%E6%B8%85.mp3?channelid=08&msisdn=6cad6a6e-95c1-4cd8-8c5d-4cf0293bc076",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=9b5e25ba9061c6f98ef0d9f25007030c"
}, {
  "title": "咱们结婚吧",
  "desp": "齐晨 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/n4/karakalupload/2014/01/2013%E5%B9%B412%E6%9C%8827%E6%97%A5%E5%8D%8E%E5%A4%8F%E5%8A%A8%E5%A3%B0%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A51%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E5%92%B1%E4%BB%AC%E7%BB%93%E5%A9%9A%E5%90%A7-%E9%BD%90%E6%99%A8.mp3?channelid=08&msisdn=4ef8f95a-058e-4b90-a3e9-8b3eeb8e691b",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=37775c91a50c7eb3970cf7190bb17a57"
}, {
  "title": "老婆你辛苦了",
  "desp": "祁隆 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/n4/karakalupload/2014/02/2014%E5%B9%B401%E6%9C%8823%E6%97%A5%E5%8D%8E%E5%A4%8F%E5%8A%A8%E5%A3%B0%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A54%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E8%80%81%E5%A9%86%E4%BD%A0%E8%BE%9B%E8%8B%A6%E4%BA%86-%E7%A5%81%E9%9A%86.mp3?channelid=08&msisdn=36f6db25-7879-479f-8a9c-2dfb01687d81",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=37775c91a50c7eb381bc16c77c69cee7"
}, {
  "title": "想要我接电话钱就打到我的卡",
  "desp": "批疯组合 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/dailyring/karakalupload/2014/10/2014%E5%B9%B410%E6%9C%8828%E6%97%A5%E4%B9%90%E6%96%B0%E6%96%87%E5%8C%96%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A510%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E6%83%B3%E8%A6%81%E6%88%91%E6%8E%A5%E7%94%B5%E8%AF%9D%E9%92%B1%E5%B0%B1%E6%89%93%E5%88%B0%E6%88%91%E7%9A%84%E5%8D%A1-%E6%89%B9%E7%96%AF%E7%BB%84%E5%90%88.mp3?channelid=08&msisdn=c9a69a31-c701-4d0c-aba7-04b57de4ac07",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=eaf1b0559975b22e053d47e57a97f892"
}, {
  "title": "杀阡陌的霸道告白",
  "desp": "杀阡陌 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/dailyring03/vsftp/ywq/public/ringmaker01/dailyring03/2015/09/2015%E5%B9%B409%E6%9C%8817%E6%97%A513%E7%82%B951%E5%88%86%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A5%E5%8D%8E%E5%BC%BA%E8%87%B4%E8%BF%9C1%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E6%9D%80%E9%98%A1%E9%99%8C%E7%9A%84%E9%9C%B8%E9%81%93%E5%91%8A%E7%99%BD-%E6%9D%80%E9%98%A1%E9%99%8C.mp3?channelid=08&msisdn=0606652d-5def-4032-b148-de00bb2014db",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=b3031e881b8faf32ca5b4503b05871e3"
}, {
  "title": "一生最爱的是你",
  "desp": "祁隆 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/dailyring/karakalupload/2014/07/2014%E5%B9%B407%E6%9C%8814%E6%97%A5%E5%8D%8E%E5%A4%8F%E5%8A%A8%E5%A3%B0%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A51%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E4%B8%80%E7%94%9F%E6%9C%80%E7%88%B1%E7%9A%84%E6%98%AF%E4%BD%A0-%E7%A5%81%E9%9A%86.mp3?channelid=08&msisdn=4d5b92e7-88b1-4b23-b224-743f24c47033",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=37775c91a50c7eb3fb3f34eec7963ab3"
}, {
  "title": "喜欢你",
  "desp": "G.E.M.邓紫棋 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/dailyring/karakalupload/2014/08/2014%E5%B9%B48%E6%9C%8819%E6%97%A5%E7%B4%A7%E6%80%A5%E5%87%86%E5%85%A5%E5%98%89%E7%BE%8E%E8%81%94%E5%88%9B1%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E5%96%9C%E6%AC%A2%E4%BD%A0-G.E.M.%E9%82%93%E7%B4%AB%E6%A3%8B.mp3?channelid=08&msisdn=def142d4-63db-42c4-8ceb-4ff8f30fccf8",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=d95e529ea0f2b9ae8c532c3a4768240f"
}, {
  "title": "男人的苦女人不清楚",
  "desp": "金久哲 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/dailyring02/2015/06/2015%E5%B9%B406%E6%9C%8804%E6%97%A5%E4%B9%90%E6%96%B0%E6%96%87%E5%8C%96%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A52%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E7%94%B7%E4%BA%BA%E7%9A%84%E8%8B%A6%E5%A5%B3%E4%BA%BA%E4%B8%8D%E6%B8%85%E6%A5%9A-%E9%87%91%E4%B9%85%E5%93%B2.mp3?channelid=08&msisdn=f29bf610-5a48-429b-ba53-802aae07f7c7",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=eaf1b0559975b22eceb7f5306d37aba0"
}, {
  "title": "恋人心",
  "desp": "魏新雨 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/dailyring02/2015/07/2015%E5%B9%B407%E6%9C%8814%E6%97%A5%E5%88%9B%E6%96%B0%E6%96%87%E5%8C%96%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A52%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E6%81%8B%E4%BA%BA%E5%BF%83-%E9%AD%8F%E6%96%B0%E9%9B%A8.mp3?channelid=08&msisdn=31f7467b-91b8-4af2-93c8-a922fbebb2b6",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=6b7154c0894229d8952ae31fa289b2ff"
}, {
  "title": "该死的承诺",
  "desp": "雨宗林 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/dailyring03/vsftp/ywq/public/ringmaker01/dailyring03/2015/10/2015%E5%B9%B410%E6%9C%8815%E6%97%A509%E7%82%B944%E5%88%86%E7%B4%A7%E6%80%A5%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A5%E5%90%AF%E9%9F%B5%E6%96%87%E5%8C%962%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E8%AF%A5%E6%AD%BB%E7%9A%84%E6%89%BF%E8%AF%BA-%E9%9B%A8%E5%AE%97%E6%9E%97.mp3?channelid=08&msisdn=ed8f6641-4953-4712-90db-326b9adb0beb",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=b24b9f2b6b31f7641169bc3f555e3110"
}, {
  "title": "一百个放心(Dj版)",
  "desp": "张津涤 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/dailyring/karakalupload/2015/02/2015%E5%B9%B402%E6%9C%8806%E6%97%A5%E7%A6%BE%E4%BF%A1%E7%A7%91%E6%8A%80%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A51%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E4%B8%80%E7%99%BE%E4%B8%AA%E6%94%BE%E5%BF%83%28Dj%E7%89%88%29-%E5%BC%A0%E6%B4%A5%E6%B6%A4.mp3?channelid=08&msisdn=1d5515f8-60ce-4686-945a-0aec2674627d",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=7f700e2ed4ce66a15d083e365519deb8"
}, {
  "title": "您拨打的电话已停机",
  "desp": "手机小精灵 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/dailyring03/vsftp/ywq/public/ringmaker01/dailyring03/2015/09/2015%E5%B9%B409%E6%9C%8823%E6%97%A509%E7%82%B928%E5%88%86%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A5%E4%B9%90%E6%96%B0%E6%96%87%E5%8C%966%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E6%82%A8%E6%8B%A8%E6%89%93%E7%9A%84%E7%94%B5%E8%AF%9D%E5%B7%B2%E5%81%9C%E6%9C%BA-%E6%89%8B%E6%9C%BA%E5%B0%8F%E7%B2%BE%E7%81%B5.mp3?channelid=08&msisdn=a4a79bec-fa7d-4cf9-bc42-e30dc751e498",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=eaf1b0559975b22edecb721523c21950"
}, {
  "title": "南山南(中国好声音第四季 盲选第三期)",
  "desp": "张磊 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/dailyring02/2015/07/2015%E5%B9%B407%E6%9C%8831%E6%97%A515%E7%82%B952%E5%88%86%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A5%E5%A4%A9%E7%BF%BC%E7%88%B1%E9%9F%B3%E4%B9%90%E9%A2%84%E7%95%9910%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E5%8D%97%E5%B1%B1%E5%8D%97%28%E4%B8%AD%E5%9B%BD%E5%A5%BD%E5%A3%B0%E9%9F%B3%E7%AC%AC%E5%9B%9B%E5%AD%A3+%E7%9B%B2%E9%80%89%E7%AC%AC%E4%B8%89%E6%9C%9F%29-%E5%BC%A0%E7%A3%8A.mp3?channelid=08&msisdn=2fc07619-ecb5-459c-bc5a-4410539264a3",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=d85d9ed467653d2d968c66133f48f9bf"
}, {
  "title": "不爱我就别管我爱谁",
  "desp": "鸿飞 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/dailyring02/2015/06/2015%E5%B9%B406%E6%9C%8823%E6%97%A5%E5%8D%8E%E5%A4%8F%E5%8A%A8%E5%A3%B0%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A58%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E4%B8%8D%E7%88%B1%E6%88%91%E5%B0%B1%E5%88%AB%E7%AE%A1%E6%88%91%E7%88%B1%E8%B0%81-%E9%B8%BF%E9%A3%9E.mp3?channelid=08&msisdn=0eb17d72-b5e4-4b65-a6d1-149f840d7e2b",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=59868e427019445d1e0fd4cef9f8d504"
}, {
  "title": "您拨打的电话是空号",
  "desp": "电话秘书 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/n3/Product/2011/12/2011%E5%B9%B411%E6%9C%8803%E6%97%A5%E5%87%86%E5%85%A5%E9%9F%B3%E7%8B%90%E6%96%87%E5%8C%96144%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E6%82%A8%E6%8B%A8%E6%89%93%E7%9A%84%E7%94%B5%E8%AF%9D%E6%98%AF%E7%A9%BA%E5%8F%B7-%E7%94%B5%E8%AF%9D%E7%A7%98%E4%B9%A6.mp3?channelid=08&msisdn=61cac126-88e3-466f-a301-f12f41cc2e52",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=933be54a156740cf5a222f2d967de7cb"
}, {
  "title": "飞蛾扑火",
  "desp": "彭丽丽 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/dailyring/karakalupload/2015/04/2015%E5%B9%B404%E6%9C%8807%E6%97%A5%E6%82%A6%E9%9F%B3%E4%B8%8A%E6%B5%B7%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A512%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E9%A3%9E%E8%9B%BE%E6%89%91%E7%81%AB-%E5%BD%AD%E4%B8%BD%E4%B8%BD.mp3?channelid=08&msisdn=8051ab1b-ce47-456b-86b3-62ce32910c86",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=7f1300405f24e1261600ab2ce7ca7962"
}, {
  "title": "有钱男子汉没钱汉子难",
  "desp": "东浩 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/dailyring02/2015/05/2015%E5%B9%B405%E6%9C%8827%E6%97%A5%E5%B9%BF%E5%B7%9E%E5%BF%97%E8%88%AA%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A52%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E6%9C%89%E9%92%B1%E7%94%B7%E5%AD%90%E6%B1%89%E6%B2%A1%E9%92%B1%E6%B1%89%E5%AD%90%E9%9A%BE-%E4%B8%9C%E6%B5%A9.mp3?channelid=08&msisdn=98b965a7-6516-4618-a34d-c29be66efc5c",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=9b5e25ba9061c6f9b7924c57336780ae"
}, {
  "title": "相依为命",
  "desp": "陈小春 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/dailyring03/vsftp/ywq/public/ringmaker01/dailyring03/2015/10/2015%E5%B9%B410%E6%9C%8827%E6%97%A516%E7%82%B945%E5%88%86%E7%B4%A7%E6%80%A5%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A5SONY27%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E7%9B%B8%E4%BE%9D%E4%B8%BA%E5%91%BD-%E9%99%88%E5%B0%8F%E6%98%A5.mp3?channelid=08&msisdn=83300ece-d0f3-4ca3-95ac-cd31928162fe",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=a7246919c0a269056d94c2354640a12f"
}, {
  "title": "您拨打的用户在日本",
  "desp": "可米儿 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/dailyring/karakalupload/2015/03/2015%E5%B9%B403%E6%9C%8823%E6%97%A5%E4%B9%90%E6%96%B0%E6%96%87%E5%8C%96%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A57%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E6%82%A8%E6%8B%A8%E6%89%93%E7%9A%84%E7%94%A8%E6%88%B7%E5%9C%A8%E6%97%A5%E6%9C%AC-%E5%8F%AF%E7%B1%B3%E5%84%BF.mp3?channelid=08&msisdn=001a9dc4-7668-4079-a6b0-53f7f874e0c8",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=eaf1b0559975b22e48aeefa35d6f2f2f"
}, {
  "title": "Creepinuponyou情不自禁爱上你",
  "desp": "Darren Hayes | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/n4/karakalupload/2014/02/2014%E5%B9%B402%E6%9C%8807%E6%97%A5%E5%81%A5%E8%AE%AF%E7%A7%91%E6%8A%80%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A546%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/Creepinuponyou%E6%83%85%E4%B8%8D%E8%87%AA%E7%A6%81%E7%88%B1%E4%B8%8A%E4%BD%A0-Darrenhayes.mp3?channelid=08&msisdn=bf62602a-68f9-40f1-91cc-486a77533615",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=cda738e4d90a1a9fe31f0eff28adb5ac"
}, {
  "title": "你偷走了我的心",
  "desp": "祁隆 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/n4/karakalupload/2014/01/2014%E5%B9%B401%E6%9C%8823%E6%97%A5%E5%8D%8E%E5%A4%8F%E5%8A%A8%E5%A3%B0%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A54%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E4%BD%A0%E5%81%B7%E8%B5%B0%E4%BA%86%E6%88%91%E7%9A%84%E5%BF%83-%E7%A5%81%E9%9A%86.mp3?channelid=08&msisdn=0fe83168-3924-47fa-824f-f41a44aacb12",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=37775c91a50c7eb38feaea38fbc01aa6"
}, {
  "title": "走在冷风中",
  "desp": "刘思涵 | 48秒",
  "songUrl": "http://tyst.migu.cn/public/ringmaker01/n4/Product/2012/02/2012%E5%B9%B402%E6%9C%8802%E6%97%A5%E7%A7%8D%E5%AD%90%E9%9F%B3%E4%B9%90%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A510%E9%A6%96/%E5%BD%A9%E9%93%83/6_mp3-128kbps/%E8%B5%B0%E5%9C%A8%E5%86%B7%E9%A3%8E%E4%B8%AD-%E5%88%98%E6%80%9D%E6%B6%B5.mp3?channelid=08&msisdn=6cc346ea-9605-48df-a5f5-fa1b75aab77f",
  "orderUrl": "http://m.kugou.com/v3/static/html/orderRing.html?id=c494b26921478bd7660dc687ab13b809"
}]

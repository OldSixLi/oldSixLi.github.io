 FOLLOW A KUGOU
----------------

vuejs仿写酷狗音乐webapp
-----------------

在线预览：
----

在线预览使用nuxt重写的demo
[vue-kugou-demo-nuxt](http://github.com/lavyun/vue-demo-kugou-nuxt)


项目截图：
----
![](http://opj15jbpo.bkt.clouddn.com/81854091-77E3-413F-BB11-0C24F27744BE.png?imageView2/3/w/400/h/200/q/75|imageslim)<br><br>
![](http://opj15jbpo.bkt.clouddn.com/0B7FDF5C-F820-4C43-BA7F-A82CDB464F29.png?imageView2/3/w/400/h/200/q/75|imageslim)<br><br>
![](http://opj15jbpo.bkt.clouddn.com/9F60D9FD-3463-46F2-848A-62D4AAD4A1BB.png?imageView2/3/w/400/h/200/q/75|imageslim)<br><br>

如何使用
----

 1. 下载本项目到本地
 2. npm install 安装依赖
 3. npm run dev 启动本地开发

/**
 * Created by Axiny on 2016/8/5.
 */
'use strict';//严格模式
var app = angular.module("routerApp");
app.factory('messageService',[
    "$http",
    "$q",
    function($http,$q){
        //获取消息列表
        var getMessageList = function(data){
            var defer = $q.defer();
            $http({
                method:"GET",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("GET", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/mmsg?key='+ data.key +'&state=' + data.state + '&obj=' + data.obj + '&startDate=' + data.startDate + '&endDate=' + data.endDate + '&page=' + data.page + '&pageNum=' + data.pageNum ,
                data:data
            })
                .success(function(data, status, headers, config){
                    defer.resolve(data);
                    console.log("select messageData clear");
                })
                .error(function(data,status,headers,config){
                    defer.resolve(data);
                    console.log("select messageData error");
                });
            return defer.promise;
        };

        //获取已推送的消息数
        var getMessageNum = function(){
            var defer = $q.defer();
            $http({
                method:"GET",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("GET", $.param("")),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/mmsg/pushnum'
            })
                .success(function(data, status, headers, config){
                    defer.resolve(data);
                    console.log("select messageData clear");
                })
                .error(function(data,status,headers,config){
                    defer.resolve(data);
                    console.log("select messageData error");
                });
            return defer.promise;
        };

        //添加消息
        var addMessageData = function(data){
            console.log(data);
            var defer = $q.defer();
            $http({
                method:"POST",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("POST", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/mmsg',
                data: $.param(data)
            })
                .success(function(data, status, headers, config){
                    var data = {
                        data:data,
                        status:status
                    }
                    defer.resolve(data);
                    console.log("add messageData clear");
                })
                .error(function(data,status,headers,config){
                    var data = {
                        data:data,
                        status:status
                    }
                    defer.resolve(data);
                    console.log("add messageData error");
                });

            return defer.promise;
        };

        //编辑消息
        var editMessageData = function(data){    //data：获取需要编辑的用户信息
            var defer = $q.defer();
            $http({
                        method:"PUT",
                        headers:
                        {
                            "content-type":HEADERS.contentType,
                            "timestamp":HEADERS.timestamp,
                            "sign":HEADERS.sign("PUT", $.param(data)),
                            "accessKey":HEADERS.accessKey
                        },
                        url:serviceURL + '/mmsg/'+data.id,
                        data: $.param(data)
                    })
                .success(function(data, status, headers, config){
                    var data = {
                        data:data,
                        status:status
                    }
                    defer.resolve(data);
                    console.log("edit messageData clear");
                })
                .error(function(data,status,headers,config){
                    var data = {
                        data:data,
                        status:status
                    }
                    defer.resolve(data);
                    console.log("edit messageData error");
                });

            return defer.promise;
        };

        //通过ID删除消息
        var deleteMessageById = function(data){    //data：需要删除的用户ID
            var defer = $q.defer();
            $http({
                method:"DELETE",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("DELETE", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/mmsg/'+data.id,
                data:data
            })
                .success(function(data, status, headers, config){
                    var data = {
                        data:data,
                        status:status
                    }
                    defer.resolve(data);
                    console.log("delete messageData clear");
                })
                .error(function(data,status,headers,config){
                    var data = {
                        data:data,
                        status:status
                    }
                    defer.resolve(data);
                    console.log("delete messageData error");
                });

            return defer.promise;
        };

        //批量删除
        var deleteMes = function(data){    //data：需要删除的用户ID list
           console.log(data);
            var defer = $q.defer();
            $http({
                method:"DELETE",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("DELETE", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/mmsg/?' + data
            })
                .success(function(data, status, headers, config){
                    var data = {
                        data:data,
                        status:status
                    };
                    defer.resolve(data);
                    console.log("delete mes clear");
                })
                .error(function(data,status,headers,config){
                    var data = {
                        data:data,
                        status:status
                    };
                    defer.resolve(data);
                    console.log("delete mes error");
                });

            return defer.promise;
        };




        //暴露数据服务接口
        return{
            getMessageList:getMessageList,  //获取消息列表      data：页码
            getMessageNum:getMessageNum,//获取推送消息数
            addMessageData:addMessageData,  //增加消息                           data：添加的消息信息
            editMessageData:editMessageData,  //修改消息                     data：修改的消息信息
            deleteMessageById:deleteMessageById, //通过ID删除消息      data：需要删除的消息ID
            deleteMes:deleteMes//批量删除消息
        };
    }
]);
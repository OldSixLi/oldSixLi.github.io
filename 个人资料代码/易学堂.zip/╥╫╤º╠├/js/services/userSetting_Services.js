/**
 * Created by Axiny on 2016/8/5.
 */
'use strict';//严格模式
var app = angular.module("routerApp");
app.factory('userSettingService',[
    "$http",
    "$q",
    function($http,$q){

        //获取注册总人数及用户信息
        var getUserData = function(data){
            var defer = $q.defer();
            var addProblem = '';
            if(data.key !=""){
                addProblem +='key='+ data.key +'';
            }
            if(data.role !=""||data.role =="0"){
                addProblem +='&role=' + data.role + '';
            }
            if(data.sex !=""||data.sex =="0"){
                addProblem +='&sex=' + data.sex + '';
            }
            if(data.regstartDate !=""){
                addProblem +='&regstartDate=' + data.regstartDate + '';
            }
            if(data.regendDate!=""){
                addProblem +='&regendDate=' + data.regendDate + '';
            }
            $http({
                method:"GET",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("GET", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/muser?'+addProblem+'&page=' + data.page + '&pageNum=' + data.pageNum
                //data:data
            })
                .success(function(data, status, headers, config){
                    defer.resolve(data);
                    console.log("select userData clear");
                })
                .error(function(data,status,headers,config){
                    defer.resolve(data);
                    console.log("select userData error");
                });
            return defer.promise;
        };

        //获取一级科室名称
        var getFirstDepName = function(data){
            var defer = $q.defer();
            $http({
                method:"GET",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("GET", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/cdepart/?level=' + data.level +'&page=' + data.page + '&pageNum=' + data.pageNum ,
                data:data
            })
                .success(function(data, status, headers, config){
                    defer.resolve(data);
                    console.log("select FirstDepName clear");
                })
                .error(function(data,status,headers,config){
                    defer.resolve(data);
                    console.log("select FirstDepName error");
                });

            return defer.promise;
        };

        //获取二级科室名称
        var getSecondDepName = function(data){   //data：一级科室ID
            var defer = $q.defer();
            $http({
                method:"GET",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("GET", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/cdepart/' + data.did + '/subdepart?page=' + data.page + '&pageNum=' + data.pageNum ,
                data:data
            })
                .success(function(data, status, headers, config){
                    defer.resolve(data);
                    console.log("select SecondDepName clear");
                })
                .error(function(data,status,headers,config){
                    defer.resolve(data);
                    console.log("select SecondDepName error");
                });

            return defer.promise;
        };

        //获取列表里对应人员科室名称
        var getPeopleDepName = function(data){   //data：科室ID
            var defer = $q.defer();
            $http({
                method:"GET",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("GET", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/cdepart/'+data.id
            })
                .success(function(data, status, headers, config){
                    defer.resolve(data);
                    console.log("select depUser clear");
                })
                .error(function(data,status,headers,config){
                    defer.resolve(data);
                    console.log("select depUser error");
                });

            return defer.promise;
        };

        //添加用户
        var addUser = function(data){
            var defer = $q.defer();
            $http({
                method:"POST",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("POST", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/muser',
                data: $.param(data)
            })
                .success(function(data, status, headers, config){
                    var data = {
                        data:data,
                        status:status
                    }
                    defer.resolve(data);
                    console.log("add User clear");
                })
                .error(function(data,status,headers,config){
                    var data = {
                        data:data,
                        status:status
                    }
                    defer.resolve(data);
                    console.log("add User error");
                });

            return defer.promise;
        };

        //编辑用户信息
        var editUserData = function(data){    //data：获取需要编辑的用户信息
            var defer = $q.defer();
            $http({
                method:"PUT",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("PUT", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/muser/'+data.id,
                data: $.param(data)
            })
                .success(function(data, status, headers, config){
                    var data = {
                        data:data,
                        status:status
                    }
                    defer.resolve(data);
                    console.log("edit userData clear");
                })
                .error(function(data,status,headers,config){
                    var data = {
                        data:data,
                        status:status
                    }
                    defer.resolve(data);
                    console.log("edit userData error");
                });

            return defer.promise;
        };

        //通过ID删除用户
        var deleteUserById = function(data){    //data：需要删除的用户ID
            var defer = $q.defer();
            $http({
                method:"DELETE",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("DELETE", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/muser/'+data.id
                //data:data
            })
                .success(function(data, status, headers, config){
                    var data = {
                        data:data,
                        status:status
                    }
                    defer.resolve(data);
                    console.log("delete userData clear");
                })
                .error(function(data,status,headers,config){
                    var data = {
                        data:data,
                        status:status
                    }
                    defer.resolve(data);
                    console.log("delete userData error");
                });

            return defer.promise;
        };

        //批量删除用户
        var deleteUser = function(data){    //data：需要删除的用户ID list
            var defer = $q.defer();
            $http({
                method:"DELETE",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("DELETE", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/muser/?' + data
            })
                .success(function(data, status, headers, config){
                    var data = {
                        data:data,
                        status:status
                    };
                    defer.resolve(data);
                    console.log("delete User clear");
                })
                .error(function(data,status,headers,config){
                    var data = {
                        data:data,
                        status:status
                    };
                    defer.resolve(data);
                    console.log("delete User error");
                });

            return defer.promise;
        };

        //查看用户信息
        var showUserData = function(data){    //data：获取需要编辑的用户信息
            var defer = $q.defer();
            $http({
                method:"GET",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("GET", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/muser/'+data
            })
                .success(function(data, status, headers, config){
                    var data = {
                        data:data,
                        status:status
                    };
                    defer.resolve(data);
                })
                .error(function(data,status,headers,config){
                    var data = {
                        data:data,
                        status:status
                    };
                    defer.resolve(data);
                });
            return defer.promise;
        };
        //暴露数据服务接口
        return{
            getUserData:getUserData,  //获取注册用户信息至table      data：页码
            getFirstDepName:getFirstDepName,  //获取一级部门名称
            getSecondDepName:getSecondDepName,  //获取二级部门名称   data：一级科室ID
            addUser:addUser,  //增加用户                           data：添加的用户信息
            editUserData:editUserData,  //修改用户                     data：修改的用户信息
            deleteUser:deleteUser,  //批量删除用户                  data：需要删除的用户ID list
            deleteUserById:deleteUserById, //通过ID删除用户      data：需要删除的用户ID
            getPeopleDepName:getPeopleDepName ,  //根据人员部门id获取部门名称
            showUserData:showUserData  //查看用户                     data：用户ID
        };
    }
]);
/**
 * Created by Axiny on 2016/8/17.
 */
'use strict';//严格模式

var app = angular.module("routerApp");
app.factory('classSettingService',[
    "$http",
    "$q",
    function($http,$q){

        //获取群组数据至table
        var getClassData = function(data){  //data：页码
            var defer = $q.defer();
            $http({
                method:"GET",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("GET", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/mgroup?key='+ data.key +'&state=' + data.state + '&page=' + data.page + '&pageNum=' + data.pageNum ,
                data:data
            })
                .success(function(data, status, headers, config){
                    defer.resolve(data);
                    //console.log("select classData clear");
                })
                .error(function(data,status,headers,config){
                    defer.resolve(data);
                    //console.log("select classData error");
                });

            return defer.promise;
        };

        //通过ID删除群组
        var deleteClassForID = function(data){
            var defer = $q.defer();
            $http({
                method:"DELETE",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("DELETE", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/mgroup/'+data.gid,
                data:data
            })
                .success(function(data, status, headers, config){
                    var data = {
                        data:data,
                        status:status
                    }
                    defer.resolve(data);
                })
                .error(function(data,status,headers,config){
                    var data = {
                        data:data,
                        status:status
                    }
                    defer.resolve(data);
                });

            return defer.promise;
        };

        //批量删除群组
        var deleteClass = function(data){  //data：群组ID list
            var defer = $q.defer();
            $http({
                method:"DELETE",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("DELETE", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/mgroup?' + data
            })
                .success(function(data, status, headers, config){
                    var data = {
                        data:data,
                        status:status
                    };
                    defer.resolve(data);
                    console.log("delete UserForClass clear");
                })
                .error(function(data,status,headers,config){
                    var data = {
                        data:data,
                        status:status
                    };
                    defer.resolve(data);
                    console.log("delete UserForClass error");
                });

            return defer.promise;
        };

        //修改群组信息
        var updateClassMes = function(data){  //data：群组信息字段
            var defer = $q.defer();
            $http({
                method:"PUT",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("PUT", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/mgroup/'+data.gid,
                data: data.str
            })
                .success(function(data, status, headers, config){
                    var data = {
                        data:data,
                        status:status
                    }
                    defer.resolve(data);
                    console.log("update class clear");
                })
                .error(function(data,status,headers,config){
                    var data = {
                        data:data,
                        status:status
                    }
                    defer.resolve(data);
                    console.log("update class error");
                });

            return defer.promise;
        };

        //获取群组成员列表
        var getGroupMember = function(data){  //data：群组信息字段
            var defer = $q.defer();
            $http({
                method:"GET",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("GET", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/mgroup/'+data.gid+'/member?page='+ data.page +'&pageNum='+ data.pageNum,
                data: $.param(data)
            })
                .success(function(data, status, headers, config){
                    var data = {
                        data:data,
                        status:status
                    }
                    defer.resolve(data);
                    console.log("get users for class clear");
                })
                .error(function(data,status,headers,config){
                    var data = {
                        data:data,
                        status:status
                    }
                    defer.resolve(data);
                    console.log("get users for class error");
                });

            return defer.promise;
        };

        //批量添加用户到群组里
        var addUsersGroup = function(data){  //data：用户id
            var defer = $q.defer();
            $http({
                method:"POST",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("POST", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/mgroup/' + data.gid +'/member',
                data:data.ids
            })
                .success(function(data, status, headers, config){
                    var data = {
                        data:data,
                        status:status
                    };
                    defer.resolve(data);
                    console.log("add Users for group clear");
                })
                .error(function(data,status,headers,config){
                    var data = {
                        data:data,
                        status:status
                    };
                    defer.resolve(data);
                    console.log("add Users for group error");
                });

            return defer.promise;
        };

        //添加用户至群组
        var addTheUserGroup = function(data){  //data：用户id 组成的list
            var defer = $q.defer();
            $http({
                method:"POST",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("POST", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/mgroup/' + data.gid +'/member/' + data.mid
                //data:data
            })
                .success(function(data, status, headers, config){
                    var data = {
                        data:data,
                        status:status
                    };
                    defer.resolve(data);
                    console.log("add UserForClass clear");
                })
                .error(function(data,status,headers,config){
                    var data = {
                        data:data,
                        status:status
                    };
                    defer.resolve(data);
                    console.log("add UserForClass error");
                });

            return defer.promise;
        };

        //添加用户
        var addUser = function(data){     //data：添加的用户信息
            var defer = $q.defer();
            $http({
                method:"POST",
                data:data,
                url:""
            })
                .success(function(data, status, headers, config){
                    defer.resolve(data);
                    console.log("add User clear");
                })
                .error(function(data,status,headers,config){
                    defer.resolve(data);
                    console.log("add User error");
                });

            return defer.promise;
        };

        //从群组中删除用户
        var delUserForClass = function(data){  //data：用户id 组成的list
            var defer = $q.defer();
            $http({
                method:"DELETE",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("DELETE", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/mgroup/' + data.gid +'/member',
                data:data.ids
            })
                .success(function(data, status, headers, config){
                    var data = {
                        data:data,
                        status:status
                    };
                    defer.resolve(data);
                    console.log("add UserForClass clear");
                })
                .error(function(data,status,headers,config){
                    var data = {
                        data:data,
                        status:status
                    };
                    defer.resolve(data);
                    console.log("add UserForClass error");
                });

            return defer.promise;
        };

        //暴露数据服务接口
        return{
            getClassData:getClassData,  //获取群组数据至table  data:页码
            getGroupMember:getGroupMember,//获取群组成员列表

            updateClassMes:updateClassMes,  //修改群组信息  data：群组信息字段

            addUsersGroup:addUsersGroup,  //批量添加用户到群组里
            addTheUserGroup:addTheUserGroup,  //添加用户至群组  data：用户id 组成的list

            addUser:addUser,  //添加用户  data：用户信息

            delUserForClass:delUserForClass,  //从群组中删除用户  data：用户id 组成的list

            deleteClassForID:deleteClassForID,  //通过ID删除群组
            deleteClass:deleteClass  //批量删除群组

        };
    }
]);
/**
 * Created by Axiny on 2016/8/29.
 */
'use strict';//严格模式
var app = angular.module("routerApp");
app.factory('countService',[
    '$http',
    '$q',
    "$state",
    function($http, $q, $state){
        //获取新增用户
        var getAddUserCount = function(data){
            var defer = $q.defer();
            $http({
                method:"GET",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("GET", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/mstatis/newusers?startDate=' + data.startDate + '&endDate=' + data.endDate+ '&periodType=' + data.periodType
            })
                .success(function(data, status, headers, config){
                    defer.resolve(data);
                    console.log("select newUserNum clear");
                })
                .error(function(data,status,headers,config){
                    defer.resolve(data);
                    console.log("select newUserNum error");
                });

            return defer.promise;
        };

        //累计用户
        var getTotalUserCount = function(data){
            var defer = $q.defer();
            $http({
                method:"GET",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("GET", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/mstatis/cumulativeusers?startDate=' + data.startDate + '&endDate=' + data.endDate+ '&periodType=' + data.periodType
            })
                .success(function(data, status, headers, config){
                    defer.resolve(data);
                    console.log("select totalNum clear");
                })
                .error(function(data,status,headers,config){
                    defer.resolve(data);
                    console.log("select totalNum error");
                });

            return defer.promise;
        };

        //启动次数
        var getStartUpCount = function(data){
            var defer = $q.defer();
            $http({
                method:"GET",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("GET", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/mstatis/launches?startDate=' + data.startDate + '&endDate=' + data.endDate+ '&periodType=' + data.periodType
            })
                .success(function(data, status, headers, config){
                    defer.resolve(data);
                    console.log("select startUpNum clear");
                })
                .error(function(data,status,headers,config){
                    defer.resolve(data);
                    console.log("select startUpNum error");
                });

            return defer.promise;
        };

        //活跃用户构成
        var getActiveUserCount = function(data){
            var defer = $q.defer();
            $http({
                method:"GET",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("GET", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/mstatis/activeusers?startDate=' + data.startDate + '&endDate=' + data.endDate+ '&periodType=' + data.periodType
            })
                .success(function(data, status, headers, config){
                    defer.resolve(data);
                    console.log("select activeNum clear");
                })
                .error(function(data,status,headers,config){
                    defer.resolve(data);
                    console.log("select activeNum error");
                });

            return defer.promise;
        };

        //留存用户
        var getRetainedUser = function(data){
            var defer = $q.defer();
            $http({
                method:"GET",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("GET", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/mstatis/retentions?startDate=' + data.startDate + '&endDate=' + data.endDate+ '&periodType=' + data.periodType
            })
                .success(function(data, status, headers, config){
                    defer.resolve(data);
                    console.log("select regNum clear");
                })
                .error(function(data,status,headers,config){
                    defer.resolve(data);
                    console.log("select regNum error");
                });

            return defer.promise;
        };

        return{
            getAddUserCount:getAddUserCount,//新增用户
            getTotalUserCount:getTotalUserCount,//累计用户
            getStartUpCount:getStartUpCount,//启动次数
            getActiveUserCount:getActiveUserCount,//活跃用户构成
            getRetainedUser:getRetainedUser//留存用户
        }
    }
]);
/**
 * Created by Axiny on 2016/8/5.
 */
'use strict';//严格模式
var app = angular.module("routerApp");
app.factory('systemSettingService',[
    "$http",
    "$q",
    function($http,$q){

        //获取图片列表
        var getImgData = function(data){
            var defer = $q.defer();
            $http({
                method:"GET",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("GET", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/mstartup?page=' + data.page + '&pageNum=' + data.pageNum
            })
                .success(function(data, status, headers, config){
                    defer.resolve(data);
                    console.log("select imgData clear");
                })
                .error(function(data,status,headers,config){
                    defer.resolve(data);
                    console.log("select imgData error");
                });
            return defer.promise;
        };

        //上传图片
        var addImg = function(data){
            console.log(data);
            var defer = $q.defer();
            $http({
                method:"POST",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("POST", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/mstartup',
                data: $.param(data)
            })
                .success(function(data, status, headers, config){
                    var data = {
                        data:data,
                        status:status
                    }
                    defer.resolve(data);
                    console.log("add img clear");
                })
                .error(function(data,status,headers,config){
                    var data = {
                        data:data,
                        status:status
                    }
                    defer.resolve(data);
                    console.log("add img error");
                });

            return defer.promise;
        };

        //通过ID删除图片
        var deleteImgById = function(data){    //data：需要删除的用户ID
            var defer = $q.defer();
            $http({
                method:"DELETE",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("DELETE", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/mstartup/'+data.id,
                data:data
            })
                .success(function(data, status, headers, config){
                    var data = {
                        data:data,
                        status:status
                    }
                    defer.resolve(data);
                    console.log("delete img clear");
                })
                .error(function(data,status,headers,config){
                    var data = {
                        data:data,
                        status:status
                    }
                    defer.resolve(data);
                    console.log("delete img error");
                });

            return defer.promise;
        };

        //获取图片详细信息
        var getImgDetail = function(data){    //data：需要删除的用户ID list
            var defer = $q.defer();
            $http({
                method:"GET",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("GET", $.param(data)),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/mstartup/'+data.id,
                data:data
            })
                .success(function(data, status, headers, config){
                    var data = {
                        data:data,
                        status:status
                    };
                    defer.resolve(data);
                    console.log("get imgData clear");
                })
                .error(function(data,status,headers,config){
                    var data = {
                        data:data,
                        status:status
                    };
                    defer.resolve(data);
                    console.log("get imgData error");
                });

            return defer.promise;
        };

          //获取七牛uptoken
        var getUptoken = function(){
            var defer = $q.defer();
            $http({
                method:"GET",
                headers:
                {
                    "content-type":HEADERS.contentType,
                    "timestamp":HEADERS.timestamp,
                    "sign":HEADERS.sign("GET"),
                    "accessKey":HEADERS.accessKey
                },
                url:serviceURL + '/cqiniu/uptoken'
            })
                .success(function(data, status, headers, config){
                    var data = {
                        data:data
                    };
                    defer.resolve(data);
                    console.log("get uptoken clear");
                })
                .error(function(data,status,headers,config){
                    var data = {
                        data:data
                    };
                    defer.resolve(data);
                    console.log("get uptoken error");
                });

            return defer.promise;
        };



        //暴露数据服务接口
        return{
            getImgData:getImgData,  //获取图片信息至table      data：页码
            getImgDetail:getImgDetail,//获取图片详细信息
            addImg:addImg,  //增加图片                           data：添加的用户信息
            deleteImgById:deleteImgById,//通过ID删除图片      data：需要删除的用户ID
            getUptoken:getUptoken //获取七牛uptoken
        };
    }
]);
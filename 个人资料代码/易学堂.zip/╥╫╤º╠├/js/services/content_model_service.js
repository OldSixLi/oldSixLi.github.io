angular.module("routerApp")
    .factory('contentModelService', ['$resource', function($resource) {
        /*整体的基础url*/
        var baseUrl = 'https://www.medschoolcloud.com/api/';//公司内侧使用
        // var baseUrl = 'http://101.201.78.224:8081/estudyserver/api/';//客户使用

        var addHeaders = {
            method: 'POST',
            isArray: false,
            headers: {
                'Content-type': 'application/json'
            }
        };

        /*心音, 呼吸音, 病例, 听诊点列表*/
        var msubjectBaseUrl = baseUrl + 'msubjectmodule/:moduleId/auscultation';

        var msubject = $resource(msubjectBaseUrl, {
            moduleId: '@moduleId'
        }, {
            /*添加听诊点*/
            addDiagPoint: addHeaders
        });

        /*听诊点的*/
        var soundPointBaseUrl = baseUrl + 'mauscultation/:aid';
        var soundPointGetSoundSourceUrl = baseUrl + 'mauscultation/:aid/soundsource';

        var soundPoint = $resource(soundPointBaseUrl, {
            aid: '@aid'
        }, {
            put: {
                method: 'PUT',
                isArray: false,
                headers: {
                    'Content-type': 'application/json'
                }
            }
        });
        var soundPointGetSource = $resource(soundPointGetSoundSourceUrl, {aid: '@aid'});


        /*音源*/
        var msoundSourceBaseUrl = baseUrl + 'msoundsource/:id';
        var msoundSourceChangeStatusUrl = msoundSourceBaseUrl + '/status';
       var msoundSourceChangeStatus = $resource(msoundSourceChangeStatusUrl, {
           id: '@id'
       }, {
           changeSoundStatus: {
               method: 'PUT',
               isArray: false,
               headers: {
                   'Content-type': 'application/json'
               }
           }
       });
        var msoundSource = $resource(msoundSourceBaseUrl, {
            id: '@id'
        }, {
            addSoundSource: addHeaders,
            deleteMore: {
                method: 'DELETE',
                isArray: false,
                headers: {
                    'Content-type': 'application/json'
                }
            },
            editSoundSource: {
                method: 'PUT',
                isArray: false,
                headers: {
                    'Content-type': 'application/json'
                }
            }
        });
        function deleteSoundSources(deleteItemsId) {
            return  $.ajax({
                url: baseUrl + 'msoundsource',
                type: 'DELETE',
                data: JSON.stringify({
                    ids: deleteItemsId
                }),
                contentType: 'application/json',
            });
        }
        var soundSoundDeletes = deleteSoundSources;


        var illCaseBaseUrl = baseUrl + 'mdiagnosis/:id';
        var illCaseChangeStatusUrl = illCaseBaseUrl + '/status';

        var illCaseChangeStatus = $resource(illCaseChangeStatusUrl, {
            id: '@id'
        }, {
            changeIllStatus: {
                method: 'PUT',
                isArray: false,
                headers: {
                    'Content-type': 'application/json'
                }
            }
        });
        var illCase = $resource(illCaseBaseUrl, {
            id: '@id'
        }, {
            editIll: {
                method: 'PUT',
                isArray: false,
                headers: {
                    'Content-type': 'application/json'
                }
            }
        });
        var illCaseAddOrListUrl = baseUrl + 'msubjectmodule/:mid/mdiagnosis';
        var illCaseAddOrList = $resource(illCaseAddOrListUrl, {
            mid: '@mid'
        }, {
            addIll: {
                method: 'POST',
                isArray: false,
                headers: {
                    'Content-type': 'application/json'
                }
            }
        });

        function deleteIlls(deleteItemsId) {
           return $.ajax({
                url: baseUrl + 'mdiagnosis',
                type: 'DELETE',
                data: JSON.stringify({
                    ids: deleteItemsId
                }),
                contentType: 'application/json',
            });
        }
        var illDeletes = deleteIlls;

        /*七牛云路径*/
        var qiniuBaseAudioUrl = baseUrl + 'cqiniu/voiceuptoken';
        var qiniuBaseImgUrl = baseUrl + 'cqiniu/uptoken';

        var qiniuSoundSourceUploadUrl = 'http://up-z0.qiniu.com';
        var qiniuImgUploadUrl = 'http://up-z1.qiniu.com';

        var qiniuHeart = 'http://og0niwlp1.bkt.clouddn.com/';
        var getQiniuImgUrl = 'http://ogos02i1z.bkt.clouddn.com/';

        var qiniu = $resource(qiniuBaseAudioUrl);
        var qiniuImg = $resource(qiniuBaseImgUrl);

        var tokenPromise = qiniuImg.get();


        var uploadImgFile = function (uploadFile) {
           return tokenPromise.$promise.then(function (data) {
                var token = data.uptoken;
                var formData = new FormData();
                formData.append('token', data.uptoken);
                formData.append('file', uploadFile);
                return $.ajax({
                    url: qiniuImgUploadUrl,
                    contentType: false,
                    processData: false,
                    type: 'POST',
                    data: formData
                });
            });
        };

        var localCaseImgUrlArr = [
            {
                url: './img/lung2.png',
                name: '前',
                points: [
                    {
                        name: '喉部',
                        id: 8107
                    },
                    {
                        name: '胸骨上窝',
                        id: 8108
                    },
                    {
                        name: '肺尖部（左）',
                        id:8109
                    },
                    {
                        name: '肺尖部（右）',
                        id:8110
                    },
                    {
                        name: '胸骨左侧第1、2肋间隙',
                        id: 8111
                    },
                    {
                        name: '胸骨右侧第1、2肋间隙',
                        id: 8112
                    },
                    {
                        name: '锁骨中线与腋前线第4肋间（左）',
                        id: 8113
                    },
                    {
                        name: '锁骨中线与腋前线第4肋间（右）',
                        id: 8114
                    },
                    {
                        name: '锁骨中线第3肋间（左）',
                        id: 8115
                    },
                    {
                        name: '锁骨中线第3肋间（右）',
                        id: 8116
                    },


                ]
            },
            {
                url: './img/lung1.png',
                name: '后',
                points: [
                    {
                        name: '第1、2胸椎水平（左）',
                        id: 8123
                    },
                    {
                        name: '第1、2胸椎水平（右）',
                        id: 8124
                    },
                    {
                        name: '肩胛间区第3、4胸椎（左）',
                        id: 8125
                    },
                    {
                        name: '肩胛间区第3、4胸椎（右）',
                        id: 8126
                    },
                    {
                        name: '肩胛线与后正中线第8肋间隙（左）',
                        id: 8127
                    },
                    {
                        name: '肩胛线与后正中线第8肋间隙（右）',
                        id: 8128
                    },
                    {
                        name: '肩胛线第9肋间隙（左）',
                        id: 8129
                    },
                    {
                        name: '肩胛线第9肋间隙（右）',
                        id: 8130
                    }]
            },
            {
                url: './img/lung_side2.png',
                name: '左',
                points: [
                    {
                        name: '腋后线第6肋间（左）',
                        id: 8119
                    },
                    {
                        name: '腋前线第5肋间（左）',
                        id: 8117
                    },
                    {
                        name: '腋中线第6肋间（左）',
                        id: 8121
                    },
                ]

            },
            {
                url: './img/lung_side1.png',
                name: '右',
                points: [
                    {
                        name: '腋后线第6肋间（右）',
                        id: 8120,
                    },
                    {
                        name: '腋中线第6肋间（右）',
                        id: 8122,
                    },
                    {
                        name: '腋前线第5肋间（右）',
                        id: 8118
                    },
                ]

            },
            {
                url: './img/heart.png',
                name: '心脏',
                points: [
                    {
                        name: '主动脉瓣区',
                        id: 8001
                    },
                    {
                        name: '肺动脉瓣区',
                        id: 8002
                    },
                    {
                        name: '主动脉瓣第二听诊区',
                        id: 8003
                    },
                    {
                        name: '心包摩擦音',
                        id: 8006
                    },
                    {
                        name: '三尖瓣区',
                        id: 8005
                    },
                    {
                        name: '二尖瓣区',
                        id: 8004
                    },
                ]

            },
        ];

        return {
            msubject: msubject,
            msoundSource: msoundSource,
            soundSourceDeletes: soundSoundDeletes,
            msoundSourceChangeStatus: msoundSourceChangeStatus,
            /*只有听诊点的按照id查询和删除*/
            soundPoint: soundPoint,
            /*根据听诊点id获取音源列表*/
            soundPointGetSource: soundPointGetSource,
            /*病例*/
            illCase: illCase,
            illCaseChangeStatus: illCaseChangeStatus,
            /*病例的添加和获取列表*/
            illCaseOrList: illCaseAddOrList,
            illDeletes: illDeletes,
            /*七牛资源*/
            qiniu: qiniu,
            qiniuImg: qiniuImg,
            qiniuSoundSourceUploadUrl: qiniuSoundSourceUploadUrl,
            qiniuHeartUrl: qiniuHeart,
            qiniuImgUrl: qiniuBaseImgUrl,
            getQiniuImgUrl: getQiniuImgUrl,
            //上传图片的方法
            uploadImgFile: uploadImgFile,
            //或者病例的听诊点列表
            localCaseImgUrlArr: localCaseImgUrlArr
        };

    }]);


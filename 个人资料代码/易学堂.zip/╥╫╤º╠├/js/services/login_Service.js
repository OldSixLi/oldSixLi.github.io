/**
 * Created by Axiny on 2016/8/4.
 */
'use strict';//严格模式

var app = angular.module("routerApp");
app.factory('loginService', [
        "$http",
        "$q",
        function($http,$q){
            var getLoginData = function(data){
                var defer = $q.defer();
                $http({
                    method: "POST",
                    headers:
                    {
                        "content-type":HEADERS.contentType
                    },
                    url:serviceURL + '/manager/' + data.name + '/token',
                    data: $.param({
                        password:data.password
                    })
                })
                    .success(function(data, status, headers, config){
                        var res = {
                            data:data,
                            status:status
                        };
                        defer.resolve(res);
                        //console.log("select data clear");
                    })
                    .error(function(data,status,headers,config){
                        var res = {
                            data:data,
                            status:status
                        };
                        defer.resolve(res);
                        //console.log("select data error");
                    });

                return defer.promise;
            };

            return {
                getLoginData : getLoginData
            };
        }
    ]
);
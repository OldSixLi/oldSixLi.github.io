angular.module("routerApp")
    .factory('loadingService', [function () {
       var loadingTemplate = '<div class="ng-loading"><i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i><span class="sr-only">Loading...</span></div>';
        var $loadingObj = $(loadingTemplate);
        $loadingObj.css({
            position: 'fixed',
            left: 0,
            top: 0,
            height: '100%',
            width: '100%',
            background: 'rgba(255, 255, 255, .2)',
            zIndex: 1000,
            display: 'none'
        });
        $loadingObj.children('i').css({

            position: 'fixed',
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%)'
        });

        $('body').append($loadingObj);

       return {
           show: function () {
              $loadingObj.show(100, function () {
                 $('body').css({
                     overflow: 'hidden'
                 });
              });
           },
           hide: function () {
               $loadingObj.hide(100, function () {
                   $('body').css({
                       overflow: 'auto'
                   });
               });
           }
       };
    }]);
/**
 * Created by Axiny on 2016/8/5.
 */
'use strict';//严格模式

var app = angular.module('routerApp');
app.factory('homeService',[
    "$http",   //注入$http
    "$q",      //注入$q
    "$state",
    function($http, $q, $state){
        /**
         * 获取首页字段数据
         */
        var getIndexData = function(){

            //if(localStorage.securityKey.length != 0){
                var defer = $q.defer();
                $http({
                    method:"GET",
                    headers:
                    {
                        "content-type":HEADERS.contentType,
                        "timestamp":HEADERS.timestamp,
                        "sign":HEADERS.sign("GET", $.param("")),
                        "accessKey":HEADERS.accessKey
                    },
                    url:serviceURL + "/mindex"
                    //url:"json/IndexData.json"
                })
                    .success(function(data,status, headers, config){
                        defer.resolve(data);
                        console.log("select IndexData clear");
                    })
                    .error(function(data,status,headers,config){
                        defer.resolve(data);
                        console.log("select IndexData error");
                    });
            //}
            //else{
            //    alert("您还未登录到系统中，请输入管理员信息进行登录");
            //    console.log("ERROR:login message is null");
            //    $state.go('login');
            //}

            return defer.promise;
        };


        //获取环形图数据
        var getChartData = function(){
            var defer = $q.defer();
            $http({
                method:"GET",
                url:"json/lineData.json"
            })
                .success(function(data,status, headers, config){
                    defer.resolve(data);
                    console.log("select data clear");
                })
                .error(function(data,status,headers,config){
                    defer.resolve(data);
                    console.log("select data error");
                });

            return defer.promise;
        };


        //返回函数接口
        return{
            getChartData:getChartData,
            getIndexData:getIndexData
            /*functionName:functionName*/
        }
    }
]);
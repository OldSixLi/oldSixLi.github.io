/**
 * Created by Axiny on 2016/8/3.
 */
'use strict';//严格模式
var app = angular.module('routerApp');

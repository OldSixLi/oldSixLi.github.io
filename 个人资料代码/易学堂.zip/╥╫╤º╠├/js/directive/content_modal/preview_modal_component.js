angular.module('routerApp')
    .component('previewModal', {
        templateUrl: './view/contentModel/preview_modal/preview_modal.html',
        controller: previewModalCtrl,
        bindings: {
            id: '@pmid',
            previewHtml: '<',
            data: '<'
        }
    });


previewModalCtrl.$inject = ['$sce', '$ocLazyLoad'];

function previewModalCtrl($sce, $ocLazyLoad) {

    /*加载预览的样式*/
    $ocLazyLoad.load('css/preview.css');

    this.$onChanges = function () {
        this.html = $sce.trustAsHtml(this.previewHtml);
    }
}
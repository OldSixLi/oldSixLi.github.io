angular.module('routerApp')
    .directive('ngMaxLength', function () {
        return {
            restrict: 'A',
            scope: {
                mlOptions: '='
            },
            link: function (scope, element, attrs) {
                $(element).maxlength({
                    alwaysShow: true,
                    warningClass: "label label-info",
                    limitReachedClass: "label label-warning"
                });
            }
        }
    });



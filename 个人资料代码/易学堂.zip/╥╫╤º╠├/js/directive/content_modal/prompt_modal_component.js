angular.module('routerApp')
    .component('promptModal', {
        templateUrl: './view/contentModel/prompt_modal/prompt_modal.html',
        controller: promptModalCtrl,
        bindings: {
            id: '@pmid',
            message: '<',
        }
    });

function promptModalCtrl() {
}
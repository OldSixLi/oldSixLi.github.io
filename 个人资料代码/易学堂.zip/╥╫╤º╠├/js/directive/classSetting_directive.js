/**
 * Created by Axiny on 2016/8/22.
 */
'use strict'//严格模式

var routerApp = angular.module('routerApp');

/**
 * Created by Axiny on 2016/9/8.
 */

/**
 * 性别
 * Sex.id  性别id
 * Sex.sex  性别
 */
var Sex = [
    {
        "id":0,
        "sex":"未设置"
    },
    {
        "id":1,
        "sex":"男"
    },
    {
        "id":2,
        "sex":"女"
    }
];

var Sex1 = [
    {
        "id":"",
        "sex":"性别不限"
    },
    {
        "id":0,
        "sex":"未设置"
    },
    {
        "id":1,
        "sex":"男"
    },
    {
        "id":2,
        "sex":"女"
    }
];

/**
 * 角色
 * Role.id  角色id
 * Role.role  角色名称
 * @type {*[]}
 */
var Role = [
    {
        "id":0,
        "role":"角色不限"
    },
    {
        "id":1,
        "role":"教师"
    },
    {
        "id":2,
        "role":"学生"
    },
    {
        "id":3,
        "role":"临床医师"
    },
    {
        "id":4,
        "role":"管理员"
    }
];
var Role1 = [
    {
        "id":1,
        "role":"教师"
    },
    {
        "id":2,
        "role":"学生"
    },
    {
        "id":3,
        "role":"临床医师"
    },
    {
        "id":4,
        "role":"管理员"
    }
];

/**
 * 部门状态
 * State.id  状态id
 * State.state  状态名称
 * @type {*[]}
 */
var State = [
    {
        "id":0,
        "state":"不限"
    },
    {
        "id":1,
        "state":"活跃"
    },
    {
        "id":2,
        "state":"解散"
    }
];

var State1 = [
    {
        "id":1,
        "state":"活跃"
    },
    {
        "id":2,
        "state":"已解散"
    }
];

/**
 * 消息推送状态
 * States.id  状态id
 * States.state  状态名称
 * @type {*[]}
 */
var States = [
    {
        "id":0,
        "state":"不限"
    },
    {
        "id":1,
        "state":"草稿"
    },
    {
        "id":2,
        "state":"未推送"
    },
    {
        "id":3,
        "state":"已推送"
    }

];

/**
 * 推送对象
 * Obj.id  对象id
 * Obj.state  对象名称
 * @type {*[]}
 */
var Obj = [
    {
        "id":0,
        "obj":"不限"
    },
    {
        "id":1,
        "obj":"教师"
    },
    {
        "id":2,
        "obj":"非教师"
    }
];
var Obj1 = [
    {
        "id":0,
        "obj":"全部"
    },
    {
        "id":1,
        "obj":"教师"
    },
    {
        "id":2,
        "obj":"非教师"
    }
];

/**
 * 手机型号
 * Type.id  手机型号id
 * Type.phoneType  手机型号名称
 * @type {*[]}
 */
var Type = [
    //{
    //    "id":0,
    //    "phoneType":"不限"
    //},
    {
        "id":1,
        "phoneType":"iPhone 5/5s"
    },
    {
        "id":2,
        "phoneType":"iPhone 6/6s/7"
    },
    {
        "id":3,
        "phoneType":"iPhone 6/6s Plus"
    },
    {
        "id":4,
        "phoneType":"Android 720p"
    },
    {
        "id":5,
        "phoneType":"Android 1080p"
    }
];
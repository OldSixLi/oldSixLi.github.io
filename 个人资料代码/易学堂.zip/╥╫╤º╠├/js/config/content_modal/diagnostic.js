angular.module('routerApp')
    .config(['$stateProvider', function ($stateProvider) {
        $stateProvider
            .state('main.sound',{
                url:"/sound",
                controller: 'diagnosticCtrl',
                templateUrl:"view/contentModel/diagnostics/index.html",
                resolve: {
                    loadCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        /*先加载服务*/
                        return $ocLazyLoad.load(['js/directive/content_modal/diagnostic_modal_component.js',
                            'js/directive/content_modal/preview_modal_component.js',
                            'js/directive/content_modal/prompt_modal_component.js', 'js/controller/content_modal/diagnostic_ctrl.js', 'js/directive/content_modal/max_length.directive.js',  'js/services/content_model_service.js','js/services/loading_Service.js'])
                    }]
                },
            })
            .state('main.sound.table', {
                url: '/table/:pointId/:pointName',
                templateUrl: 'view/contentModel/diagnostics/sound_table.html',
                controller: 'diagnosticTableCtrl',
                resolve: {
                    loadCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        return $ocLazyLoad.load('js/controller/content_modal/diagnostic_table_ctrl.js')
                    }]
                }
            })
            .state('main.sound.case', {
                url: '/case/:editId/:isView',
                controller: 'diagnosticCaseCtrl',
                templateUrl: 'view/contentModel/diagnostics/case.html',
                resolve: {
                    loadCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        return $ocLazyLoad.load(['css/case-preview.css', 'js/controller/content_modal/diagnostic_case_ctrl.js'])
                    }]
                }
            })
            .state('main.sound.soundSource', {
                url: '/soundsource/:editId/:isView',
                controller: 'diagnosticSoundSourceCtrl',
                templateUrl: 'view/contentModel/diagnostics/sound.html',
                resolve: {
                    loadCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        return $ocLazyLoad.load('js/controller/content_modal/diagnostic_sound_source_ctrl.js')
                    }]
                }
            });

        //if(!isLogin())
        //{
        //    $state.go('login');
        //}
    }])
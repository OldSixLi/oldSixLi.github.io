/**
 * Created by admin on 2016/11/15.
 */
//module.exports = {
//    'ACCESS_KEY': 'QDu65byrLAP28gngpv-wt-oUfbmGNij4Fj2Dd8hP',
//    'SECRET_KEY': 'EKrnYIA3kvBHu2J0KCE9dgnLZqkAfbh0TRKCgl8s',
//    'Bucket_Name': 'userpic',
//    'Port': 19110,
//    uptoken : 'QDu65byrLAP28gngpv-wt-oUfbmGNij4Fj2Dd8hP:VXXkj7FSMl7HcFH558XTUrki5lo=:eyJzY29wZSI6InVzZXJwaWMiLCJkZWFkbGluZSI6MTQ3OTMxNTg4Mn0=',
//    //'Uptoken_Url': '<Your Uptoken_Url>',
//    'Domain': 'http://ogos02i1z.bkt.clouddn.com/'
//}

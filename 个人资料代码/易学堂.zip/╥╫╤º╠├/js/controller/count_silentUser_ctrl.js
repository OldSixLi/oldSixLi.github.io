/**
 * Created by Axiny on 2016/8/31.
 */
var app = angular.module('routerApp');
app.controller('countSilentUserCtrl',[
    "$scope",
    "$state",
    "countService",
    function($scope,$state,countService){

        $('#dateTimePick1').datetimepicker({
            minView:"month",
            language:'zh-CN',
            bootcssVer:3,
            autoclose: true,
            todayBtn: "linked",
            pickerPosition: "bottom-left",
            todayHighlight : true,
            endDate : new Date()
        }).on('changeDate',function(e){
            var startTime = e.date;
            $('#dateTimePick2').datetimepicker('setStartDate',startTime);
        });
        $('#dateTimePick2').datetimepicker({
            minView:"month",
            language:'zh-CN',
            bootcssVer:3,
            autoclose: true,
            todayBtn: "linked",
            pickerPosition: "bottom-left",
            todayHighlight : true,
            endDate : new Date()
        }).on('changeDate',function(e){
            var endTime = e.date;
            //if(!$("#dateTimePick1").val()){
            //    alert("开始日期不能为空！");
            //    return false;
            //}
            $('#dateTimePick1').datetimepicker('setEndDate',endTime);
        });
    }
]);
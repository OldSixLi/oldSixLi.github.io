/**
 * Created by Axiny on 2016/8/31.
 */
var app = angular.module('routerApp');
app.controller('countNextDayKeepUserCtrl',[
    "$scope",
    "$state",
    "countService",
    function($scope,$state,countService){
        //预先声明echarts图的参数
        var xDate=[]; //chart X轴数据，即下面列表的数据的长度
        var legendData = []; //次日留存率
        var tetalData=[];//次日留存数量
        var startDate ="";
        var endDate = "" ;
        var periodType = 1;
        var tag = "tec";
        $('#dateTimePick1').datetimepicker({
            minView:"month",
            language:'zh-CN',
            autoclose: true,
            bootcssVer:3,
            todayBtn: "linked",
            pickerPosition: "bottom-left",
            todayHighlight : true,
            endDate : new Date()
        }).on('changeDate',function(e){
            var startTime = e.date;
            $('#dateTimePick2').datetimepicker('setStartDate',startTime);
        });
        $('#dateTimePick2').datetimepicker({
            minView:"month",
            language:'zh-CN',
            autoclose: true,
            bootcssVer:3,
            todayBtn: "linked",
            pickerPosition: "bottom-left",
            todayHighlight : true,
            endDate : new Date()
        }).on('changeDate',function(e){
            var endTime = e.date;
            //if(!$("#startDate").val()){
            //    alert("开始日期不能为空！");
            //    return false;
            //}
            $('#dateTimePick1').datetimepicker('setEndDate',endTime);
        });

        //js自动获取当前日期
        var seperator1 = "-";
        function getWantDate(date1){
            var date = new Date(date1 - 1 * 24 * 3600 * 1000);
            var year = date.getFullYear();
            var month = date.getMonth() + 1;
            var strDate = date.getDate();

            if (month >= 1 && month <= 9) {
                month = "0" + month;
            }
            if (strDate >= 0 && strDate <= 9) {
                strDate = "0" + strDate;
            }
            return year + seperator1 + month + seperator1 + strDate;
        }
        //js获取所给日期前n天的日期
        function getDayAgo(n,date){
            var curDate = new Date(Date.parse(date.replace(/-/g, "/")))
            var date1 = new Date(curDate - n * 24 * 3600 * 1000);
            var year1 = date1.getFullYear();
            var month1 = date1.getMonth() + 1;
            var day1 = date1.getDate();
            if (month1 >= 1 && month1 <= 9) {
                month1 = "0" + month1;
            }
            if (day1 >= 0 && day1 <= 9) {
                day1 = "0" + day1;
            }
            return year1 + seperator1 + month1 + seperator1 + day1;
        }

        $scope.newInfo= {
            "teacherSize": 0,
            "studentSize": 0,
            "mTeacherRetentionseList": [
                {
                    "retentionRateList": [
                        0
                    ],
                    "totalInstall": 0,
                    "installPeriod": ""
                }
            ],
            "mStudentRetentionsList": [
                {
                    "retentionRateList": [
                        0
                    ],
                    "totalInstall": 0,
                    "installPeriod": ""
                }
            ]
        };

        //获取日期
        function getDate(){
            if(!$('#endDate').val()){
                endDate = getWantDate(new Date());
            }else{
                endDate = $('#endDate').val();
            }
            if(!$('#startDate').val()){
                startDate = getDayAgo(7,getWantDate(new Date()));
            }else{
                startDate = $('#startDate').val();
            }
        }

        //预加载日期
        getDate();
        $scope.newParam={
            startDate:startDate,
            endDate:endDate,
            periodType:periodType
        };
        $scope.param={
            name:""
        };
        //预加载
        getdata();

        //点击获取非教师用户统计
        $scope.getStud = function() {
            //改变两按钮颜色
            $("#student_btn").removeClass("btn btn-default countBtn");
            $("#student_btn").addClass("btn btn-default countBtnCheck");
            $("#teacher_btn").removeClass("btn btn-default countBtnCheck");
            $("#teacher_btn").addClass("btn btn-default countBtn");
            getDate();
            tag = "stu";
            $scope.newParam = {
                startDate: startDate,
                endDate: endDate,
                periodType: periodType
            };
            getdata();
        }

        //点击查看按钮
        $scope.selectData = function() {
            getDate();
            $scope.newParam = {
                startDate: startDate,
                endDate: endDate,
                periodType: periodType
            };
            getdata();
        }

        //点击获取教师用户统计
        $scope.getTech = function() {
            //改变两按钮颜色
            $("#teacher_btn").removeClass("btn btn-default countBtn");
            $("#teacher_btn").addClass("btn btn-default countBtnCheck");
            $("#student_btn").removeClass("btn btn-default countBtnCheck");
            $("#student_btn").addClass("btn btn-default countBtn");
            getDate();
            tag = "tec";
            $scope.newParam = {
                startDate: startDate,
                endDate: endDate,
                periodType: periodType
            };
            getdata();
        }
        function  getdata() {
            //查看的数据
            xDate = [];
            legendData = [];
            tetalData=[];
        countService.getRetainedUser($scope.newParam).then(function(res){
            if (tag == "tec") {
            if(res.mTeacherRetentionseList!=null && res.mTeacherRetentionseList.length>0){
                for(var i= 0;i<res.mTeacherRetentionseList.length;i++){
                    legendData[i]=res.mTeacherRetentionseList[i].retentionRateList[0];
                    xDate[i] = res.mTeacherRetentionseList[i].installPeriod.replace(/-/g,'/');
                    tetalData[i]=res.mTeacherRetentionseList[i].totalInstall;
                }
                loadingEcharts(xDate,tetalData,legendData);
            }
            }else if (tag == "stu") {
                if(res.mStudentRetentionsList!=null && res.mStudentRetentionsList.length>0){
                    for(var i= 0;i<res.mStudentRetentionsList.length;i++){
                        legendData[i]=res.mStudentRetentionsList[i].retentionRateList[0];
                        xDate[i] = res.mStudentRetentionsList[i].installPeriod.replace(/-/g,'/');
                        tetalData[i]=res.mStudentRetentionsList[i].totalInstall;
                    }
                }
                loadingEcharts(xDate,tetalData,legendData);
            }
        });
    }
        function loadingEcharts(xDate,tetalData,legendData){
        var chart_class_DOM = $("#Chart");
        var chartView_class = echarts.init(chart_class_DOM[0],"YXT-chartStyle");//YXT-chartStyle：chart样式文件名称
        chartView_class.showLoading();
        var classData = {
            legend: {  //图例
                "x":"center",
                "y":"310px",
                "data":["新用户","次日留存率"]
            },
            xAxisDate:xDate,
            series: [
                {
                    name: '新用户',
                    type: 'bar',
                    yAxisIndex: 1,
                    barWidth: 60,//固定柱子宽度
                    label: {
                        normal: {
                            show: true,
                            position: 'insideRight'
                        }
                    },
                    data: tetalData
                },
                {
                    name: '次日留存率(%)',
                    type: 'line',
                    data: legendData,
                    yAxisIndex: 0,
                    itemStyle:
                    {
                        normal:{color:'#f17a40'}
                    }
                }
            ],
            grid: {  //图表绘制配置
                "x": 70,
                "y": 10,
                "x2": 40,
                "y2": 80,
                "backgroundColor": "rgba(0,0,0,0)",
                "borderWidth": 1,
                "borderColor": "#ccc"
            }
        };
        var chartView_line = getBarLineChart(classData);
        chartView_class.setOption(chartView_line);
        chartView_class.hideLoading();
    }
    }
]);
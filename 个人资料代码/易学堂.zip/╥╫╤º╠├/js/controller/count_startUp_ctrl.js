/**
 * Created by Axiny on 2016/8/31.
 */
var app = angular.module('routerApp');
app.controller('countStartUpCtrl',[
    "$scope",
    "$state",
    "countService",
    function($scope,$state,countService){
        //预先声明echarts图的参数
        var xDate=[]; //chart X轴数据，即下面列表的数据的长度
        var legendData = []; ///图例name
        var seriesData = []; //用于series option的数据
        var startDate ="";
        var endDate = "" ;
        var periodType = 1;
        var tag = "tec";
        $('#dateTimePick1').datetimepicker({
            minView:"month",
            language:'zh-CN',
            bootcssVer:3,
            autoclose: true,
            todayBtn: "linked",
            pickerPosition: "bottom-left",
            todayHighlight : true,
            endDate : new Date()
        }).on('changeDate',function(e){
            var startTime = e.date;
            $('#dateTimePick2').datetimepicker('setStartDate',startTime);
        });
        $('#dateTimePick2').datetimepicker({
            minView:"month",
            language:'zh-CN',
            bootcssVer:3,
            autoclose: true,
            todayBtn: "linked",
            pickerPosition: "bottom-left",
            todayHighlight : true,
            endDate : new Date()
        }).on('changeDate',function(e){
            var endTime = e.date;
            //if(!$("#startDate").val()){
            //    alert("开始日期不能为空！");
            //    return false;
            //}
            $('#dateTimePick1').datetimepicker('setEndDate',endTime);
        });

        //js自动获取当前日期
        var seperator1 = "-";
        function getWantDate(date1){
            var date = new Date(date1 - 1 * 24 * 3600 * 1000);
            var year = date.getFullYear();
            var month = date.getMonth() + 1;
            var strDate = date.getDate();

            if (month >= 1 && month <= 9) {
                month = "0" + month;
            }
            if (strDate >= 0 && strDate <= 9) {
                strDate = "0" + strDate;
            }
            return year + seperator1 + month + seperator1 + strDate;
        }
        function getWantDate1(date1){
            var date = new Date(date1);
            var year = date.getFullYear();
            var month = date.getMonth() + 1;
            var strDate = date.getDate();

            if (month >= 1 && month <= 9) {
                month = "0" + month;
            }
            if (strDate >= 0 && strDate <= 9) {
                strDate = "0" + strDate;
            }
            return year + seperator1 + month + seperator1 + strDate;
        }
        //js获取所给日期前n天的日期
        function getDayAgo(n,date){
            var curDate = new Date(Date.parse(date.replace(/-/g, "/")))
            var date1 = new Date(curDate - n * 24 * 3600 * 1000);
            var year1 = date1.getFullYear();
            var month1 = date1.getMonth() + 1;
            var day1 = date1.getDate();
            if (month1 >= 1 && month1 <= 9) {
                month1 = "0" + month1;
            }
            if (day1 >= 0 && day1 <= 9) {
                day1 = "0" + day1;
            }
            return year1 + seperator1 + month1 + seperator1 + day1;
        }

        //获取当前日期所在月的最后一天
        function getLastDay(date) {
            var curDate = new Date(Date.parse(date.replace(/-/g, "/")))
            var date1 = new Date(curDate);
            var new_year = date1.getFullYear(); //取当前的年份
            var new_month = date1.getMonth() + 1;//取下一个月的第一天，方便计算（最后一天不固定）

            if(new_month>12) {
                new_month -=12;        //月份减
                new_year++;            //年份增
            }
            var new_date = new Date(new_year,new_month,1);
            var new_day = new Date(new_date.getTime()-1000*60*60*24).getDate();
            if (new_month >= 1 && new_month <= 9) {
                new_month = "0" + new_month;
            }
            if (new_day >= 0 && new_day <= 9) {
                new_day = "0" + new_day;
            }
            return new_year + seperator1 + new_month + seperator1 + new_day;//取当年当月最后一天日期
        }

        $scope.newInfo={
            "teacherSize": 0,
            "studentSize": 0,
            "newTeacherList": [
                {
                    "num": 0,
                    "date": ""
                }
            ],
            "newStudentList": [
                {
                    "num": 0,
                    "date": ""
                }
            ]
        };
        //获取日期
        function getDate(){
            if(!$('#endDate').val()){
                endDate = getWantDate(new Date());
            }else{
                endDate = $('#endDate').val();
            }
            if(!$('#startDate').val()){
                startDate = getDayAgo(6,getWantDate(new Date()));
            }else{
                startDate = $('#startDate').val();
            }
        }

        //预加载日期
        getDate();
        $scope.newParam={
            startDate:startDate,
            endDate:endDate,
            periodType:periodType
        };
        $scope.param={
            name:""
        };
        //预加载
        getdata();

    //点击获取教师启动次数统计
        $scope.getTech = function() {
            //改变两按钮颜色
            $("#teacher_btn").removeClass("btn btn-default countBtn");
            $("#teacher_btn").addClass("btn btn-default countBtnCheck");
            $("#student_btn").removeClass("btn btn-default countBtnCheck");
            $("#student_btn").addClass("btn btn-default countBtn");
            getDate();
            tag = "tec";
            $scope.newParam = {
                startDate: startDate,
                endDate: endDate,
                periodType: periodType
            };
            getdata();
        }
        //点击获取非教师启动次数统计
        $scope.getStud = function() {
            //改变两按钮颜色
            $("#student_btn").removeClass("btn btn-default countBtn");
            $("#student_btn").addClass("btn btn-default countBtnCheck");
            $("#teacher_btn").removeClass("btn btn-default countBtnCheck");
            $("#teacher_btn").addClass("btn btn-default countBtn");
            getDate();
            tag = "stu";
            $scope.newParam = {
                startDate: startDate,
                endDate: endDate,
                periodType: periodType
            };
            getdata();
        }
        //点击查询按钮
        $scope.selectData = function() {
            getDate();
            $scope.newParam = {
                startDate: startDate,
                endDate: endDate,
                periodType: periodType
            };
            getdata();
        }
        //点击按日走的按钮
        $scope.dailyData = function() {
            $("#d_btn").removeClass("btn btn-default btn-xs");
            $("#d_btn").addClass("btn btn-default btn-xs btnCheck");
            $("#w_btn").removeClass("btn btn-default btn-xs btnCheck");
            $("#w_btn").addClass("btn btn-default btn-xs");
            $("#m_btn").removeClass("btn btn-default btn-xs btnCheck");
            $("#m_btn").addClass("btn btn-default btn-xs");
            getDate();
            periodType = 1;
            $scope.newParam = {
                startDate: startDate,
                endDate: endDate,
                periodType: periodType
            };
            getdata();
        }
        //点击按周走的按钮
        $scope.weekData = function() {
            $("#d_btn").removeClass("btn btn-default btn-xs btnCheck");
            $("#d_btn").addClass("btn btn-default btn-xs");
            $("#w_btn").removeClass("btn btn-default btn-xs");
            $("#w_btn").addClass("btn btn-default btn-xs btnCheck");
            $("#m_btn").removeClass("btn btn-default btn-xs btnCheck");
            $("#m_btn").addClass("btn btn-default btn-xs");
            getDate();
            periodType = 2;
            $scope.newParam = {
                startDate: startDate,
                endDate: endDate,
                periodType: periodType
            };
            getdata();
        }
        //点击按月走的按钮
        $scope.mounthData = function() {
            $("#d_btn").removeClass("btn btn-default btn-xs btnCheck");
            $("#d_btn").addClass("btn btn-default btn-xs");
            $("#w_btn").removeClass("btn btn-default btn-xs btnCheck");
            $("#w_btn").addClass("btn btn-default btn-xs");
            $("#m_btn").removeClass("btn btn-default btn-xs");
            $("#m_btn").addClass("btn btn-default btn-xs btnCheck");
            getDate();
            periodType = 3;
            $scope.newParam = {
                startDate: startDate,
                endDate: endDate,
                periodType: periodType
            };
            getdata();
        }

        function  getdata(){
            //查看的数据
            xDate = [];
            legendData = [];
            j=1;
            var tempDate = [];
            countService.getStartUpCount($scope.newParam).then(function(res){
                //预加载和点击教师按钮时候调用的echarts图
                if(tag =="tec"){
                    //$scope.addCountData = res.newTeacherList;
                    $scope.param={
                        name:"教师启动次数"
                    };
                    if(res.newTeacherList!=null && res.newTeacherList.length>0){
                        for(var i= 0;i<res.newTeacherList.length;i++){
                            xDate[i] = res.newTeacherList[i].date.substring(5).replace('-','/'); //只显示月份
                            tempDate[i] = res.newTeacherList[i].num;
                        }
                        //var mName = xDate[0]+'到'+xDate[xDate.length-1];
                        if(xDate[0]==xDate[xDate.length-1]){
                            var mName = xDate[0];
                        }else{
                            var mName = xDate[0]+'到'+xDate[xDate.length-1];
                        }
                    }else{
                        var mName = "暂无数据";
                    }
                    legendData[0] = mName;
                    seriesData[0] =
                    {
                        "name": mName,
                        "type": "line",
                        "data": tempDate,
                        itemStyle:{
                            normal:{
                                color:"#4096b5",
                                lineStyle:{
                                    color:"#4096b5",
                                    width:2
                                }
                            }
                        }
                    }
                    seriesData.length=1;
                    loadingEcharts(xDate);

                    //下方列表显示内容
                    $scope.addCountData = res.newTeacherList;
                    angular.forEach($scope.addCountData,function(item){
                        if(periodType == "2"){
                            item.date =item.date+"~"+getDayAgo(-6,item.date);
                        }else if(periodType == "3"){
                            item.date =item.date+"~"+getLastDay(item.date);
                        }
                    });
                }
                else if(tag =="stu"){
                    //$scope.addCountData = res.newStudentList;
                    $scope.param={
                        name:"非教师启动次数"
                    };
                    if(res.newStudentList!=null && res.newStudentList.length>0){
                        for(var i= 0;i<res.newStudentList.length;i++){
                            xDate[i] = res.newTeacherList[i].date.substring(5).replace('-','/'); //只显示月份
                            tempDate[i] = res.newStudentList[i].num;
                        }
                        //var mName = xDate[0]+'到'+xDate[xDate.length-1];
                        if(xDate[0]==xDate[xDate.length-1]){
                            var mName = xDate[0];
                        }else{
                            var mName = xDate[0]+'到'+xDate[xDate.length-1];
                        }
                    }else{
                        var mName = "暂无数据";
                    }
                    legendData[0] = mName;
                    seriesData[0] =
                    {
                        "name": mName,
                        "type": "line",
                        "data": tempDate,
                        itemStyle:{
                            normal:{
                                color:"#4096b5",
                                lineStyle:{
                                    color:"#4096b5",
                                    width:2
                                }
                            }
                        }
                    }
                    seriesData.length=1;
                    loadingEcharts(xDate);

                    //下方列表显示内容
                    $scope.addCountData = res.newTeacherList;
                    angular.forEach($scope.addCountData,function(item){
                        if(periodType == "2"){
                            item.date =item.date+"~"+getDayAgo(-6,item.date);
                        }else if(periodType == "3"){
                            item.date =item.date+"~"+getLastDay(item.date);
                        }
                    });
                }
            });
        }
        //选择日期对比时段
        function  DateDiff(sDate1,  sDate2) {    //sDate1和sDate2是2002-12-18格式
            var aDate, oDate1, oDate2, iDays
            aDate = sDate1.split("-")
            oDate1 = new Date(aDate[1] + '-' + aDate[2] + '-' + aDate[0])    //转换为12-18-2002格式
            aDate = sDate2.split("-")
            oDate2 = new Date(aDate[1] + '-' + aDate[2] + '-' + aDate[0])
            iDays = parseInt(Math.abs(oDate1 - oDate2) / 1000 / 60 / 60 / 24)    //把相差的毫秒数转换为天数
            return iDays
        }
        var choseDate = "";
        var startDate1 = "";
        var difDay = "";
        var j = 1;
        $( "#countDatePick" ).datetimepicker({
            minView:"month",
            language:'zh-CN',
            autoclose: false,
            bootcssVer:3,
            todayBtn: "linked",
            linkField:"mirror_field",//值反射域
            pickerPosition: "bottom-left",
            todayHighlight : true,
            endDate : new Date()
        }).on('changeDate',function(e){
            choseDate = e.date;
            if(periodType=="1") {
                if ($('#startDate').val()==""&&$('#endDate').val()=="") {
                    difDay="6"
                } else {
                    difDay = DateDiff(startDate, endDate);
                }
                startDate1 = getDayAgo(difDay,getWantDate1(choseDate));
            }else if(periodType=="2"){
                if ($('#startDate').val()==""&&$('#endDate').val()=="") {
                    difDay="6"
                } else {
                    difDay = DateDiff(startDate, endDate);
                }
                startDate1 = getDayAgo(difDay,getWantDate1(choseDate));
            }else if(periodType=="3"){
                if ($('#startDate').val()==""&&$('#endDate').val()=="") {
                    difDay="30"
                } else {
                    difDay = DateDiff(startDate, endDate);
                }
                startDate1 = getDayAgo(difDay,getWantDate1(choseDate));
            }
            var showCompareDate = startDate1 +"~"+getWantDate1(choseDate);
            $("#showCompareDate").val(showCompareDate);
        });
        document.querySelector('#compareDate').onclick=function(){
            $(".myEndDateBody").css('display','block');
        };
        document.querySelector('#myEndDateSubmit').onclick=function(){

            if(checkDate(getWantDate1(choseDate))){
                $scope.newParam={
                    startDate:startDate1,
                    endDate:getWantDate1(choseDate),
                    periodType:periodType
                };
                if(j<=7){
                    getConpareData(j);
                    j++;
                }else{
                    //$scope.promptMessage = "对比时间段不能超过八次！";
                    $("#promptMes_model5").modal("show");
                }
            }else{
                //$scope.promptMessage= "该时间段已选择，请选择不同的时间段做对比!";
                $("#promptMes_model6").modal("show");
            }
            $(".myEndDateBody").css('display','none');
            //alert($("#mirror_field").val());
        };
        $scope.myCountDatePick=$("#mirror_field").val();

        function checkDate(endDate){
            for (var i=0;i<legendData.length;i++){
                if(legendData[i].substring((legendData[i].length-5),legendData[i].length)==endDate.substring(5).replace('-','/')){
                    return false;
                }
            }
            return true;
        }
        //js获取随机颜色
        var getRandomColor = function(j){
            //return '#'+('00000'+(Math.random()*0x1000000<<0).toString(16)).substr(-6);
            var colorList = ['#C1232B','#B5C334','#FCCE10','#E87C25','#27727B',
                '#FE8463','#9BCA63','#FAD860','#F3A43B','#60C0DD',
                '#D7504B','#C6E579','#F4E001','#F0805A','#26C0C0'
            ];
            var  newColor = colorList[j];
            return newColor
        }
        function  getConpareData(j) {

            countService.getStartUpCount($scope.newParam).then(function (res) {
                var corlor = getRandomColor(j);
                //预加载和点击教师按钮时候调用的echarts图
                var tempData = [];
                if (tag == "tec") {
                    if (res.newTeacherList != null && res.newTeacherList.length > 0) {
                        for (var i = 0; i < res.newTeacherList.length; i++) {
                            tempData[i] = res.newTeacherList[i].num;
                        }
                        var mName = res.newTeacherList[0].date.substring(5).replace('-','/')+"到"+res.newTeacherList[res.newTeacherList.length-1].date.substring(5).replace('-','/');
                    }else{
                        var mName = "暂无数据";
                    }
                    legendData[j] = mName;
                    seriesData[j] =
                    {
                        "name": mName,
                        "type": "line",
                        "data": tempData,
                        itemStyle:{
                            normal:{
                                color:corlor,
                                lineStyle:{
                                    color:corlor,
                                    width:2
                                }
                            }
                        }
                    }
                    seriesData.length=j+1;
                    loadingEcharts(xDate)
                }

                else if (tag == "stu") {
                    if (res.newStudentList != null && res.newStudentList.length > 0) {
                        for (var i = 0; i < res.newStudentList.length; i++) {
                            tempData[i] = res.newStudentList[i].num;
                        }
                        var mName = res.newTeacherList[0].date.substring(5).replace('-','/')+"到"+res.newTeacherList[res.newTeacherList.length-1].date.substring(5).replace('-','/');
                    }else{
                        var mName = "暂无数据";
                    }
                    legendData[j] = mName;
                    seriesData[j] =
                    {
                        "name": mName,
                        "type": "line",
                        "data": tempData,
                        itemStyle:{
                            normal:{
                                color:corlor,
                                lineStyle:{
                                    color:corlor,
                                    width:2
                                }
                            }
                        }
                    }
                    seriesData.length=j+1;

                    loadingEcharts(xDate)
                }
            });
        }

        function loadingEcharts(xDate){
            var chart_class_DOM = $("#Chart");
            var chartView_class = echarts.init(chart_class_DOM[0], "YXT-chartStyle");//YXT-chartStyle：chart样式文件名称
            chartView_class.showLoading();
            var classData = {
                legend: {  //图例
                    "x": "center",
                    "y": "310px",
                    "data": legendData
                },
                xAxisDate: xDate,
                series: seriesData,
                grid: {  //图表绘制配置
                    "x": 70,
                    "y": 15,
                    "x2": 50,
                    "y2": 80,
                    "backgroundColor": "rgba(0,0,0,0)",
                    "borderWidth": 1,
                    "borderColor": "#ccc"
                }
            };
            var chartView_line = getLineChart(classData);
            chartView_class.setOption(chartView_line);
            chartView_class.hideLoading();
        }
    }
]);
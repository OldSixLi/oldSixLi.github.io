/**
* Created by Axiny on 2016/8/1.
*/
'use strict';//严格模式

var app = angular.module('routerApp');
app.controller('homeCtrl',[
    //注入部分
    "$scope",
    "$state",
    'homeService',
    function($scope,$state,homeService){

        $scope.indexData = {
            "newTeacherNum": 0,
            "totalTeacherNum": 0,
            "teacherStartNum": 0,
            "newStudentNum": 0,
            "totalStudentNum": 0,
            "studentStartNum": 0,
            "newGroupNum": 0,
            "totalGroupNum": 0,
            "newCourseNum": 0,
            "totalCourseNum": 0
        };

        homeService.getIndexData().then(function(res){
            $scope.indexData = res;

            var chart_class_DOM = $("#Chart-class");
            var chartView_class = echarts.init(chart_class_DOM[0],"YXT-chartStyle");//YXT-chartStyle：chart样式文件名称
            chartView_class.showLoading();                                  //当数据加载
            var classData = {
                name:"'群组/班级占比'",
                legend: {
                    orient: 'vertical',
                    x: 'left',
                    data:['总群组/班级','今日新增群组/班级']
                },
                data:
                    [
                        {
                            value:res.totalGroupNum,
                            name:'总群组/班级',
                            itemStyle:
                            {
                                normal:{color:'#C9C9C9'}
                            }
                        },
                        {
                            value:res.newGroupNum,
                            name:'今日新增群组/班级',
                            itemStyle:
                            {
                                normal:{color:'#9954cc'}
                            }
                        }
                    ]
            };
            var pie_class = getPieChart(classData);
            chartView_class.setOption(pie_class);
            chartView_class.hideLoading();

            var chart_mission = $("#Chart-mission");
            var chartView_mission = echarts.init(chart_mission[0],"YXT-chartStyle");
            chartView_mission.showLoading();
            var missionData = {
                name:"'课程/任务占比'",
                legend: {
                    orient: 'vertical',
                    x: 'left',
                    data:['总课程/任务','今日新增课程/任务']
                },
                data:
                    [
                        {
                            value:res.totalCourseNum ,
                            name:'总课程/任务',
                            itemStyle:
                            {
                                normal:{color:'#C9C9C9'}
                            }
                        },
                        {
                            value:res.newCourseNum ,
                            name:'今日新增课程/任务',
                            itemStyle:
                            {
                                normal:{color:'#9954cc'}
                            }
                        }
                    ]

            };

            var pie_missionData = getPieChart(missionData);
            chartView_mission.setOption(pie_missionData);
            chartView_mission.hideLoading();

        });
    }
]);

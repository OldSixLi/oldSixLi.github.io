/**
 * Created by Axiny on 2016/8/31.
 */
var app = angular.module('routerApp');
app.controller('countWeekUserCtrl',[
    "$scope",
    "$state",
    "countService",
    function($scope,$state,countService){


    }
]);
/**
 * Created by Axiny on 2016/8/11.
 */
'use strict';//严格模式

var app = angular.module('routerApp');
app.controller('classSettingCtrl',[
    "$scope",
    "$state",
    "classSettingService",
    "userSettingService",
    "classPageInfo",
    'pageInfo',
    function($scope,$state,classSettingService,userSettingService,classPageInfo,pageInfo){

        //群组状态,搜索
        $scope.State = State;

        //群组状态
        $scope.State1 = State1;

        //角色
        $scope.Role1 = Role1;
        $scope.Role = Role;

        //性别
        $scope.Sex = Sex;

        //按条件搜索用户类
        $scope.selectClassList =
            {
                "key":"",
                "state":0
            };

        //翻页配置类
        $scope.paginationConf =
            {
                currentPage: 0,     //初始页码
                itemsPerPage: 10,   //每页显示条目
                totalItems: 0     //总条目数
            };

        //获取群组信息
        $scope.groupInfo ={
            "totalNum": 0,
            "mGroupList": [
                {
                    "id": 0,
                    "imId": "",
                    "name": "",
                    "mTeacher": {
                        "id": 0,
                        "name": ""
                    },
                    "memberNum": 0,
                    "state": 0,
                    "classState":"",
                    "createDate": "",
                    "lastMsgTime": ""
                }
            ]
        };

        //验证
        $scope.erroMsg ="";
        var length = 0;
        var reg =/^[\u4e00-\u9fa5]+$/;
        var reg1=/^[0-9a-zA-Z_]+$/;
        $("#groupName").blur(function(){
            length = 0;
            var name =$("#groupName").val();
            for(var i=0;i<name.length;i++){
                var str = name.substr(i,1);
                if((reg.test(str))||(reg1.test(str))){
                    if(reg.test(str)){
                        length = parseInt(length)+parseInt(2);
                    }else if(reg1.test(str)){
                        length =parseInt(length)+parseInt(1);
                    }
                }else{
                    $scope.erroMsg ="群组名称格式输入不正确！";
                }
            }
            if (parseInt(length) >20){
                $("#showErro").html("输入已超过20个字符!");
            }else{
                $("#showErro").html("");
            }
        });

        //群组 GET Parameters
        $scope.paramGroupData =
            {
                page:$scope.paginationConf.currentPage,
                pageNum:$scope.paginationConf.itemsPerPage,
                key:"",
                state:0
            };
        var pageClassFlag ="Y";
        var classState = "";
        getClassList(pageClassFlag);
        $scope.getGroupData = function(page){
            //$scope.paramGroupData.page = page;
            $scope.paramGroupData = {
                page:page != 0 ? page - 1 : 0,
                pageNum:$scope.paginationConf.itemsPerPage,
                key:$scope.selectClassList.key,
                state:$scope.selectClassList.state
            };
            pageClassFlag ="N";
            getClassList(pageClassFlag);
        };
        //根据条件查询群组信息
        $scope.selectGroup = function(){
            $scope.paramGroupData.page = 1;
            $scope.paramGroupData = {
                page:0,
                pageNum:$scope.paginationConf.itemsPerPage,
                key:$scope.selectClassList.key,
                state:$scope.selectClassList.state
            }
            pageClassFlag="Y1";
            getClassList(pageClassFlag);
        };
        //获取群组数据
        function getClassList(pageClassFlag){
            $scope.select_all = false;
            classSettingService.getClassData($scope.paramGroupData).then(function(res){
                if(pageClassFlag=="Y"){
                    $scope.groupDetail = res;
                }
                var classData=[];
                if (res.mGroupList != null && res.mGroupList.length > 0){
                    for (var i = 0; i < res.mGroupList.length; i++) {
                        switch (res.mGroupList[i].state) {
                            case 0:
                            {
                                classState = "不限";
                                break;
                            }
                            case 1:
                            {
                                classState = "活跃";
                                break;
                            }
                            case 2:
                            {
                                classState = "解散";
                                break;
                            }
                            default :
                            {
                                break;
                            }
                        }
                        classData[i] = {
                            id:res.mGroupList[i].id,
                            imId: res.mGroupList[i].imId,
                            name:res.mGroupList[i].name,
                            mTeacher: {
                                id: res.mGroupList[i].mTeacher.id,
                                name: res.mGroupList[i].mTeacher.name
                            },
                            memberNum:res.mGroupList[i].memberNum,
                            state: res.mGroupList[i].state,
                            createDate: res.mGroupList[i].createDate,
                            lastMsgTime: res.mGroupList[i].lastMsgTime,
                            classState:classState
                        }
                    }
                }
                $scope.classData =classData;
                if(classData.length > 0){
                    $(".message_content").css('display','block');
                    $(".message_contentNo").css('display','none');
                }else{
                    $(".message_contentNo").css('display','block');
                    $(".message_content").css('display','none');
                }
                if(pageClassFlag =="Y" || pageClassFlag=="Y1"){
                    $scope.paginationConf =
                        {
                            currentPage: 1,     //初始页码
                            itemsPerPage: 10,   //每页显示条目
                            totalItems: res.totalNum       //总条目数
                        };
                }else{
                    $scope.paginationConf =
                        {
                            itemsPerPage: 10,   //每页显示条目
                            totalItems: res.totalNum       //总条目数
                        };
                }
            });
        }
        //获取总条目数
        $scope.paginationConf.totalItems = classPageInfo.totalNum;


        //群组模态框配置类
        $scope.modalData =
            {
                "modalName":"",
                "id":"",
                "name":"",
                "mTeacher": {
                    "id": 0,
                    "name": ""
                },
                "memberNum":"",
                "memberData" :"",
                "state": 0
            };


        //通过ID删除群组
        $scope.deleteGroupForID = function(){
            var  deleteOneGroup= {
                gid:$scope.modalData.id
            }
            classSettingService.deleteClassForID(deleteOneGroup).then(function(res){
                if(res.status=="202"){
                    getClassList(pageClassFlag);
                    $("#deleteUserForId_model").modal("hide");
                }else{
                    //alert(res.data.message);
                    $scope.promptMes=res.data.message;
                    $('#messages_model').modal('show');
                }
            });
        };

        $scope.deleteTheGroup  = function(classlist){
            $scope.modalData.id = classlist.id;
        };

        //复选框全选或者反选
        $scope.select_all = false;
        $scope.choseAllArr=[];//定义数组用于存放全选数组
        $scope.choseSomeArr=[];//定义数组用于存放所选数组
        $scope.selectAll = function (c) {
            $scope.choseAllArr = [];
            if(c==true) {
                angular.forEach($scope.classData, function(groupIdList) {
                    groupIdList.status = true;
                    $scope.choseAllArr.push(groupIdList.id);
                })
            }else {
                angular.forEach($scope.classData, function(groupIdList) {
                    groupIdList.status = false;
                })
            }
        };
        $scope.checkChose = function (check) {
            var count = 0;
            if(check == true) {
                for(var i = 0; i < $scope.classData.length; i++){
                    if($scope.classData[i].status){
                        count++
                    }
                }
                if(count == $scope.classData.length){
                    $scope.select_all = true
                }
            }else {
                $scope.select_all = false;
            }
        };
        //批量删除群组
        var delArray = "";
        $scope.deleteSelecteUser = function() {
            delArray = "";
            angular.forEach($scope.classData, function(groupIdList){
                if(groupIdList.status){
                    delArray += "gids=" + groupIdList.id + "&"
                }
            });
            var newstr1 = delArray.substring(0, delArray.length - 1);
            if(newstr1.length != 0){
                $("#deleteUser_model").modal("show");
            }else{
                //alert("至少选择一项删除！");
                $scope.promptMes="至少选择一项删除！";
                $('#messages_model').modal('show');
                $("#deleteUser_model").modal("hide");
            }
        }
        $scope.deleteClass = function(){
            $scope.select_all = false;
            var newStr = delArray.substring(0, delArray.length - 1);
            classSettingService.deleteClass(newStr).then(function(res){
                if(res.status=="202"){
                    getClassList(pageClassFlag);
                    $("#deleteUser_model").modal("hide");
                }else{
                    //alert(res.data.message);
                    $scope.promptMes=res.data.message;
                    $('#messages_model').modal('show');
                }
            });
        };


        //获取对应群组用户列表
        $scope.groupMemberList ={
            "mGroupMemberList": [
                {
                    "picPath": "",
                    "name": "",
                    "mobilePhone": "",
                    "role": 0,
                    "sex": 0,
                    "regDate": "",
                    "departIdLevelOne": 0,
                    "departId": 0,
                    "id": 0
                }
            ],
            "totalNum": 0
        }
        //获取群组人员的预声明
        var getMemberData ={
            gid:"",
            page:0,
            pageNum:100
        }
        //初始化修改群组信息+获取该群组员显示
        $scope.getUpdateGroup = function(classlist){
            $scope.erroMsg ="";
            $scope.inputStyle = "userCheckOFF";
            $scope.modalData.modalName = "编辑群组";
            $scope.modalData.id = classlist.id;
            $scope.modalData.name = classlist.name;
            $scope.modalData.mTeacher.name = classlist.mTeacher.name;
            $scope.modalData.state = classlist.state;
            $scope.modalData.memberData = classlist.memberData;
            getMemberData ={
                gid:classlist.id,
                page:0,
                pageNum:100
            }
            if(classlist.state  != 2){
                getClassUser(getMemberData,"Y");
            }else{
                $scope.memberDataList = null;
            }
        };

        //获取、刷新群组成员列表
        var classUserListData = "";
        //该对象用于群组成员列表显示
        $scope.modalData.mTeacher.id ="";
        function getClassUser(data,getMemberFlag){
            $scope.modalData.mTeacher.id ="";
            if(getMemberFlag=="Y"){
                classSettingService.getGroupMember(data).then(function(res) {
                    if(res.status=="200"){
                        $scope.memberDataList = res.data.mGroupMemberList;
                        if (res.data.mGroupMemberList != null && res.data.mGroupMemberList.length > 0) {
                            for (var i = 0; i < res.data.mGroupMemberList.length; i++) {
                                $scope.modalData.mTeacher.id += res.data.mGroupMemberList[i].id+'&';
                            }
                        }
                    }else{
                        //alert (res.data.message);
                        $scope.promptMes=res.data.message;
                        $('#messages_model').modal('show');
                    }
                });
            }else{
                var userListData=[];
                //classUserListData = data.substring(0, data.length - 1); //这是一字符串
                classUserListData = data.substring(0,data.length-1);
                var classUserList1= new Array(); //定义一数组
                classUserList1=classUserListData.split("&"); //字符分割
                for (var i=0;i<classUserList1.length ;i++ )
                {
                    userListData[i] ={
                        id:classUserList1[i],
                        "picPath": "",
                        "name": "",
                        "mobilePhone": "",
                        "role": 0,
                        "sex": 0,
                        "regDate": "",
                        "departIdLevelOne": 0,
                        "departId": 0
                    }
                }
                $scope.memberDataList = userListData;
                angular.forEach($scope.memberDataList,function(item){
                    userSettingService.showUserData(item.id).then(function(res){
                        if(res.status=="200"){
                            item.name = res.data.realname;
                            item.picPath = res.data.picPath;
                            //item.mobilePhone = res.data.mobilePhone;
                            //item.role = res.data.role;
                            //item.regDate = res.data.regDate;
                        }else{
                            //alert(res.data.message);
                            $scope.promptMes=res.data.message;
                            $('#messages_model').modal('show');
                        }
                    });
                });
            }
        }
        //编辑群组时，选择用户
        var tag1 = "";       //判定当前是否为添加新用户至群组
        var tag2 = "";       //判定当前是否为 勾选查找用户
        var tag3 = "";       //判定当前是否为删除用户
        var addOneArray = "";//群组添加新成员
        var addArray = "";//群组添加成员list
        var delArray = "";  //群组删除成员list
        $("#selectUser").click(function(){
            $scope.addUser.modalName1 = "selectUser";
            tag2 = "selectUser";
        });

        $("#addUser").click(function(){
            $scope.addUser.modalName1 = "addNewUser";
            tag1 = "addNewUser";
        });

        //批量删除群成员
        //默认checkbox为隐藏状态
        $scope.inputStyle = "userCheckOFF";

        //更改checkbox为显示状态
        $scope.showCheck = function(){
            $scope.inputStyle = "userCheckON";
            tag3 = "deleteUser";
        };

        //点击新增群组用户的按钮
        $scope.addGroupUser = function(gid1){
            $scope.modalData.id = gid1;
            $scope.addUser.modalName1 = "selectUser";
            tag2 = "selectUser";
        };
        //用户  GET parameters
        //翻页配置类
        $scope.paginationConf1 =
            {
                currentPage: 0,     //初始页码
                itemsPerPage: 10,   //每页显示条目
                totalItems: 0       //总条目数
            };
        $scope.paramUserData =
            {
                page:$scope.paginationConf1.currentPage,
                pageNum:$scope.paginationConf1.itemsPerPage,
                key:"",
                role:0,
                sex:0,
                regstartDate:"",
                regendDate:""
            };
        //获取用户信息
        $scope.userInfo ={
            "totalNum": 0,
            "mUserList": [
                {
                    "id": 0,
                    "mobilePhone": "",
                    "role": 0,
                    "realname": "",
                    "sex": 0,
                    "regDate": "",
                    "picPath": "img/userImg404.png",
                    "departIdLevelOne": 0,
                    "departId": 0,
                    "peopleRole":""
                }
            ]
        };
        //获取用户数据
        var pageFlag ="Y";
        var peopleRole = "";
        getUserList(pageFlag);

        //选择用户的搜索功能
        $scope.selectUserForClass = function(){
            $scope.paramUserData.page = 1;
            $scope.paramUserData= {
                page:0,
                pageNum:$scope.paginationConf1.itemsPerPage,
                key:$scope.paramUserData.key,
                role:$scope.paramUserData.role,
                sex:"",
                regstartDate:"",
                regendDate:""
            };
            getUserList(pageFlag);
        };

        //点击页码的翻页功能
        $scope.getUserData1 = function(page){
            //$scope.paramUserData.page = page;
            $scope.paramUserData = {
                page:page != 0 ? page - 1 : 0,
                pageNum:$scope.paginationConf1.itemsPerPage,
                key:$scope.paramUserData.key,
                role:$scope.paramUserData.role,
                sex:"",
                regstartDate:"",
                regendDate:""
            };
            pageFlag ="N";
            getUserList(pageFlag);
        };
        function  getUserList(pageFlag){
            userSettingService.getUserData($scope.paramUserData).then(function(res){
                var userData=[];
                if (res.mUserList != null && res.mUserList.length > 0){
                    for (var i = 0; i < res.mUserList.length; i++) {
                        switch (res.mUserList[i].role) {
                            case 0:
                            {
                                peopleRole = "角色不限";
                                break;
                            }
                            case 1:
                            {
                                peopleRole = "教师";
                                break;
                            }
                            case 2:
                            {
                                peopleRole = "学生";
                                break;
                            }
                            case 3:
                            {
                                peopleRole = "临床医生";
                                break;
                            }
                            case 4:
                            {
                                peopleRole = "管理员";
                                break;
                            }
                            default :
                            {
                                break;
                            }
                        }
                        userData[i] = {
                            id: res.mUserList[i].id,
                            mobilePhone: res.mUserList[i].mobilePhone,
                            role: res.mUserList[i].role,
                            realname: res.mUserList[i].realname,
                            sex: res.mUserList[i].sex,
                            regDate: res.mUserList[i].regDate,
                            picPath: res.mUserList[i].picPath,
                            departIdLevelOne: res.mUserList[i].departIdLevelOne,
                            departId: res.mUserList[i].departId,
                            peopleRole:peopleRole
                        }
                    }
                }
                $scope.userDetail = userData;
                if(pageFlag =="Y"){
                    $scope.paginationConf1 =
                        {
                            currentPage: 1,     //初始页码
                            itemsPerPage: 10,   //每页显示条目
                            totalItems: res.totalNum       //总条目数
                        };
                }else{
                    $scope.paginationConf1 =
                        {
                            itemsPerPage: 10,   //每页显示条目
                            totalItems: res.totalNum       //总条目数
                        };
                }
            });
        }
        //获取总条目数
        //$scope.paginationConf1.totalItems = pageInfo.totalNum;

        //为群组新增用户
        //添加新用户并添加至当前群组
        $scope.addUser =
            {
                "modalName":"",
                "mobilePhone":"",
                "id":"",
                "password":"e99a18c428cb38d5f260853678922e03",
                "role":1,
                "realname":"",
                "sex":0,
                "departIdLevelOne ":"",
                "departId ":"",
                "picPath":"img/userImg404.png"
            };
        //初始化添加用户
        $scope.createAddUser = function(){
            $scope.addUser.mobilePhone = "";
            $scope.addUser.role = 1;
            $scope.addUser.realname = "";
            $scope.addUser.sex = 0;
            $scope.addUser.departIdLevelOne = "";
            $scope.addUser.departId = "";
            $scope.addUser.picPath = "img/userImg404.png";

            //获取科室
            var paramFirDepart =
                {
                    name:'',
                    level:1,
                    page:0,
                    pageNum:100
                }
            //获取一级科室
            userSettingService.getFirstDepName(paramFirDepart).then(function(res){
                $scope.FirstDepName = res.departList;
                if (res.departList != null && res.departList.length > 0) {
                    for (var i = 0; i < res.departList.length; i++) {
                        var secPid= res.departList[0].id;
                    }
                }
                var paramSecDepart =
                    {
                        page:0,
                        pageNum:100,
                        did:secPid
                    }
                //获取二级科室
                userSettingService.getSecondDepName(paramSecDepart).then(function(res){
                    $scope.SecondDepName = res.departList;
                });
            });
        };
        //当一级科室发生变化时获取二级科室
        $scope.getDepartmentTwo = function(){
            var paramSecDepart =
                {
                    page:0,
                    pageNum:100,
                    did:$scope.addUser.departIdLevelOne
                }
            userSettingService.getSecondDepName(paramSecDepart).then(function(res){
                $scope.SecondDepName = res.departList;
            });
        };

        //获取需要添加的用户至list
        var addArray2 ="";
        var selectUserList ="";//定义一个全局变量，来存选择的用户
        $scope.addUserInClass = function(){
            //先清空id的Array，再往里面存值
            addArray = "";
            addArray2 = "";
            switch ($scope.addUser.modalName1){
                //选择用户 存用户ids数组
                case "selectUser":{
                    angular.forEach($scope.userDetail, function(userIdList) {
                        if (userIdList.status) {
                            addArray += userIdList.id + "&"
                            addArray2 += "ids=" + userIdList.id + "&"
                        }
                    });
                    selectUserList = addArray;
                    var addArray1=addArray+$scope.modalData.mTeacher.id
                    getClassUser(addArray1,"N");
                    break;
                }
                //新增用户 存该用户id
                case "addNewUser":{
                    addOneArray ="";
                    var picPath1 ="";
                    var userDepId1 ="";
                    if($scope.addUser.picPath==null||$scope.addUser.picPath==""){
                        picPath1 = "img/userImg404.png";
                    }else{
                        picPath1 = $scope.addUser.picPath;
                    }
                    if($scope.addUser.departId==""||$scope.addUser.departId==null){
                        userDepId1 = $scope.addUser.departIdLevelOne;
                    }else{
                        userDepId1 = $scope.addUser.departId;
                    }
                    var  addNewUserDate= {
                        mobilePhone:$scope.addUser.mobilePhone,
                        role:$scope.addUser.role,
                        password:$scope.addUser.password,
                        realname:$scope.addUser.realname,
                        sex:$scope.addUser.sex,
                        picPath:picPath1,
                        departId:userDepId1
                    }
                    userSettingService.addUser(addNewUserDate).then(function(res){
                        if(res.status=="200"){
                            addOneArray = res.data.id;
                            var addOneArray1=res.data.id +'&'+$scope.modalData.mTeacher.id;
                            getClassUser(addOneArray1,"N");
                        }else{
                            //alert(res.data.message);
                            $scope.promptMes=res.data.message;
                            $('#messages_model').modal('show');
                        }
                    });
                    break;
                }
            }
        };
        //查看成员详细信息
        $scope.userInfoDet = {
            id: 0,
            mobilePhone: "",
            role: 0,
            realname: "",
            sex: 0,
            regDate: "",
            lastLoginTime: "",
            picPath:"",
            departIdLevelOne: 0,
            departId: 0,
            peopleRole:"",
            peopleSex:"",
            peopleDep1:""
        }
        //预先声明 角色、科室、性别的保存字段
        var peopleDep1 = "";
        var peopleSex1 = "";
        var peopleRole1 = "";
        //判断角色
        function roleSwitch(data){
            switch (data) {
                case 0:{
                    peopleRole1="角色不限";
                    break;
                }
                case 1:{
                    peopleRole1="教师";
                    break;
                }
                case 2:{
                    peopleRole1="学生";
                    break;
                }
                case 3:{
                    peopleRole1="临床医生";
                    break;
                }
                case 4:{
                    peopleRole="管理员";
                    break;
                }
                default :{
                    break;
                }
            }
        }

        //判断性别
        function sexSwitch(data){
            switch (data) {
                case 0:{
                    peopleSex1="未设置";
                    break;
                }
                case 1:{
                    peopleSex1="男";
                    break;
                }
                case 2:{
                    peopleSex1="女";
                    break;
                }
                default :{
                    break;
                }
            }
        }
        //获得部门
        function getUserDep(data){
            var dpId = {
                id: data
            };
            var level = 0;
            var level1_pid = 0;
            userSettingService.getPeopleDepName(dpId).then(
                function(res){
                    $scope.userInfoData.peopleDep1 = res.name;
                    level = res.level;
                    level1_pid = res.pid != null && res.pid != undefined ? res.pid : null;
                    if(level == 2){
                        var _pid = {
                            id:res.pid
                        };
                        userSettingService.getPeopleDepName(_pid).then(
                            function (res) {
                                $scope.userInfoData.peopleDep1 = res.name + " " + $scope.userInfoData.peopleDep1;
                            }
                        )
                    }
                });
        }


        $scope.getUserInfoDet = function(data){
            userSettingService.showUserData(data.id).then(function(res){
                //角色判断
                roleSwitch(res.data.role);
                //性别判断
                sexSwitch(res.data.sex);

                //人员第二部门判断
                if(res.data.departId != 0&&typeof (res.data.departId)!='undefined'){
                    getUserDep(res.data.departId)
                }else if(res.data.departIdLevelOne != 0&&typeof (res.data.departIdLevelOne)!='undefined'){
                    getUserDep(res.data.departIdLevelOne)
                }else{
                    peopleDep1 = "暂无科室";
                }
                var userData = {
                    id: res.data.id,
                    mobilePhone: res.data.mobilePhone,
                    role: res.data.role,
                    realname: res.data.realname,
                    sex: res.data.sex,
                    regDate: res.data.regDate,
                    lastLoginTime: res.data.lastLoginTime,
                    picPath: res.data.picPath,
                    departIdLevelOne: res.data.departIdLevelOne,
                    departId: res.data.departId,
                    peopleRole1:peopleRole1,
                    peopleSex1:peopleSex1,
                    peopleDep1:peopleDep1
                };
                $scope.userInfoData = userData;
            });
        }


        //保存编辑群组信息和人员
        $scope.saveClass = function(){
            //编辑状态
            //var update = {
            //    add:"",
            //    del:"",
            //    updateClass:""
            //};
            //群组信息筛选上传
            //var classData = {
            //    gid:"",
            //    name:"",
            //    "mTeacher": {
            //        "id": 0,
            //        "name": ""
            //    },
            //    state:""
            //};
            $scope.select_all = false;
            var flag ="";
            //自己新增用户保存到群组
            if(tag1=="addNewUser"){
                var  saveAddUser= {
                    gid:$scope.modalData.id,
                    mid:addOneArray
                };
                if(addOneArray.length != 0) {
                    classSettingService.addTheUserGroup(saveAddUser).then(function (res) {
                        if (res.status == "202") {
                            flag = "Y";
                            console.log("添加用户至群组成功!");
                        } else {
                            flag="N";
                            //alert(res.data.message);
                            $scope.promptMes=res.data.message;
                            $('#messages_model').modal('show');
                        }
                    });
                }
                tag1='';
            }
            //选择已有用户保存到群组
            if(tag2== "selectUser"){
                var newAddStr = addArray2.substring(0, addArray2.length - 1);
                var  saveChooseUser={
                    gid:$scope.modalData.id,
                    ids:newAddStr
                }
                if(newAddStr.length != 0){
                    classSettingService.addUsersGroup(saveChooseUser).then(function(res){
                        if(res.status=="202"){
                            flag = "Y";
                            console.log("批量添加用户至群组成功!");
                        }else{
                            flag = "N";
                            //alert(res.data.message);
                            $scope.promptMes=res.data.message;
                            $('#messages_model').modal('show');
                        }
                    });
                }
                tag2='';
            }
            //删除选中的群组成员
            if(tag3=="deleteUser"){
                //获取需要删除的用户至list
                angular.forEach($scope.memberDataList, function (memberlist) {
                    if (memberlist.status) {
                        delArray += "ids=" + memberlist.id + "&"
                    }
                });
                var newDelStr = delArray.substring(0, delArray.length - 1);
                var  delChooseUser={
                    gid:$scope.modalData.id,
                    ids:newDelStr
                }
                if (delArray.length != 0) {
                    classSettingService.delUserForClass(delChooseUser).then(function (res) {
                        if(res.status=="202"){
                            flag = "Y";
                            console.log("批量删除群成员成功!");
                        }else{
                            flag = "N";
                            //alert(res.data.message);
                            $scope.promptMes=res.data.message;
                            $('#messages_model').modal('show');
                        }
                        //update.del = res;
                    });
                }
                tag3='';
            }
            //if (addArray.length != 0) {
            //    classSettingService.addTheUserGroup(addArray).then(function (res) {
            //        update.add = res;
            //    });
            //}
            var name = $scope.modalData.name;
            var checkflag ="";
            length =0;
            if(name.length>0){
                for(var i=0;i<name.length;i++){
                    var str = name.substr(i,1);
                    if((reg.test(str))||(reg1.test(str))){
                        if(reg.test(str)){
                            length = parseInt(length)+parseInt(2);
                        }else if(reg1.test(str)){
                            length =parseInt(length)+parseInt(1);
                        }
                        checkflag ="Y";
                    }else{
                        checkflag = "N";
                    }
                }
                if (parseInt(length) >20){
                    checkflag = "N";
                }
                if(checkflag=="N"){
                    //alert("无法保存，请按照提示消息修改错误！");
                    $scope.promptMes="无法保存，请按照提示消息修改错误！";
                    $('#messages_model').modal('show');
                }
            }else{
                //alert("群组名称不能为空！");
                $scope.promptMes="群组名称不能为空！";
                $('#messages_model').modal('show');
                checkflag = "N";
            }

            if(checkflag =="Y"||flag=="Y"){
                var str ="name="+ $scope.modalData.name +"&state="+ $scope.modalData.state
                var classData1 = {
                    gid: $scope.modalData.id,
                    str: str
                }
                classSettingService.updateClassMes(classData1).then(function(res){
                    if(res.status=="202"){
                        //alert("更新群组成功!");
                        $scope.promptMes="更新群组成功!";
                        $('#messages_model').modal('show');
                        getClassList(pageClassFlag);
                        $("#updateClass_model").modal("hide");
                    }else{
                        //alert(res.data.message);
                        $scope.promptMes=res.data.message;
                        $('#messages_model').modal('show');
                    }
                    //update.updateClass = res;
                });
            }
            //if(update.add && update.del && update.updateClass){
            //    alert("编辑成功");
            //}
            //else if(update.del && update.updateClass){
            //    alert("编辑成功");
            //}
            //else if(update.add && update.del){
            //    alert("编辑成功");
            //}
            //else if(update.add && update.updateClass){
            //    alert("编辑成功");
            //}
            //else if(update.add){
            //    alert("编辑成功");
            //}
            //else if(update.del){
            //    alert("编辑成功");
            //}
            //else if(update.updateClass){
            //    alert("编辑成功");
            //}
            //else{
            //    alert("编辑失败");
            //}
        };

        //初始化添加群组
        //$scope.AddClass = function(){
        //    $scope.ClassModalData.modalName = "添加新群组";
        //    $scope.inputStyle = "userCheckOFF";
        //};
        //
        //if(!isLogin())
        //{
        //    $state.go('login');
        //}
    }

]);

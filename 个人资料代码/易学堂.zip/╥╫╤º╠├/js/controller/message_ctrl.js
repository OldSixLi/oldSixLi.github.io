/**
 * Created by Axiny on 2016/9/6.
 */
'use strict';//严格模式
angular.module("routerApp")
    .controller("messageCtrl",[
        "$scope",
        "$state",
        "messageService",
        'messagePageInfo',
    function($scope,$state,messageService,messagePageInfo){
        //配置dateTimePick
        $('#dateTimePick1').datetimepicker({
            minView:"month",
            language:'zh-CN',
            autoclose: true,
            bootcssVer:3,
            todayBtn: "linked",
            pickerPosition: "bottom-left",
            todayHighlight : true,
            endDate : new Date()
        }).on('changeDate',function(e){
            var startTime = e.date;
            $('#dateTimePick2').datetimepicker('setStartDate',startTime);
        });
        $('#dateTimePick2').datetimepicker({
            minView:"month",
            language:'zh-CN',
            autoclose: true,
            bootcssVer:3,
            todayBtn: "linked",
            pickerPosition: "bottom-left",
            todayHighlight : true,
            endDate : new Date()
        }).on('changeDate',function(e){
            var endTime = e.date;
            //if(!$("#startDate").val()){
            //    alert("开始日期不能为空！");
            //    return false;
            //}
            $('#dateTimePick1').datetimepicker('setEndDate',endTime);
        });

        $('#dateTimePick').datetimepicker({
            minView:"hour",
            language:'zh-CN',
            bootcssVer:3,
            autoclose: true,
            pickerPosition: "bottom-left",
            todayHighlight : true
        });

        //初始化文本编辑器
        var contentOption = {
            lang: 'zh-CN',
            minHeight: null,
            maxHeight: null,
            focus: true,
            dialogsInBody: true,
            dialogsFade: false,
            toolbar: [
                ['link', ['link']]
            ]
        };

        $scope.contentOption = angular.extend(contentOption, {
            placeholder: '消息内容(200字以内…)',
            height: '200'
        });

        //状态
        $scope.States = States;

        //推送对象
        $scope.Obj = Obj;
        $scope.Obj1 = Obj1;

        //搜索
        $scope.selectMessageList =
        {
            "key":"",
            "state":0,
            "obj":0,
            "startDate":"",
            "endDate":""
        };

        //翻页配置类
        $scope.paginationConf =
        {
            currentPage: 0,     //初始页码
            itemsPerPage: 10,   //每页显示条目
            totalItems: 0       //总条目数
        };

        //GET Parameters
        $scope.paramMessageData =
        {
            page:$scope.paginationConf.currentPage,
            pageNum:$scope.paginationConf.itemsPerPage,
            key:"",
            state:0,
            obj:0,
            startDate:"",
            endDate:""
        };

        //获取用户信息
        $scope.MessageInfo ={
            "totalNum": 0,
            "mMessageList": [
                {
                    "title": "",
                    "pushTime": "",
                    "modifyTime": "",
                    "obj": 0,
                    "id": 0,
                    "state": 0,
                    "content": "",
                    "messageObj": "",
                    "messageState": ""
                }
            ]
        };

        //获取已推送消息数
        messageService.getMessageNum().then(function(res) {
            $scope.messagePushNum = res;
        });

        var messageState="";
        var messageObj="";
        var flag ="Y";
        //获取消息数据
        getMsgList(flag);

        //点击页码
        $scope.getMessageData = function(page){
            //$scope.paramMessageData.page = page;
            $scope.paramMessageData = {
                page:page != 0 ? page - 1 : 0,
                pageNum:$scope.paginationConf.itemsPerPage,
                key:$scope.selectMessageList.key,
                state:$scope.selectMessageList.state,
                obj:$scope.selectMessageList.obj,
                startDate:$('#startDate').val(),
                endDate:$('#endDate').val()
            };
            flag = "N";
            getMsgList(flag);
        };

        //按条件查找消息
        $scope.selectMessage = function(){
                $scope.paramMessageData.page = 1;
                $scope.paramMessageData= {
                page:0,
                pageNum:$scope.paginationConf.itemsPerPage,
                key:$scope.selectMessageList.key,
                state:$scope.selectMessageList.state,
                obj:$scope.selectMessageList.obj,
                startDate:$('#startDate').val(),
                endDate:$('#endDate').val()
            };
            flag ="Y";
            getMsgList(flag);
        };

        function getMsgList(flag){
            $scope.select_all = false;
            if($scope.paramMessageData.startDate !=""){
                $scope.paramMessageData.startDate = $scope.paramMessageData.startDate+" "+"00:00:00";
            }
            if($scope.paramMessageData.endDate !="") {
                $scope.paramMessageData.endDate = $scope.paramMessageData.endDate + " " + "00:00:00";
            }
            messageService.getMessageList($scope.paramMessageData).then(function(res){
                var messageData=[];
                if (res.mMessageList != null && res.mMessageList.length > 0) {
                    for (var i = 0; i < res.mMessageList.length; i++) {
                        if(res.mMessageList[i].state==0){
                            messageState="不限";
                        }else if(res.mMessageList[i].state==1){
                            messageState="草稿";
                        }else if(res.mMessageList[i].state==2){
                            messageState="未推送";
                        }else if(res.mMessageList[i].state==3){
                            messageState="已推送";
                        }
                        if(res.mMessageList[i].obj==0){
                            messageObj="全部";
                        }else if(res.mMessageList[i].obj==1){
                            messageObj="教师";
                        }else if(res.mMessageList[i].obj==2){
                            messageObj="非教师";
                        }
                        messageData[i] = {
                            "id": res.mMessageList[i].id,
                            "title": res.mMessageList[i].title,
                            "content": res.mMessageList[i].content,
                            "pushTime": (res.mMessageList[i].pushTime).substring(0,(res.mMessageList[i].pushTime.length-3)),
                            "modifyTime": (res.mMessageList[i].modifyTime).substring(0,(res.mMessageList[i].modifyTime.length-3)),
                            "messageObj": messageObj,
                            "messageState": messageState,
                            "obj": res.mMessageList[i].obj,
                            "state": res.mMessageList[i].state
                        }
                    }
                }
                $scope.messageDetail = messageData;
                if(messageData.length > 0){
                    $(".message_content").css('display','block');
                    $(".message_contentNo").css('display','none');
                }else{
                    $(".message_contentNo").css('display','block');
                    $(".message_content").css('display','none');
                }
                if(flag =="Y"){
                    $scope.paginationConf =
                    {
                        currentPage: 1,     //初始页码
                        itemsPerPage: 10,   //每页显示条目
                        totalItems: res.totalNum       //总条目数
                    };
                }else{
                    if(res.totalNum/10 < $scope.paramMessageData.page ){
                        $scope.paramMessageData.page=0;
                        messageService.getMessageList($scope.paramMessageData).then(function(res) {
                            messageData = [];
                            if (res.mMessageList != null && res.mMessageList.length > 0) {
                                for (var i = 0; i < res.mMessageList.length; i++) {
                                    if (res.mMessageList[i].state == 0) {
                                        messageState = "不限";
                                    } else if (res.mMessageList[i].state == 1) {
                                        messageState = "草稿";
                                    } else if (res.mMessageList[i].state == 2) {
                                        messageState = "未推送";
                                    } else if (res.mMessageList[i].state == 3) {
                                        messageState = "已推送";
                                    }
                                    if (res.mMessageList[i].obj == 0) {
                                        messageObj = "全部";
                                    } else if (res.mMessageList[i].obj == 1) {
                                        messageObj = "教师";
                                    } else if (res.mMessageList[i].obj == 2) {
                                        messageObj = "非教师";
                                    }
                                    messageData[i] = {
                                        "id": res.mMessageList[i].id,
                                        "title": res.mMessageList[i].title,
                                        "content": res.mMessageList[i].content,
                                        "pushTime": (res.mMessageList[i].pushTime).substring(0,(res.mMessageList[i].pushTime.length-3)),
                                        "modifyTime": (res.mMessageList[i].modifyTime).substring(0,(res.mMessageList[i].modifyTime.length-3)),
                                        "messageObj": messageObj,
                                        "messageState": messageState,
                                        "obj": res.mMessageList[i].obj,
                                        "state": res.mMessageList[i].state
                                    }
                                }
                            }
                            $scope.messageDetail = messageData;
                            $scope.paginationConf =
                            {
                                currentPage: 1,     //初始页码
                                itemsPerPage: 10,   //每页显示条目
                                totalItems: res.totalNum       //总条目数
                            };
                        })
                    }else{
                        $scope.paginationConf =
                        {
                            itemsPerPage: 10,   //每页显示条目
                            totalItems: res.totalNum       //总条目数
                        };
                    }
                }
            });
        }

        //获取总条目数计算页码
        //$scope.paginationConf.totalItems = messagePageInfo.totalNum;

        //模态框用户类
        $scope.modalData =
        {
            "modalName":"",
            "title": "",
            "pushTime": "",
            "modifyTime": "",
            "isdraft": "",
            "obj": 0,
            "id":"",
            "state": 0,
            "content": ""
        };
        //初始化添加消息
        $scope.creatAddMessage = function(){
            $scope.modalData.modalName = "添加消息";
            $scope.modalData.title = "";
            $scope.modalData.pushTime = "";
            $scope.modalData.obj = 0;
            //$scope.modalData.isdraft = 0;
            $scope.modalData.content = "";

        };

        //初始化编辑消息
        $scope.editMessage = function(messagelist){
            if(messagelist.state  == 3){
                //alert("已推送消息无法编辑！");
                $scope.promptMes="已推送消息无法编辑！";
                $('#messages_model').modal('show');
                $("#messageModal").modal("hide");
            }else{
            $scope.modalData.modalName = "编辑消息";
            $scope.modalData.id = messagelist.id;
            $scope.modalData.title = messagelist.title;
            // $scope.modalData.pushTime = (messagelist.pushTime).substring(0,(messagelist.pushTime).length-3);
            $scope.modalData.pushTime = messagelist.pushTime;
            $scope.modalData.obj = messagelist.obj;
            $scope.modalData.content = messagelist.content;
            $("#messageModal").modal("show");
            }
        };

        //复制消息
        $scope.copyChoseMessage = function(messagelist) {
            //将日期格式截取为yyyy-mm-dd hh:ii
            //var time = messagelist.pushTime;
            //var pushTime = time.substring(0,time.length-3);
            $scope.modalData.modalName = "复制消息";
            $scope.modalData.title = messagelist.title;
            $scope.modalData.pushTime = messagelist.pushTime;
            $scope.modalData.obj = messagelist.obj;
            $scope.modalData.content = messagelist.content;
        };

        //选择执行操作  添加/编辑消息
        $scope.operationMessage = function(flag1){
            $scope.select_all = false;
            var datesend = $('#SendDate').val();
            if(datesend !=""&&datesend!=null&&datesend.length<17){
                var pushtimes= $('#SendDate').val()+":00";
            }else{
                var pushtimes="";
            }
            var isdraft;
            if(flag1 =="T"){
                isdraft = 0;
            }else{
                isdraft = 1;
            }
            switch ($scope.modalData.modalName){
                case "添加消息":{
                    var  addNewUserMessage= {
                        title:$scope.modalData.title,
                        pushTime:pushtimes,
                        obj:$scope.modalData.obj,
                        content:$scope.modalData.content,
                        isdraft: isdraft
                    };
                    if(countTextLength("note-editable", 200) && countInputLength("messageTitle", 60) && checkStringLength(addNewUserMessage.content, 500)){
                        messageService.addMessageData(addNewUserMessage).then(function(res){
                            if(res.status=="202"){
                                getMsgList(flag);
                                $("#messageModal").modal("hide");
                                //alert("添加信息成功");
                            }else{
                                var resMes = sendMesError(res.data);
                                //alert(resMes);
                                $scope.promptMes=resMes;
                                $('#messages_model').modal('show');
                            }
                        });
                    }
                    break;
                }
                case "编辑消息":{
                    var  editNewMessageDate= {
                        id:$scope.modalData.id,
                        title:$scope.modalData.title,
                        pushTime:pushtimes,
                        obj:$scope.modalData.obj,
                        content:$scope.modalData.content,
                        isdraft: isdraft
                    };
                    if(countTextLength("note-editable", 200) && countInputLength("messageTitle", 60) && checkStringLength(editNewMessageDate.content, 500)){
                        messageService.editMessageData(editNewMessageDate).then(function(res){
                            if(res.status=="202"){
                                getMsgList(flag);
                                $("#messageModal").modal("hide");
                                //alert("修改信息成功");
                                $scope.promptMes="修改信息成功";
                                $('#messages_model').modal('show');
                            }else{
                                var resMes = sendMesError(res.data);
                                //alert(resMes);
                                $scope.promptMes=resMes;
                                $('#messages_model').modal('show');
                            }
                        });
                    }
                    break;
            }
                case "复制消息":{
                    var  copyNewMessageDate= {
                        title:$scope.modalData.title,
                        pushTime:pushtimes,
                        obj:$scope.modalData.obj,
                        content:$scope.modalData.content,
                        isdraft: isdraft
                    };
                    if(countTextLength("note-editable", 200) && countInputLength("messageTitle", 60) && checkStringLength(copyNewMessageDate.content, 500)){
                        messageService.addMessageData(copyNewMessageDate).then(function(res){
                            if(res.status=="202"){
                                getMsgList(flag);
                                $("#messageModal").modal("hide");
                                //alert("复制信息成功");
                                $scope.promptMes="复制信息成功";
                                $('#messages_model').modal('show');
                            }else{
                                var resMes = sendMesError(res.data);
                                alert(resMes);
                                $scope.promptMes=resMes;
                                $('#messages_model').modal('show');
                            }
                        });
                    }
                    break;
                }
                default :{
                    break;
                }
            }
        };

        //删除消息
        $scope.deleteMessageInit = function(messagelist){
            $scope.modalData.id = messagelist.id;
        };
        $scope.deleteMessage = function() {
            var  deleteOneMessage= {
                id:$scope.modalData.id
            };
            messageService.deleteMessageById(deleteOneMessage).then(function(res){
                if(res.status=="202"){
                    getMsgList(flag);
                    $("#deleteMessageById_model").modal("hide");
                }else{
                    //alert(res.data.message);
                    $scope.promptMes=res.data.message;
                    $('#messages_model').modal('show');
                }
            })
        };

        //复选框全选或者反选
        $scope.select_all = false;
        $scope.selectAll = function () {
            if($scope.select_all) {
                angular.forEach($scope.messageDetail, function(messageIdList) {
                    messageIdList.status = true;
                })
            }else {
                angular.forEach($scope.messageDetail, function(messageIdList) {
                    messageIdList.status = false;
                })
            }
        };

        $scope.select_all = false;
        $scope.choseAllArr=[];//定义数组用于存放全选数组
        $scope.choseSomeArr=[];//定义数组用于存放所选数组
        $scope.selectAll = function (c) {
            $scope.choseAllArr = [];
            if(c==true) {
                angular.forEach($scope.messageDetail, function(messageIdList){
                    messageIdList.status = true;
                    $scope.choseAllArr.push(messageIdList.id);
                })
            }else {
                angular.forEach($scope.messageDetail, function(messageIdList) {
                    messageIdList.status = false;
                })
            }
        };
        // $scope.checkChose = function (some) {
        //     $scope.choseSomeArr = [];
        //     if(some==true) {
        //         angular.forEach($scope.messageDetail, function(messageIdList){
        //             if(messageIdList.status == true){
        //                 $scope.choseSomeArr.push(messageIdList.id);
        //             }
        //         });
        //         if($scope.choseAllArr.sort().toString() == $scope.choseSomeArr.sort().toString()){
        //             $scope.select_all = true;
        //         }else{
        //             $scope.select_all = false;
        //         }
        //     }else {
        //         $scope.select_all = false;
        //     }
        // };

        $scope.checkChose = function (check) {
            var count = 0;
            if(check == true) {
                for(var i = 0; i < $scope.messageDetail.length; i++){
                    if($scope.messageDetail[i].status){
                        count++
                    }
                }
                if(count == $scope.messageDetail.length){
                    $scope.select_all = true
                }
            }else {
                $scope.select_all = false;
            }
        };

        //批量删除
        var delArray = "";
        $scope.deleteSelectMes = function() {
            delArray = "";
            angular.forEach($scope.messageDetail, function(messageIdList) {
                if (messageIdList.status) {
                    delArray += "ids=" + messageIdList.id + "&"
                }
            });
            var newstr1 = delArray.substring(0, delArray.length - 1);
            if(newstr1.length != 0){
                $("#deleteMes_model").modal("show");
            }else{
                //alert("至少选择一项删除！");
                $scope.promptMes="至少选择一项删除！";
                $('#messages_model').modal('show');
                $("#deleteMes_model").modal("hide");
            }
        };
        $scope.batchDeleteMes = function() {
            $scope.select_all = false;
            var newstr = delArray.substring(0, delArray.length - 1);
            messageService.deleteMes(newstr).then(function(res){
                if(res.status=="202"){
                    getMsgList(flag);
                    $("#deleteMes_model").modal("hide");
                }else{
                    //alert(res.data.message);
                    $scope.promptMes=res.data.message;
                    $('#messages_model').modal('show');
                }
            });
        };

        /**
         * 检测多行文本框用户输入字符
         * @param className 输入框类名
         * @param maxLength 限制最大字符长度
         * @returns {boolean}
         */
        function countTextLength(className, maxLength) {
            var dom_text = document.getElementsByClassName(className);
            var text = '';
            for(var i = 0; i < dom_text[0].children.length; i++) {
                text += dom_text[0].children[i].innerText;
            }

            if(text.length > maxLength){
                //alert("消息正文字数不得超过" + maxLength + "个字符");
                $scope.promptMes="消息正文字数不得超过" + maxLength + "个字符";
                $('#messages_model').modal('show');
                return false;
            }
            else{
                return true;
            }
        }

        /**
         * 检测表单输入框字符
         * @param id
         * @param maxLength
         * @returns {boolean}
         */
        function countInputLength(id, maxLength) {
            var dom_text = document.getElementById(id);
            var text = dom_text.value;
            if(text.length > maxLength){
                //alert("消息标题字数不得超过" + maxLength + "个字符");
                $scope.promptMes="消息标题字数不得超过" + maxLength + "个字符";
                $('#messages_model').modal('show');
                return false;
            }
            else {
                return true;
            }
        }

        /**
         * 检测推送到后台数据长度是否超过限定值
         * @param str
         * @param length
         */
        function checkStringLength(str, length) {
            if (str.length > length){
                $scope.promptMes="消息正文数据过长";
                $('#messages_model').modal('show');
                return false;
            }
            else {
                return true;
            }
        }
    }
]);
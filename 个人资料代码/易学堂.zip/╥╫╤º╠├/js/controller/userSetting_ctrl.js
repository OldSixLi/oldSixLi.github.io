/**
 * Created by Axiny on 2016/8/4.
 */
'use strict';//严格模式
angular.module("routerApp")
    .controller("userSettingCtrl",[
        "$scope",
        "$state",
        "userSettingService",
        'pageInfo',
        function($scope,$state,userSettingService,pageInfo){
            //配置dateTimePick
            $('#dateTimePick1').datetimepicker({
                minView:"month",
                language:'zh-CN',
                bootcssVer:3,
                autoclose: true,
                todayBtn: "linked",
                pickerPosition: "bottom-left",
                todayHighlight : true,
                endDate : new Date()
            }).on('changeDate',function(e){
                var startTime = e.date;
                $('#dateTimePick2').datetimepicker('setStartDate',startTime);
            });
            $('#dateTimePick2').datetimepicker({
                minView:"month",
                language:'zh-CN',
                bootcssVer:3,
                autoclose: true,
                todayBtn: "linked",
                pickerPosition: "bottom-left",
                todayHighlight : true,
                endDate : new Date()
            }).on('changeDate',function(e){
                var endTime = e.date;
                //if(!$("#regstartDate").val()){
                //    alert("开始日期不能为空！");
                //    return false;
                //}
                $('#dateTimePick1').datetimepicker('setEndDate',endTime);
            });
            //验证
            var length = 0;
            var reg =/^[\u4e00-\u9fa5]+$/;
            var reg1=/^[a-zA-Z]+$/;
            var reg2= /^([0-9]{11})?$/;
            $("#tel").blur(function() {
                length = 0;
                var checkTel = $("#tel").val();
                if (!reg2.test(checkTel)) {
                    $("#showErro1").html("请输入正确格式的手机号！");
                    //length = parseInt(length);
                } else {
                    $("#showErro1").html("");
                }
                //if (parseInt(length) >11){
                //    $("#showErro1").html("手机号输入已超过11个数字!");
                //}else{
                //    $("#showErro1").html("");
                //}
            });
            $("#userName").blur(function(){
                length = 0;
                var checkName =$("#userName").val();
                for(var i=0;i<checkName.length;i++){
                    var str = checkName.substr(i,1);
                    if((reg.test(str))||(reg1.test(str))){
                        if(reg.test(str)){
                            length = parseInt(length)+parseInt(2);
                        }else if(reg1.test(str)){
                            length =parseInt(length)+parseInt(1);
                        }
                    }else{
                        $("#showErro").html("仅能输入汉字或字母！");
                    }
                }
                if (parseInt(length) >20){
                    $("#showErro").html("输入已超过20个字符!");
                }else{
                    $("#showErro").html("");
                }
            });

            //性别
            $scope.Sex = Sex;
            $scope.Sex1 = Sex1;

            //角色
            $scope.Role = Role;
            $scope.Role1 = Role1;

            //搜索
            $scope.selectUserList =
            {
                "key":"",
                "role":0,
                "sex":"",
                "regstartDate":"",
                "regendDate":""
            };

            //翻页配置类
            $scope.paginationConf =
            {
                currentPage: 0,     //初始页码
                itemsPerPage: 10,   //每页显示条目
                totalItems: 0       //总条目数
            };

            //GET Parameters
            $scope.paramUserData =
            {
                page:$scope.paginationConf.currentPage,
                pageNum:$scope.paginationConf.itemsPerPage,
                key:"",
                role:0,
                sex:"",
                regstartDate:"",
                regendDate:""
            };

            //获取用户信息
            $scope.userInfo ={
                "totalNum": 0,
                "mUserList": [
                    {
                        "id": 0,
                        "mobilePhone": "",
                        "role": 0,
                        "realname": "",
                        "sex": 0,
                        "regDate": "",
                        "lastLoginTime": "",
                        "picPath": "img/userImg404.png",
                        "departIdLevelOne": 0,
                        "departId": 0,
                        "peopleRole":"",
                        "peopleSex":"",
                        "peopleDepOne":"",
                        "peopleDepTwo":""
                    }
                ]
            };

            //预先声明 角色、科室、性别的保存字段
            var peopleRole = "";
            var peopleDepOne = "";
            var peopleDepTwo = "";
            var peopleSex = "";

            //判断是点击页码、搜索还是预加载
            var flag ="Y";

            //判断角色
            function roleSwitch(data){
                switch (data) {
                    case 0:{
                        peopleRole="角色不限";
                        break;
                    }
                    case 1:{
                        peopleRole="教师";
                        break;
                    }
                    case 2:{
                        peopleRole="学生";
                        break;
                    }
                    case 3:{
                        peopleRole="临床医生";
                        break;
                    }
                    case 4:{
                        peopleRole="管理员";
                        break;
                    }
                    default :{
                        break;
                    }
                }
            }

            //判断性别
            function sexSwitch(data){
                switch (data) {
                    case 0:{
                        peopleSex="未设置";
                        break;
                    }
                    case 1:{
                        peopleSex="男";
                        break;
                    }
                    case 2:{
                        peopleSex="女";
                        break;
                    }
                    default :{
                        break;
                    }
                }
            }

            //获取用户数据
            getUserList(flag);

            $scope.getUserData1 = function(page){
                //$scope.paramUserData.page = page;
                $scope.paramUserData = {
                    page:page != 0 ? page - 1 : 0,
                    pageNum:$scope.paginationConf.itemsPerPage,
                    key:$scope.selectUserList.key,
                    role:$scope.selectUserList.role,
                    sex:$scope.selectUserList.sex,
                    regstartDate:$('#regstartDate').val(),
                    regendDate:$('#regendDate').val()
                };
                flag="N";
                getUserList(flag);
            };

            //按条件查找用户
            $scope.selectUser = function(){
                $scope.paramUserData.page = 1;
                $scope.paramUserData = {
                    page:0,
                    pageNum:$scope.paginationConf.itemsPerPage,
                    key:$scope.selectUserList.key,
                    role:$scope.selectUserList.role,
                    sex:$scope.selectUserList.sex,
                    regstartDate:$('#regstartDate').val(),
                    regendDate:$('#regendDate').val()
                };
                flag ="Y1";
                getUserList(flag);
            };

            function getUserList(flag){
                $scope.select_all = false;
                if($scope.paramUserData.regstartDate !=""){
                    $scope.paramUserData.regstartDate = $scope.paramUserData.regstartDate+" "+"00:00:00";
                }
                if($scope.paramUserData.regendDate !="") {
                    $scope.paramUserData.regendDate = $scope.paramUserData.regendDate + " " + "00:00:00";
                }
                userSettingService.getUserData($scope.paramUserData).then(function(res){
                   if(flag =="Y"){
                    $scope.userData1 = res;
                   }
                    var userData=[];
                    if (res.mUserList != null && res.mUserList.length > 0) {
                        for (var i = 0; i < res.mUserList.length; i++) {
                            //角色判断
                            roleSwitch(res.mUserList[i].role);
                            //性别判断
                            sexSwitch(res.mUserList[i].sex);

                            userData[i] = {
                                id: res.mUserList[i].id,
                                mobilePhone: res.mUserList[i].mobilePhone,
                                role: res.mUserList[i].role,
                                realname: res.mUserList[i].realname,
                                sex: res.mUserList[i].sex,
                                regDate: res.mUserList[i].regDate,
                                lastLoginTime: res.mUserList[i].lastLoginTime,
                                picPath: res.mUserList[i].picPath,
                                departIdLevelOne: res.mUserList[i].departIdLevelOne,
                                departId: res.mUserList[i].departId,
                                peopleRole:peopleRole,
                                peopleSex:peopleSex,
                                peopleDepOne:peopleDepOne,
                                peopleDepTwo:peopleDepTwo
                            }
                        }
                    }
                    $scope.userDetail = userData;
                    if(userData.length > 0){
                        $(".message_content").css('display','block');
                        $(".message_contentNo").css('display','none');
                    }else{
                        $(".message_contentNo").css('display','block');
                        $(".message_content").css('display','none');
                    }
                    angular.forEach($scope.userDetail,function(item){
                        if(item.departIdLevelOne != 0){
                            var dpId = {
                                id:item.departIdLevelOne
                            }
                            //人员第一部门判断
                            userSettingService.getPeopleDepName(dpId).then(function(res){
                                item.peopleDepOne = res.name;
                            });
                        }else{
                            item.peopleDepTwo = "";
                        }
                        if(item.departId != 0){
                            //人员第二部门判断
                            var dpId = {
                                id:item.departId
                            }
                            userSettingService.getPeopleDepName(dpId).then(function(res){
                                item.peopleDepTwo = res.name;
                            });
                        }else{
                            item.peopleDepTwo = "暂无科室";
                        }
                    });
                    if(flag =="Y" || flag=="Y1"){
                        $scope.paginationConf =
                        {
                            currentPage: 1,     //初始页码
                            itemsPerPage: 10,   //每页显示条目
                            totalItems: res.totalNum       //总条目数
                        };
                    }else{
                        $scope.paginationConf =
                        {
                            itemsPerPage: 10,   //每页显示条目
                            totalItems: res.totalNum       //总条目数
                        };
                    }
                });
            }

            //获取总条目数计算页码
            //$scope.paginationConf.totalItems = pageInfo.totalNum;

            //模态框用户类
            $scope.modalData =
            {
                "modalName":"",
                "mobilePhone":"",
                "id":"",
                "password":"e99a18c428cb38d5f260853678922e03",
                "role":0,
                "realname":"",
                "sex":0,
                "departIdLevelOne ":0,
                "departId ":0,
                "picPath":"img/userImg404.png",
                "regDate": "",
                "lastLoginTime": ""
            };

            $scope.departDetail =
            {
                "totalNum": 0,
                "departList": [
                    {
                        "id": 0,
                        "name": "",
                        "level": 0,
                        "pid": 0,
                        "createTime": ""
                    }
                ]
            };

            //初始化添加用户
            $scope.createAddUser = function(){
                $scope.erroMsg ="";
                $scope.modalData.modalName = "添加新用户";
                $scope.modalData.mobilePhone = "";
                $scope.modalData.role = 1;
                $scope.modalData.realname = "";
                $scope.modalData.sex = 0;
                $scope.modalData.departIdLevelOne = 0;
                $scope.modalData.departId = 0;
                $scope.modalData.picPath = "img/userImg404.png";
                //id、regDate等在新增时不显示
               $("#showEditInfo").css('display','none');
               $("#showUserTime").css('display','none');
                $("#picPath").removeClass("img-thumbnail userImg1");
                $("#picPath").addClass("img-thumbnail userImg");
                $("#userRole").removeAttr("disabled");
                //获取科室
                var paramFirDepart =
                {
                    name:'',
                    level:1,
                    page:0,
                    pageNum:100
                }
                //获取一级科室
                userSettingService.getFirstDepName(paramFirDepart).then(function(res){
                    $scope.FirstDepName = res.departList;
                    //if (res.departList != null && res.departList.length > 0) {
                    //    for (var i = 0; i < res.departList.length; i++) {
                    //        var secPid= res.departList[0].id;
                    //    }
                    //}
                    //var paramSecDepart =
                    //{
                    //    page:0,
                    //    pageNum:100,
                    //    did:secPid
                    //}
                    ////获取二级科室
                    //userSettingService.getSecondDepName(paramSecDepart).then(function(res){
                    //    $scope.SecondDepName = res.departList;
                    //});
                });
            };

            //初始化编辑用户
            $scope.editUser = function(userlist){
                $scope.erroMsg ="";
                $scope.modalData.modalName = "编辑用户";
                $scope.modalData.id = userlist.id;
                $scope.modalData.mobilePhone = userlist.mobilePhone;
                $scope.modalData.role = userlist.role;
                $scope.modalData.realname = userlist.realname;
                $scope.modalData.sex = userlist.sex;
                if(userlist.departIdLevelOne==null||typeof (userlist.departIdLevelOne)=='undefined'){
                    $scope.modalData.departIdLevelOne = userlist.departId;
                }else{
                $scope.modalData.departIdLevelOne = userlist.departIdLevelOne;
                $scope.modalData.departId = userlist.departId;
                }
                $scope.modalData.picPath = userlist.picPath;
                $scope.modalData.regDate = userlist.regDate;
                $scope.modalData.lastLoginTime = userlist.lastLoginTime;

                //id、regDate等在新增时不显示
                $("#showEditInfo").css('display','block');
                $("#showUserTime").css('display','block');
                $("#picPath").removeClass("img-thumbnail userImg");
                $("#picPath").addClass("img-thumbnail userImg1");
                $("#userRole").attr("disabled","disabled");
                //获取科室
                var paramFirDepart =
                {
                    name:'',
                    level:1,
                    page:0,
                    pageNum:100
                }
                //获取一级科室
                userSettingService.getFirstDepName(paramFirDepart).then(function(res){
                    $scope.FirstDepName = res.departList;
                });
                var paramSecDepart =
                {
                    page:0,
                    pageNum:100,
                    did:$scope.modalData.departIdLevelOne
                }
                //获取二级科室
                userSettingService.getSecondDepName(paramSecDepart).then(function(res){
                    $scope.SecondDepName = res.departList;
                });
            };

            //当一级科室发生变化时获取二级科室
            $scope.getDepartmentTwo = function(){
                var paramSecDepart =
                {
                    page:0,
                    pageNum:100,
                    did:$scope.modalData.departIdLevelOne
                }
                userSettingService.getSecondDepName(paramSecDepart).then(function(res){
                    $scope.SecondDepName = res.departList;
                });
            };

            $scope.submitted = false;
            //选择执行操作  添加/编辑用户
            var picPath ="";
            var userDepId ="";
            $scope.operation = function(){
                $scope.select_all = false;
                if($scope.modalData.picPath==null||$scope.modalData.picPath==""){
                    picPath = "img/userImg404.png";
                }else{
                    picPath = $scope.modalData.picPath;
                }
                if($scope.modalData.departId==""||$scope.modalData.departId==null){
                    userDepId = $scope.modalData.departIdLevelOne;
                }else{
                    userDepId = $scope.modalData.departId;
                }

                var name = $scope.modalData.realname;
                var userTel = $scope.modalData.mobilePhone;
                var checkFlag ="Y";
                length =0;
                if(name.length>0){
                    for(var i=0;i<name.length;i++){
                        var str = name.substr(i,1);
                        if((reg.test(str))||(reg1.test(str))){
                            if(reg.test(str)){
                                length = parseInt(length)+parseInt(2);
                            }else if(reg1.test(str)){
                                length =parseInt(length)+parseInt(1);
                            }
                        }else{
                            $("#showErro").html("仅能输入汉字或字母！");
                            checkFlag = "N";
                        }
                    }
                    if (parseInt(length) >20){
                        $("#showErro").html("输入已超过20个字符!");
                        checkFlag = "N";
                    }
                    if(userTel.length<1){
                        $("#showErro1").html("请输入手机号！");
                        checkFlag = "S";
                    }

                }else{
                    $("#showErro").html("用户姓名不能为空！");
                    //$scope.promptMes="用户姓名不能为空！";
                    //$('#messages_model').modal('show');
                    checkFlag = "S";
                }
                if(checkFlag=="N"){
                    $scope.promptMes="无法保存，请按照提示消息修改错误！";
                    $('#messages_model').modal('show');
                }else if( checkFlag =="Y"){
                switch ($scope.modalData.modalName){
                    case "添加新用户":{
                        var  addNewUserDate = null;
                        if($scope.modalData.role == 4){
                         addNewUserDate= {
                            mobilePhone:$scope.modalData.mobilePhone,
                            role:$scope.modalData.role,
                            password:$scope.modalData.password,
                            realname:$scope.modalData.realname,
                            sex:$scope.modalData.sex,
                            picPath:picPath
                        }
                    }else{

                            addNewUserDate= {
                                mobilePhone:$scope.modalData.mobilePhone,
                                role:$scope.modalData.role,
                                password:$scope.modalData.password,
                                realname:$scope.modalData.realname,
                                sex:$scope.modalData.sex,
                                picPath:picPath,
                                departId:userDepId
                            }
                        }
                        //if($scope.userForm.$valid) {
                            userSettingService.addUser(addNewUserDate).then(function (res) {
                                if (res.status == "200") {
                                    getUserList(flag);
                                    $("#updateUser").modal("hide");
                                } else {
                                    //alert(res.data.message);
                                    $scope.promptMes = res.data.message;
                                    $('#messages_model').modal('show');
                                }
                            });
                        //}else{
                        //    $scope.promptMes="请按照提示修改信息再提交！";
                        //    $('#messages_model').modal('show');
                        //}
                        break;
                    }
                    case "编辑用户":{
                        var  editNewUserDate = null;
                        if($scope.modalData.role == 4) {
                            editNewUserDate = {
                                id: $scope.modalData.id,
                                mobilePhone: $scope.modalData.mobilePhone,
                                realname: $scope.modalData.realname,
                                sex: $scope.modalData.sex,
                                picPath: picPath
                            }
                        }else{
                            editNewUserDate = {
                                id: $scope.modalData.id,
                                mobilePhone: $scope.modalData.mobilePhone,
                                realname: $scope.modalData.realname,
                                sex: $scope.modalData.sex,
                                departId: userDepId,
                                picPath: picPath
                            }
                        }
                        //if($scope.userForm.$valid) {
                            userSettingService.editUserData(editNewUserDate).then(function (res) {
                                if (res.status == "202") {
                                    getUserList(flag);
                                    $("#updateUser").modal("hide");
                                } else {
                                    //alert(res.data.message);
                                    $scope.promptMes = res.data.message;
                                    $('#messages_model').modal('show');
                                }
                            });
                        //}else{
                        //    $scope.promptMes="请按照提示修改信息再提交！";
                        //    $('#messages_model').modal('show');
                        //}
                        break;
                    }
                    default :{
                        break;
                    }
                }
                }
            };

            //删除单个用户
            $scope.deleteOperation = function() {
                var  deleteOneUser= {
                    id:$scope.modalData.id
                }
                userSettingService.deleteUserById(deleteOneUser).then(function(res){
                    if(res.status=="202"){
                        getUserList(flag);
                        $("#deleteUserById_model").modal("hide");
                    }else{
                        //alert(res.data.message);
                        $scope.promptMes=res.data.message;
                        $('#messages_model').modal('show');
                    }
                })
            };

            $scope.deleteInit = function(userlist){
                $scope.modalData.id = userlist.id;
            };

            //复选框全选或者反选
                $scope.select_all = false;
                $scope.choseAllArr=[];//定义数组用于存放全选数组
                $scope.choseSomeArr=[];//定义数组用于存放所选数组
                $scope.selectAll = function (c) {
                    $scope.choseAllArr = [];
                    if(c==true) {
                        angular.forEach($scope.userDetail, function(userIdList) {
                            userIdList.status = true;
                            $scope.choseAllArr.push(userIdList.id);
                        })
                    }else {
                        angular.forEach($scope.userDetail, function(userIdList) {
                            userIdList.status = false;
                        })
                    }
                };
            $scope.checkChose = function (check) {
                var count = 0;
                if(check == true) {
                    for(var i = 0; i < $scope.userDetail.length; i++){
                        if($scope.userDetail[i].status){
                            count++
                        }
                    }
                    if(count == $scope.userDetail.length){
                        $scope.select_all = true
                    }
                }else {
                    $scope.select_all = false;
                }
            };

            //批量删除
            var delArray = "";
            $scope.deleteSelecteUser = function() {
                delArray = "";
                angular.forEach($scope.userDetail, function(userIdList) {
                    if (userIdList.status) {
                        delArray += "id=" + userIdList.id + "&"
                    }
                });
                var newstr1 = delArray.substring(0, delArray.length - 1);
                if(newstr1.length != 0){
                    $("#deleteUser_model").modal("show");
                }else{
                    //alert("至少选择一项删除！");
                    $scope.promptMes="至少选择一项！";
                    $('#messages_model').modal('show');

                    $("#deleteUser_model").modal("hide");
                }
            }
            $scope.batchDeleteUser = function() {
                $scope.select_all = false;
                var newstr = delArray.substring(0, delArray.length - 1);
                    userSettingService.deleteUser(newstr).then(function(res){
                        if(res.status=="202"){
                            getUserList(flag);
                            $("#deleteUser_model").modal("hide");
                        }else{
                            //alert(res.data.message);
                            $scope.promptMes=res.data.message;
                            $('#messages_model').modal('show');
                        }
                    });
            };

        }

    ]);
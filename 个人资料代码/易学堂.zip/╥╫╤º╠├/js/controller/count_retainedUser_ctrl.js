/**
 * Created by Axiny on 2016/9/1.
 */
var app = angular.module('routerApp');
app.controller('countRetainedUserCtrl',[
    "$scope",
    "$state",
    "countService",
    function($scope,$state,countService){
        var startDate ="";
        var endDate = "" ;
        var periodType = 1;
        var tag = "tec";
        $('#dateTimePick1').datetimepicker({
            minView:"month",
            language:'zh-CN',
            bootcssVer:3,
            autoclose: true,
            todayBtn: "linked",
            pickerPosition: "bottom-left",
            todayHighlight : true,
            endDate : new Date()
        }).on('changeDate',function(e){
            var startTime = e.date;
            $('#dateTimePick2').datetimepicker('setStartDate',startTime);
        });
        $('#dateTimePick2').datetimepicker({
            minView:"month",
            language:'zh-CN',
            autoclose: true,
            bootcssVer:3,
            todayBtn: "linked",
            pickerPosition: "bottom-left",
            todayHighlight : true,
            endDate : new Date()
        }).on('changeDate',function(e){
            var endTime = e.date;
            //if(!$("#startDate").val()){
            //    alert("开始日期不能为空！");
            //    return false;
            //}
            $('#dateTimePick1').datetimepicker('setEndDate',endTime);
        });

        //js自动获取当前日期
        var date = new Date();
        var seperator1 = "-";
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        var strDate = date.getDate();
        if (month >= 1 && month <= 9) {
            month = "0" + month;
        }
        if (strDate >= 0 && strDate <= 9) {
            strDate = "0" + strDate;
        }
        var currentdate = year + seperator1 + month + seperator1 + strDate
        //js自动获取当前日期前七天日期
        var date1 = new Date(date.getTime() - 6 * 24 * 3600 * 1000);
        var year1 = date1.getFullYear();
        var month1 = date1.getMonth() + 1;
        var day1 = date1.getDate();
        if (month1 >= 1 && month1 <= 9) {
            month1 = "0" + month1;
        }
        if (day1 >= 0 && day1 <= 9) {
            day1 = "0" + day1;
        }
        var sevenDayAgo = year1 + seperator1 + month1 + seperator1 + day1

        $scope.staInfo={
            "mTeacherRetentionseList": [
                {
                    "totalInstall": 0,
                    "installPeriod": "",
                    "retentionRateList": [
                        0
                    ]
                }
            ],
            "mStudentRetentionsList": [
                {
                    "totalInstall": 0,
                    "installPeriod": "",
                    "retentionRateList": [
                        0
                    ]
                }
            ],
            "teacherSize": 0,
            "studentSize": 0
        };
        //获取日期
        function getDate(){
            if(!$('#startDate').val()){
                startDate = sevenDayAgo;
            }else{
                startDate = $('#startDate').val();
            }
            if(!$('#endDate').val()){
                endDate = currentdate;
            }else{
                endDate = $('#endDate').val();
            }
        }
        //预加载日期
        getDate();
        $scope.newParam={
            startDate:startDate,
            endDate:endDate,
            periodType:periodType
        };
        $scope.param={
            name:""
        };
        $scope.newParam = {
            startDate: startDate,
            endDate: endDate,
            periodType: periodType
        };
        $scope.paramDate={
            name1:"1天后",
            name2:"2天后",
            name3:"3天后",
            name4:"4天后",
            name5:"5天后",
            name6:"6天后",
            name7:"7天后",
            name8:"14天后",
            name9:"30天后"
        };
        //预加载
        getdata()

        //点击获取教师用户统计
        $scope.getTech = function() {
            //改变两按钮颜色
            $("#teacher_btn").removeClass("btn btn-default countBtn");
            $("#teacher_btn").addClass("btn btn-default countBtnCheck");
            $("#student_btn").removeClass("btn btn-default countBtnCheck");
            $("#student_btn").addClass("btn btn-default countBtn");
            getDate();
            tag = "tec";
            $scope.newParam = {
                startDate: startDate,
                endDate: endDate,
                periodType: periodType
            };
            getdata();
        }
        //点击获取非教师用户统计
        $scope.getStud = function() {
            //改变两按钮颜色
            $("#student_btn").removeClass("btn btn-default countBtn");
            $("#student_btn").addClass("btn btn-default countBtnCheck");
            $("#teacher_btn").removeClass("btn btn-default countBtnCheck");
            $("#teacher_btn").addClass("btn btn-default countBtn");
            getDate();
            tag = "stu";
            $scope.newParam = {
                startDate: startDate,
                endDate: endDate,
                periodType: periodType
            };
            getdata();
        }
        //点击查询按钮
        $scope.selectData = function() {
            getDate();
            $scope.newParam = {
                startDate: startDate,
                endDate: endDate,
                periodType: periodType
            };
            getdata();
        }
        //点击按日走的按钮
        $scope.dailyData = function() {
            $("#d_btn").removeClass("btn btn-default btn-xs");
            $("#d_btn").addClass("btn btn-default btn-xs btnCheck");
            $("#w_btn").removeClass("btn btn-default btn-xs btnCheck");
            $("#w_btn").addClass("btn btn-default btn-xs");
            $("#m_btn").removeClass("btn btn-default btn-xs btnCheck");
            $("#m_btn").addClass("btn btn-default btn-xs");
            getDate();
            periodType = 1;
            $scope.newParam = {
                startDate: startDate,
                endDate: endDate,
                periodType: periodType
            };
            $scope.paramDate={
                name1:"1天后",
                name2:"2天后",
                name3:"3天后",
                name4:"4天后",
                name5:"5天后",
                name6:"6天后",
                name7:"7天后",
                name8:"14天后",
                name9:"30天后"
            };
            getdata();
        }
        //点击按周走的按钮
        $scope.weekData = function() {
            $("#d_btn").removeClass("btn btn-default btn-xs btnCheck");
            $("#d_btn").addClass("btn btn-default btn-xs");
            $("#w_btn").removeClass("btn btn-default btn-xs");
            $("#w_btn").addClass("btn btn-default btn-xs btnCheck");
            $("#m_btn").removeClass("btn btn-default btn-xs btnCheck");
            $("#m_btn").addClass("btn btn-default btn-xs");
            getDate();
            periodType = 2;
            $scope.newParam = {
                startDate: startDate,
                endDate: endDate,
                periodType: periodType
            };
            $scope.paramDate={
                name1:"1周后",
                name2:"2周后",
                name3:"3周后",
                name4:"4周后",
                name5:"5周后",
                name6:"6周后",
                name7:"7周后",
                name8:"8周后",
                name9:"9周后"
            };
            getdata();
        }
        //点击按月走的按钮
        $scope.mounthData = function() {
            $("#d_btn").removeClass("btn btn-default btn-xs btnCheck");
            $("#d_btn").addClass("btn btn-default btn-xs");
            $("#w_btn").removeClass("btn btn-default btn-xs btnCheck");
            $("#w_btn").addClass("btn btn-default btn-xs");
            $("#m_btn").removeClass("btn btn-default btn-xs");
            $("#m_btn").addClass("btn btn-default btn-xs btnCheck");
            getDate();
            periodType = 3;
            $scope.newParam = {
                startDate: startDate,
                endDate: endDate,
                periodType: periodType
            };
            $scope.paramDate={
                name1:"1月后",
                name2:"2月后",
                name3:"3月后",
                name4:"4月后",
                name5:"5月后",
                name6:"6月后",
                name7:"7月后",
                name8:"8月后",
                name9:"9月后"
            };
            getdata();
        }

        function  getdata(){
        countService.getRetainedUser($scope.newParam).then(function(res){
           console.log(res);
            //预加载和点击教师按钮
            if(tag =="tec") {
                $scope.param = {
                    name: "教师留存数量"
                };
                $scope.tableData = res.mTeacherRetentionseList;
            }else if(tag =="stu"){
                $scope.tableData = res.mStudentRetentionsList;
                $scope.param={
                    name:"非教师留存数量"
                };
            }
            //var list = [];
            //for(var i = 0; i < res.length; i++){
            //    var tableData = {
            //        time:res[i].time,
            //        addUser:res[i].addUser,
            //        time1:res[i].week1,
            //        time2:res[i].week2,
            //        time3:res[i].week3,
            //        time4:res[i].week4,
            //        time5:res[i].week5,
            //        time6:res[i].week6,
            //        time7:res[i].week7,
            //        time8:res[i].week8,
            //        time9:res[i].week9
            //    };
            //
            //    list.push(tableData);
            //}
            //
            //$scope.tableData = list;
        });
    }
    }
]);
/**
 * Created by Axiny on 2015/7/28.
 */
'use strict';//严格模式

var app = angular.module('routerApp');
app.controller('loginCtrl',[
        //注入部分
        '$scope',
        '$state',
        'loginService',
        function($scope,$state,loginService){
            deleteCookie("password");
            $scope.user =
            {
                "name":"",
                "password":""
            };

            $scope.promptMes="";

            $scope.login = function(){
                var name = $scope.user.name;
                var password = $scope.user.password;
                if(name==""){
                    //alert("请输入用户名！");
                    $scope.promptMes="请输入用户名！";
                    //alert($scope.promptMes);
                    $('#messages_model').modal('show');
                    return false;
                }else if(password==""){
                    //alert("请输入密码！");
                    $scope.promptMes="请输入密码！";
                    $('#messages_model').modal('show');
                    return false;
                }else{
                var user = {
                    name:$scope.user.name,
                    password:hex_md5($scope.user.password)
                };

                loginService.getLoginData(user).then(function(res){
                    switch (res.status){
                        case 200:{
                            $scope.message = "登录成功";
                            save_key("userName",$scope.user.name);
                            save_key("password",$scope.user.password);
                            localStorage.accessKey = res.data.mtoken.accessKey;
                            localStorage.securityKey = res.data.mtoken.securityKey;
                            $state.go('main.home');
                            break;
                        }
                        case 403:{
                            $scope.promptMes="登录失败，请检查用户名和密码是否正确！";
                            $('#messages_model').modal('show');
                            break;
                        }
                        case 404:{
                            $scope.promptMes="登录失败，用户名不存在！";
                            $('#messages_model').modal('show');
                            break;
                        }
                        default :{
                                $scope.promptMes="登录失败，请检查网络连接！";
                                $('#messages_model').modal('show');
                            break;
                        }
                    }
                });
            }
            }

        }
    ]
);

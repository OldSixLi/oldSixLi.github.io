var routerApp = angular.module('routerApp');
routerApp.controller('diagnosticCaseCtrl', ['$scope', '$state', 'FileUploader', 'contentModelService', '$sce', '$stateParams', 'loadingService', function ($scope, $state, FileUploader, cms, $sce, $stateParams, loadingService) {

    var msubject = cms.msubject;
    var soundPointGetSource = cms.soundPointGetSource;
    var illCaseOrList = cms.illCaseOrList;
    var illCase = cms.illCase;
    var illCaseChangeStatus = cms.illCaseChangeStatus;
    var localCaseImgUrlArr = cms.localCaseImgUrlArr;
    var soundPoint = cms.soundPoint;
    var msoundSource = cms.msoundSource;
    var qiniuSoundSourceUploadUrl = cms.qiniuSoundSourceUploadUrl;
    var qiniuHeart = cms.qiniuHeartUrl;

    var qiniu = cms.qiniu;

    //图片上传
    var uploadImgFile = cms.uploadImgFile;
    var getImgUrl = cms.getQiniuImgUrl;

    var $imgContainer = $('.diag-img-container > .row');
    var $diagPoint = $('ul.diag-point');
    var $diagContainer = $('.diag-img-detial-container');

    $scope.diagPoints = [];

    $scope.isView = $stateParams.isView;
    $scope.editMode = false;

    // $('#addDiagPointStatus').attr({
    //    disabled: 'disabled'
    // });

    if ($stateParams.editId) {
        $scope.editMode = true;
        console.log($stateParams.editId);
        illCase.get({
            id: $stateParams.editId
        }).$promise.then(function (data) {
            console.log(data);
            $scope.caseName = data.name;
            $scope.caseContent = data.content;
            $scope.previewCaseContent = $sce.trustAsHtml($scope.caseContent);
            $scope.diagResult = data.result;
            var ans = data.aidAndSidList;
            if (ans) {
                console.log(ans);
                ans.forEach(function (v, i) {
                    var analysis = JSON.stringify(v.analysis);
                    analysis = analysis.substring(1, analysis.length - 1);
                    analysis = encodeURIComponent(analysis);

                    aNameAndSidList.push({
                        aname: v.aname,
                        sname: v.sname,
                        analysis: analysis,
                        audioUrl: v.audioUrl,
                        second:  v.second
                    });
                });

                $scope.pointObj = {
                    name: aNameAndSidList[0].aname,
                    id: Date.now()
                };

                $scope.audioUrl = aNameAndSidList[0].audioUrl;
                $scope.analysis = aNameAndSidList[0].analysis;

                //初始化轮播图上的激活状态
                $scope.change3dPic(localCaseImgUrlArr[0], null, true);
            }
        }, function (err) {

        });
    }

    function fillModuleData(moduleId) {
        return msubject.get({moduleId: moduleId, page: 0, pageNum: 30}).$promise.then(function (data) {
            var mData = data.mAuscultationList;
            mData.forEach(function (v, i) {
                $scope.diagPoints.push({
                    mid: moduleId,
                    moudleName: moduleId == 1 ? '心音' : '呼吸音',
                    id: v.id,
                    name: v.name
                });
            });

        }).catch(function (err) {
            promptMessage({
                title: '网络跑偏了哦'
            });
        });
    }


    var heartSound = fillModuleData(1);
    var breathSound = fillModuleData(2);

    $scope.soundSearchKey = '';
    $scope.searchSoundSource = function () {
        console.log($scope.soundSearchKey);

        soundPointGetSource.get({
            sname: $scope.soundSearchKey,
            aid: $scope.selectedDiagPoint.id,
            page: 0,
            pageNum: 100
        }).$promise.then(function (data) {
            console.log(data);
            $scope.selectDiagPointSoundSource = data.soundSourceList;
        }, function (err) {
            console.log(err);
        });
    };
    $scope.selectDiagPointSoundSource = [];
    /*初始化音源列表*/
    $scope.changeSoundSource = function () {
        soundPointGetSource.get({
            aid: $scope.selectedDiagPoint.id,
            page: 0,
            pageNum: 30,
        }).$promise.then(function (data) {
            $scope.selectDiagPointSoundSource = data.soundSourceList;
        });
    }

    /*定义两个modal框*/
    var audioFileModal = $('#audioFile'),
        selectAudioModal = $('#selectAudio');

    /*弹出层的audio*/

    var $audioFileAudio = $('.MediaPlayBox audio');


    $scope.contentNameArray = [
        {id: 1, name: '音源'},
        {id: 2, name: '病例'}
    ];
    $scope.contentName = $scope.contentNameArray[1];

    var conentNameWatch = $scope.$watch('contentName', function (newVal, oldVal) {
        switch (newVal.name) {
            case '音源':
                $state.go('main.sound.soundSource');
                break;
            case '病例':
                $state.go('main.sound.case');
                break;
        }
    });

    function promptMessage(message) {
        $scope.promptMessage = message;
        $('#casePromptModal').modal('show');
    }


    /*init*/
    $scope.isEditModal = false;

    $scope.caseName = '';
    $scope.caseContent = '';
    $scope.diagPoint = '';
    $scope.diag3dPic = '';
    //3d诊听
    $scope.diagResult = '';

    $scope.promptMessage = '';

    /*初始化选择按钮*/
    $scope.selectedImg = localCaseImgUrlArr[0];
    $scope.localCaseImgUrlArr = localCaseImgUrlArr;
    $scope.selectedArrPoint = localCaseImgUrlArr[0].points;

    $scope.sName = '';
    $scope.showPointDetail = function (e, v) {
        $diagContainer.slideDown();
        $('.diag-point-name.active').removeClass('active');
        $(e.target).parents('.icon-container').siblings('.diag-point-name').addClass('active');
       clearPointDetailUi();
        aNameAndSidList.forEach(function (val, i) {
            if (v.name == val.aname) {
                var str = decodeURIComponent(val.analysis);
                str = str.replace(/\\\"/ig, '');
                $scope.analysis = str;
                $scope.audioUrl = val.audioUrl;
                $scope.sName = val.sname;
            }
        });
    };


    /*所有的即见即所得的编辑器*/
    /*通用配置*/
    var htmlRichTextOptions = {
        lang: 'zh-CN',
        popover: [
            ['imagesize', []]
        ],
        dialogsInBody: true,
        dialogsFade: false,
        airMode: false,
        disableDragAndDrop: true,
        toolbar: [
            ['style',['bold']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['link', ['linkDialogShow', 'picture']]
        ],
        height: '187px',

    };
    /*诊断解析*/

    $scope.caseContentOption = $.extend({}, htmlRichTextOptions, {
        placeholder: '请在此输入病例及详情',
    });
    $scope.diagAnalysisOption = $.extend({}, htmlRichTextOptions, {
        placeholder: '请输入诊断解析',
    });

    $scope.caseContentEditor = null;

    $scope.caseContentFileLimit = function (files) {
        var file = files[0];
        if (!file) {
            return;
        }
        if (file.type.indexOf('image') == -1) {
            $scope.$apply(function () {
                promptMessage({
                    title: '请上传图片类型文件'
                });
            });

            var $file = $('#caseContentContainer').find('[type=file]');
            $file[0].value = null;
            return ;
        }
        if (parseInt(file.size / 1024) > 100) {
            $scope.$apply(function () {
                promptMessage({
                    title: '请传小于100kb的图片'
                });
            });
            var $file = $('#caseContentContainer').find('[type=file]');
            $file[0].value = null;
            return;
        }
        uploadImgFile(file).then(function (data) {
            var imgUrl = getImgUrl + data.key;
            $scope.caseContentEditor.summernote('insertImage', imgUrl, function ($img) {
                $img.css({
                    "max-width": "100%"
                })
            });
        });
    };


    $scope.analysisEditor = null;

    $scope.analysisFileLimit = function (files, value) {
        if (!FileUploader) {
            promptMessage({
                title: '请使用现代浏览器上传图片'
            });
            return;
        }
        var file = files[0];
        if (!file) {
            return;
        }
        if (file.type.indexOf('image') == -1) {
            $scope.$apply(function () {
                promptMessage({
                    title: '请上传图片类型文件'
                });
            });
            var $file = $('.diag-analysis').find('[type=file]');
            $file[0].value = null;
            return ;
        }

        if (parseInt(file.size / 1024) > 100) {
            $scope.$apply(function () {
                promptMessage({
                    title: '请传小于100kb的图片'
                });
            });
            var $file = $('.diag-analysis').find('[type=file]');
            $file[0].value = null;
            return;
        }
        uploadImgFile(file).then(function (data) {
            var imgUrl = getImgUrl + data.key;
            $scope.analysisEditor.summernote('insertImage', imgUrl, function ($img) {
                $img.css({
                    "max-width": "100%"
                })
            });
        });
    };


    /*填充数据,从后台获得数据赋值*/
    /*听诊点每次只是请求一条数据就行*/

    /*听诊点名*/
    $scope.pointObj = '';
    /*诊断分析*/
    $scope.analysis = '';
    /*音源路径*/
    $scope.audioUrl =  ''

    /*给后台发送的数据*/
    // $scope.contentName.name
    // $scope.musicFile



    /*音源对象*/
    var caseMusic = $scope.caseMusic = new FileUploader({
        url: '',
        queueLimit: 1,     //文件个数
        removeAfterUpload: true   //上传后删除文件
    });
    $scope.$watch('audioUrl', function (newVal, oldVal) {
        $('.MediaPlayBox audio')[0].src = newVal;

        // $('.case3D_panel audio')[0].src = newVal;
    });
    caseMusic.onAfterAddingFile = displayMusic;

    function displayMusic(fileItem) {
        var file = $scope.musicFile = fileItem._file;
        if (file.type.indexOf('audio') != -1) {
            var url = window.URL.createObjectURL(file);
            $scope.audioUrl = url;
            $scope.soundSize = parseInt(file.size / 1024);
            var regExp = /\.[a-zA-Z0-9]+/ig;
            $scope.sName = file.name.replace(regExp, '');
            $scope.analysis = '';
            $('#addMusicFile').parent('.dropdown').removeClass('open');
            $('#musicFileForm').trigger('reset');
        } else {
            promptMessage({
                title: '请添加常规的音频文件'
            });
        }
        // $scope.currentDiagPoint.audio.audioUrl = url;
    }

    caseMusic.onSuccessItem = function (fileItem, response, status, headers) {
        // show success modal
    };

    $scope.isLocalAddSound = false;
    $scope.clearSoundMusicQueue = function (e) {
        // $(e.target).parents('.dropdown-menu').hide();
        $scope.isLocalAddSound = true;
        caseMusic.clearQueue(); //重新选择文件时，清空队列，达到覆盖文件的效果

    };

    /*event*/
    $scope.musicChange = function (obj) {
        var file = $scope.musicFile = obj.files[0];
        if (file.type.indexOf('audio') != -1) {
            var url = window.URL.createObjectURL(file);
            $scope.audioUrl = url;
            $scope.soundSize = parseInt(file.size / 1024);
            var regExp = /\.[a-zA-Z0-9]+/ig;
            $scope.sName = file.name.replace(regExp, '');
            $scope.analysis = '';
            $('#addMusicFile').parent('.dropdown').removeClass('open');
            $('#musicFileForm').trigger('reset');
        } else {
            promptMessage({
                title: '请添加常规的音频文件'
            });
        }

    };
    
    $scope.change3dPic = function (v, e, isFirst) {
        $('.diag-img-detial-container').slideUp(function () {
           clearPointDetailUi();
        });
        $('.pic-nav.active').removeClass('active');
        if (!isFirst) {
            $(e.target).addClass('active');
        }
        $scope.selectedImg = v;
        if (aNameAndSidList != '') {
            setTimeout(function () {
                v.points.forEach(function (point, i) {
                    aNameAndSidList.forEach(function (val, i) {
                        if (point.name == val.aname) {
                            var $point = $('[title='+ val.aname +']');
                            var $parent = $point.parent();
                            $parent.find('.glyphicon.glyphicon-pencil').show(0);
                            $parent.find('.glyphicon.glyphicon-trash').show(0);
                            $parent.find('.glyphicon.glyphicon-plus').hide(0);
                            $point.siblings('.icon-add').show(0);
                            $point.removeClass('active');
                        }
                    });
                });
            }, 100);
        }
    };


    $scope.selectedSoundSource = null;
    $scope.selectRadio = function (v) {
        $scope.selectedSoundSource = v;
    };
    $scope.soundSize = 0;
    $scope.addSoundSourceClick = function () {
        var sss = $scope.selectedSoundSource;
        if (sss) {
            $scope.sName = sss.name;
            // console.log(sss.content);
            // var str = decodeURIComponent(sss.content);
            // str = str.replace(/\\\"/ig, '');
            $scope.analysis = sss.content;
            $scope.audioUrl = sss.audioPath;
            // $scope.analysis = $sce.trustAsHtml(sss.content);
            $scope.soundSize = sss.size;
            $scope.isLocalAddSound = false;
            selectAudioModal.modal('hide');
        } else {
            promptMessage({
                title: '请选择音源再确定'
            })
        }
    };

    $scope.aNameAndSidList = aNameAndSidList = [];
    $scope.plusStatus = false;

    function isSelfPoint(e) {
        var $point = $('.diag-point-name.active');
        var aName = $.trim($point.text());
        var $parent = $point.parent();
        var $target = $(e.target);
        var $parentRel = $target.parents('li');
        var $pointRel = $parentRel.find('.diag-point-name');
        var aNameRel = $.trim($pointRel.text());

        if (aName != aNameRel) {
            return false;
        }
        return true;
    }
    $scope.addPointClick = function (e) {
        e.preventDefault();
        e.stopPropagation();
        saveSoundPoint(e);
        return false;
    };

    $diagContainer.slideUp();

    var selectPointName = '';
    $scope.slideDownPointDetail = function (e) {
        $diagContainer.slideDown();
        $('.diag-point-name.active').removeClass('active');
        var $point = $(e.target).parents('.icon-container').siblings('.diag-point-name');
        $point.addClass('active');
        clearPointDetailUi();
        selectPointName = $.trim($point.text());
        console.log(selectPointName);
    };

    $scope.slideUpPointDetail = function (e) {
        $diagContainer.slideUp(function () {
            clearPointDetailUi();
        });
    };

    function clearPointDetailUi() {
        $scope.analysis = '';
        $scope.audioUrl = '';
        $scope.sName = '';
    }

    //是添加还是修改
    function saveSoundPoint(e) {

        if ($scope.audioUrl != '') {
            loadingService.show();
            if ($scope.isLocalAddSound) {
                qiniu.get({type: 1}).$promise.then(function (data) {
                    console.log(data);
                    var formData = new FormData();
                    var token = data.uptoken;
                    formData.append('token', token);
                    formData.append('file', $scope.musicFile);
                    return $.ajax({
                        url: qiniuSoundSourceUploadUrl,
                        type: 'POST',
                        contentType: false,
                        processData: false,
                        data: formData
                    });
                }).then(function (data) {
                    console.log(data);
                    var url = qiniuHeart + data.key;
                    $scope.audioUrl = url;
                    saveSoundPointData()
                }, function (err) {
                    console.log(err);
                });
            } else {
                saveSoundPointData();
            }
        } else {
            promptMessage({
                title: '请填写完'
            });
        }
    }
    //是否本地添加还是音源库
    function saveSoundPointData() {
        var $point = $('.diag-point-name.active');
        var aName = $.trim($point.text());
        var $parent = $point.parent();
        var analysis = JSON.stringify($scope.analysis);
        analysis = analysis.substring(1, analysis.length - 1);

        const regExp = /font-size:\s*\w+.?\w+;/;
        analysis = analysis.replace(regExp, 'font-size:15px;');
        analysis = encodeURIComponent(analysis);

        for (var i = 0; i < aNameAndSidList.length; i++) {
            var v = aNameAndSidList[i];
            if (v.aname == aName) {
                aNameAndSidList.splice(i, 1);
            }
        }

        aNameAndSidList.push({
            aname: aName,
            sname: $scope.sName,
            analysis: analysis,
            audioUrl: $scope.audioUrl,
            second: parseInt($audioFileAudio[0].duration),
            size: $scope.soundSize
        });
        $point.siblings('.icon-add').show(300);
        $point.removeClass('active');
        $parent.find('.glyphicon.glyphicon-pencil').show(300);
        $parent.find('.glyphicon.glyphicon-trash').show(300);
        $parent.find('.glyphicon.glyphicon-plus').hide(300);
        $diagContainer.slideUp();
        clearPointDetailUi();
        loadingService.hide();
    }

    $scope.deleteDiagPoint = function (e) {
        var $target = $(e.target);
        var $parent = $target.parents('li');
        var $point = $parent.find('.diag-point-name');
        var aName = $.trim($point.text());
        for (var i = 0; i < aNameAndSidList.length; i++) {
            var v = aNameAndSidList[i];
            if (v.aname == aName) {
                promptMessage.bind(i)({
                    title: '确认删除?',
                    hasCancel: true,
                    confirmCallback: function () {
                        $diagContainer.slideUp();
                        aNameAndSidList.splice(i, 1);
                        $point.siblings('.icon-add').hide(300);
                        $point.removeClass('active');
                        $parent.find('.glyphicon.glyphicon-pencil').hide(300);
                        $parent.find('.glyphicon.glyphicon-trash').hide(300);
                        $parent.find('.glyphicon.glyphicon-plus').show(300)
                    }
                });
                return ;
            }
        }
    };

    $scope.editDiagPointClick = function (e, v) {
        $diagContainer.slideDown();
        $('.diag-point-name.active').removeClass('active');
        var $point = $(e.target).parents('.icon-container').siblings('.diag-point-name');
        $point.addClass('active');
        selectPointName = $.trim($point.text());
        clearPointDetailUi();

        aNameAndSidList.forEach(function (val, i) {
            if (v.name == val.aname) {
                var str = decodeURIComponent(val.analysis);
                str = str.replace(/\\\"/ig, '');
                $scope.analysis = str;
                $scope.audioUrl = val.audioUrl;
                $scope.sName = val.sname;
            }
        });


    };

    function showAudioFileModal() {
        selectAudioModal.modal('hide');
        audioFileModal.modal('show');
    }

    function showSelectAudio() {
        audioFileModal.modal('hide');
        selectAudioModal.modal('show');
    }

    $scope.showResourceSoundSource = function () {
        $scope.selectedSoundSource = null;
        $scope.selectedDiagPoint = $scope.diagPoints.filter(function (v) {
            return v.name == selectPointName;
        })[0];
        $scope.soundSearchKey = '';
        $scope.selectDiagPointSoundSource = [];
        $scope.changeSoundSource();
        showSelectAudio();
    };

    $scope.audioFileCancel = function () {
        $scope.caseMusic.clearQueue();
        $scope.currentDiagPoint = $scope.diagPoint.diagPoint;
    };

    $scope.previewClickHandle = function () {

        $scope.sAndArr =  JSON.parse(JSON.stringify($scope.aNameAndSidList));

        for (var i in $scope.sAndArr) {
            delete $scope.sAndArr[i].$$hashKey;
            var str = decodeURIComponent($scope.sAndArr[i].analysis);
            str = str.replace(/\\\"/ig, '');
            $scope.sAndArr[i].analysis = str;
        }
        if ($scope.caseContent) {
            $scope.previewCaseContent = $sce.trustAsHtml($scope.caseContent);
        } else {
            $scope.previewCaseContent =  $sce.trustAsHtml('病例内容');
        }


        $('#casePreviewModal').modal('show');
    }

    function saveData(isValid, callback) {
        callback = callback ? callback : function () {
                $state.go('main.sound.table');
            };


        if (!$scope.caseName) {
            promptMessage({
                title: '请填写病例名称'
            });
            return;
        }
        if (!$scope.caseContent) {
            promptMessage({
                title: '请填写病例内容'
            });
            return;
        }
        if (!$scope.diagResult) {
            promptMessage({
                title: '请填写诊断结果'
            });
            return;
        }
        const regExp = /font-size:\s*\w+.?\w+;/;
        var content = $scope.caseContent.replace(regExp, 'font-size:15px;');
        content = encodeURIComponent(content);
        var caseObj = {
            name: $scope.caseName,
            content: content,
            result: $scope.diagResult,
            isValid: isValid ? 0 : 1,
            aidAndSidList: aNameAndSidList
        };

        loadingService.show();

        if ($scope.editMode) {
            var editData = angular.extend(caseObj, {
                id: $stateParams.editId
            });
            illCase.editIll({
                id: $stateParams.editId
            }, editData).$promise.then(function (data) {
                console.log(data);
                loadingService.hide();
                promptMessage({
                    title: '成功',
                    confirmCallback: callback
                });
            }, function (err) {
                console.log(err)
                loadingService.hide();
                promptMessage({
                    title: '失败'
                });
            });
        } else {
            illCaseOrList.addIll({
                mid: 1
            }, caseObj).$promise.then(function (data) {
                console.log(data);
                loadingService.hide();
                promptMessage({
                    title: '成功',
                    confirmCallback: callback
                })
            }, function (err) {
                loadingService.hide();
                console.log(err);
                if (err.data && err.data.message == '病历名称已存在') {
                    promptMessage({
                        title: err.data.message
                    });
                    return;
                }
                promptMessage({
                    title: '失败'
                });
            });
        }
    }
    $scope.saveCaseClick = function () {
        saveData(false);
    };

    $scope.saveEditCaseClick = function () {
        saveData(false);
    };

    $scope.saveEditCaseAndGo = function () {
        saveData(false, function () {
           console.log('success')
        });
    };

    function clearAllModelData() {
        $diagContainer.slideUp();
        aNameAndSidList = [];
        $scope.diagResult = '';
        $scope.caseContent = '';
        $scope.caseName = '';
        showAddPoint();
        $('.glyphicon.glyphicon-ok').hide();
    }

    $scope.saveAndGoOn = function () {
        saveData(false, clearAllModelData);
    };

    $scope.publishCase = function () {
        // if ($scope.editMode) {
        //     illCaseChangeStatus.changeIllStatus({
        //         id: $stateParams.editId
        //     }, {
        //         id: $stateParams.editId,
        //         isValid: 0
        //     }).$promise.then(function (data) {
        //         console.log(data);
        //         promptMessage({
        //             title: '发布成功',
        //             confirmCallback: function () {
        //                 $state.go('main.sound.table');
        //             }
        //         });
        //     }, function (err) {
        //         console.log(err);
        //         promptMessage({
        //             title: '发布失败\n'
        //         });
        //     });
        // } else {
            saveData(true);
        // }
    };


    $scope.goBacktoTable = function () {
        $state.go('main.sound.table') ;
    };

    function showEditPoint() {
        $('.diag-img-container .glyphicon.glyphicon-plus').hide(0);
        $('.diag-img-container .glyphicon.glyphicon-pencil').show(0);
        $('.diag-img-container .glyphicon.glyphicon-trash').show(0);
    }
    function showAddPoint() {
        $('.diag-img-container .glyphicon.glyphicon-plus').show(0);
        $('.diag-img-container .glyphicon.glyphicon-pencil').hide(0);
        $('.diag-img-container .glyphicon.glyphicon-trash').hide(0);
    }

    $('#caseImg').on('load', function () {
        $(window).trigger('resize');
        if (!$('.pic-nav').hasClass('active')) {
           $('.pic-nav').eq(0).addClass('active');
        }
        if ($scope.editMode || $scope.isView) {
            showEditPoint();
        } else {
            showAddPoint();
        }
    });

    var resizeSoundPointHeight = function () {
        $diagPoint.css({
            height: $('#caseImg').height()
        });
    };
    $(window).off('resize', resizeSoundPointHeight);
    $(window).on('resize', resizeSoundPointHeight);

    if(!isLogin())
    {
        $state.go('login');
    }


}]);
﻿var routerApp = angular.module('routerApp');
routerApp.controller('diagnosticCtrl', ['$scope', '$state', 'contentModelService', function ($scope, $state, cms ) {
    var msubject = cms.msubject;
    var soundPoint = cms.soundPoint;

    $state.go('main.sound.table');
    // 模仿 json 可以直接复制到

    $scope.items = [
        {
            "id": 1,
            "itemName": "心音",
            "itemArray": []
        },
        {
            "id": 2,
            "itemName": "呼吸音",
            "itemArray": []
        }
    ];
    
    function fillModuleData(moduleId, itemsId) {
        return msubject.get({moduleId: moduleId, page: 0, pageNum: 30}).$promise.then(function (data) {
            var mData = data.mAuscultationList;
            var itemArray = [];
            mData.forEach(function (v, i) {
                itemArray.push({
                    soundName: v.name,
                    soundInstruction: v.desc,
                    id: v.id
                });
            });
            $scope.items[itemsId].itemArray = itemArray;
        }).catch(function (err) {
            console.log(err);
            promptMessage({
                title: '网络出错'
            });
        });
    }

    var heartSound = fillModuleData(1, 0);
    var breathSound = fillModuleData(2, 1);


    var deleteModal = 'delete',
        addModal = 'add',
        editModal = 'edit';


    function promptMessage(message) {
        $scope.promptMessage = message;
        $('#promptModal').modal('show');
    }

    function dataBind(bindObj) {
        $scope.modalMessage = bindObj.modalMessage || {title: '出错了'};
        $scope.modalType = bindObj.modalType || '未知模态框';
        $scope.currentId = bindObj.currentId || 1;
        $scope.currentItem = bindObj.currentItem || {};
        $scope.currentItemIndex = bindObj.currentItemIndex || 0;
        $('#diagnosticModal').modal('show');
    }


    $scope.currentItem = $scope.items[0];

    $scope.currentId = 1;

    $scope.currentItemIndex = 0;

    /*每个听诊点的对象*/
    $scope.soundPointId = 0;

    /*默认弹出框是增加框*/
    $scope.modalType = addModal;

    /*显示隐藏后面的编辑和删除按钮*/
    $scope.itemClickHandle = function (e, v) {
        var currentTarget = e.currentTarget;
        var $target = $(e.target);
        $('.treeView ul ul li span:nth-of-type(2)').removeClass('show-inline').removeClass('hide-none');
        $('span:nth-of-type(2)', currentTarget).addClass('show-inline');
        if ($target.data('click')) {
            $state.go('main.sound.table', {pointId: v.id, pointName: v.soundName});
        }
    };

    $scope.goToCase = function () {
        $state.go('main.sound.table', {pointId: "case_id"});
    };


    /*add click animate*/
    $scope.clickAnimateDropdown = function (e) {
        var $target = $(e.target);
        if ($target[0].tagName.toLowerCase() == 'li') {
            $target.toggleClass('active');
            $target.find('> ul').slideToggle();
        }
        if ($target[0].tagName.toLowerCase() == 'span') {
            if ($.trim($target.text()) == '心音') {
                $state.go('main.sound.table', {pointId: "心音"});
            } else if ($.trim($target.text()) == '呼吸音') {
                $state.go('main.sound.table', {pointId: "呼吸音"});
            }
        }
    };
    /*显示添加modal*/

    $scope.addClickHandle = function (e, moduleId) {
        $scope.cTimestamp = new Date().getTime();
        $('#diagnosticModal').modal('show');
        dataBind({
            modalMessage: {
              title: '添加'
            },
            modalType: addModal,
            currentItem: this.item,
            currentId: this.item.id,
        });
    }

    /*显示编辑modal*/
    $scope.editClickHandle = function (e, index, v) {
        $scope.soundPointId = v.id;

        var item = this.$parent.item;
        dataBind({
            modalMessage: {
                title: '修改'
            },
            currentId: item.id,
            currentItem: item,
            currentItemIndex: index,
            modalType: editModal
        });
        $scope.editModal = {
            soundName: this.v.soundName,
            soundInstruction: this.v.soundInstruction
        };
    }

    $scope.deleteClickHandle = function (e, index, id) {

        $scope.soundPointId = id;

        /*可以给后台发送 当前item 和 删除对象的数组下标*/

        var item = this.$parent.item;

        dataBind({
            modalMessage: {
              title: '确认删除吗?'
            },
            modalType: deleteModal,
            currentItem: item,
            currentId: item.id,
            currentItemIndex: index

        });
    }

    $scope.onClickHandle = function (itemId, soundName, soundInstruction, modalType) {
        /*隐藏modal 显示loading*/


        $('#diagnosticModal').modal('hide');


        /*先判断是添加还是修改*/
        if (modalType == addModal) {
            /*添加*/
            /*发送http  应该只有soundName, soundInstruction, modalType(修改类型) currentItem.id(音源)*/
            msubject.addDiagPoint({
                moduleId: itemId,
            }, {
                name: soundName,
                desc: soundInstruction,
            }, function (data) {
                console.log(data);
                $scope.items[itemId - 1].itemArray.push({
                    soundName: soundName,
                    soundInstruction: soundInstruction,
                    id: data.id
                });
                promptMessage({
                    title: '添加成功'
                });

            }, function (err) {
               console.log(err);
                promptMessage({
                    title: '添加失败'
                });
            });

        } else if (modalType == editModal){
            /*修改*/
            /*如果一样, 就直接返回不用发送请求*/
            var currentSoundPoint = $scope.currentItem.itemArray[$scope.currentItemIndex];
            if (soundName == currentSoundPoint.soundName && soundInstruction == currentSoundPoint.soundInstruction && itemId == $scope.currentId) {
                return;
            }

            /*发送http请求接受promise对象*/
            console.log($scope.soundPointId);
            soundPoint.put({
               aid: $scope.soundPointId,
            }, {
                name: soundName,
                desc: soundInstruction
            }).$promise.then(function (data) {
               console.log(data);
                if (itemId != $scope.currentId) {
                    $scope.currentId = itemId;
                    $scope.currentItem.itemArray.splice($scope.currentItemIndex, 1);
                    $scope.items[itemId - 1].itemArray.push(
                        {
                            soundName: soundName,
                            soundInstruction: soundInstruction,
                            id: $scope.soundPointId
                        }
                    )
                } else {
                    $scope.items[itemId - 1].itemArray[$scope.currentItemIndex] = {
                        soundName: soundName,
                        soundInstruction: soundInstruction,
                        id: $scope.soundPointId
                    };
                }

                promptMessage({
                    title: '修改成功'
                });
            }).catch(function (err) {
               console.log(err);
                promptMessage({
                    title: '修改失败'
                });
            })
        } else if (modalType == deleteModal) {
            /*如果修改成功*/
            soundPoint.delete({
                aid: $scope.soundPointId
            }, function (data) {
                console.log(data);
                $scope.currentItem.itemArray.splice($scope.currentItemIndex, 1);
                promptMessage({
                    title: '删除成功'
                });
            }, function (err) {
                console.log(err)
                var data = err.data.message || '删除失败';
                promptMessage({
                    title: data
                });
            });

        }

    }

    if(!isLogin())
    {
        $state.go('login');
    }

}])
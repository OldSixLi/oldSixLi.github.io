var routerApp = angular.module('routerApp');
routerApp.controller('diagnosticTableCtrl', ['$scope', '$state', 'contentModelService', '$stateParams', 'loadingService', function ($scope, $state, cms, $stateParams, loadingService) {
    var msoundSource = cms.msoundSource;
    var soundPoint = cms.soundPoint;
    var illCase = cms.illCase;
    var soundPointGetSource = cms.soundPointGetSource;

    /*先获得所有听诊点*/

    var soundPage = 0, illPage = 0;
    var soundPageNum = 10, illPageNum = 10;
    var soundTotalNum = 0, illTotalNum = 0;

    /*1为音源*/
    $scope.tableType = 1;

    $scope.isEmpty = false;

    /*翻页的配置项*/
    $scope.paginationConf =
        {
            currentPage: 0,     //初始页码
            itemsPerPage: 10,   //每页显示条目
            totalItems: 0
        };

    function fillIllCaseData(routerArgObj) {
        loadingService.show();
        illCase.get(routerArgObj).$promise.then(function (data) {
            $scope.paginationConf.totalItems = data.totalNum;
            if (data.totalNum == 0) {
                $scope.isEmpty = true;
            } else {
                $scope.isEmpty = false;
            }
            var illDataArr = [];
            data.mDiagnosisCaseList.forEach(function (v, i) {
                var publish = v.isValid == 0 ? '发布' : '未发布';
                illDataArr.push({
                    id: v.id,
                    title: v.name,
                    public: publish
                });
            });
            $scope.illCaseArr = illDataArr;
            loadingService.hide();
        }).catch(function (err) {
            console.log(err)
            promptMessage({
                title: '加载失败'
            });
            loadingService.hide();
        })
    }


    function fillSoundSourceData(routerArgObj) {
        loadingService.show();
        var mssObj = msoundSource.get(routerArgObj, function () {
            soundTotalNum = mssObj.totalNum;
            $scope.paginationConf.totalItems = soundTotalNum;
            if (soundTotalNum == 0) {
                $scope.isEmpty = true;
            } else {
                $scope.isEmpty = false;
            }

            var arr = [];
            mssObj.soundSourceList.forEach(function (v, i) {
                var type = v.type == 1 ? '心音' : '呼吸音';
                var publish = v.isValid == 0 ? '发布' : '未发布';
                var diagPoints = [];
                var getDiagPointsArr = v.mAuscultationList.mAuscultationList;
                if (getDiagPointsArr) {
                    getDiagPointsArr.forEach(function (v, i) {
                        diagPoints.push(v.name);
                    });
                }
                diagPoints = diagPoints.join(', ');
                diagPoints = type + '/' + diagPoints;
                arr.push({
                    id: v.id,
                    type: type,
                    title: v.name,
                    module: diagPoints,
                    publish: publish
                });
            });
            $scope.resData = arr;
            loadingService.hide();
        }, function (err) {
            console.log(err)
            promptMessage({
                title: '加载失败'
            });
        });
    }

    $scope.initTableData = function () {
        if ($stateParams.pointId) {
            loadingService.show();

            if ($stateParams.pointId == 'case_id') {
                $scope.tableType = 0;
                fillIllCaseData({
                    page: 0,
                    pageNum: illPageNum
                });

            } else if ($stateParams.pointId == '心音') {
                fillSoundSourceData({
                    page: 0,
                    pageNum: soundPageNum,
                    key: '',
                    type: 1
                });
            } else if ($stateParams.pointId == '呼吸音') {
                fillSoundSourceData({
                    page: 0,
                    pageNum: soundPageNum,
                    key: '',
                    type: 2
                });
            } else {
                soundPointGetSource.get({
                    aid: $stateParams.pointId,
                    page: soundPage,
                    pageNum: soundPageNum
                }).$promise.then(function (data) {
                    $scope.paginationConf.totalItems = data.totalNum;
                    var arr = [];
                    var name = $stateParams.pointName;
                    console.log(name);
                    data.soundSourceList.forEach(function (v, i) {
                        var type = v.type == 1 ? '心音' : '呼吸音';
                        var publish = v.isValid == 0 ? '发布' : '未发布';
                        arr.push({
                            id: v.id,
                            type: type,
                            title: v.name,
                            module: name,
                            publish: publish
                        });
                    });
                    $scope.resData = arr;
                    $scope.isEmpty = false;
                    loadingService.hide();
                }, function (err) {
                    loadingService.hide();
                    promptMessage({
                        title: '出现出错'
                    });
                    console.log(err);
                });
            }

        } else {
            /*一上来先填充一下音源的数据*/
            fillSoundSourceData({
                page: soundPage,
                pageNum: soundPageNum,
            });
        }

        $scope.searchText = '';
    }

    $scope.initTableData();

    /*提示框*/
    function promptMessage(message) {
        $scope.promptMessage = message;
        $('#soundTablePromptModal').modal('show');
    }

    /*选择框*/
    $scope.selectBoxs = [];

    /*全选*/
    $scope.selectedAll = function (e) {
        $scope.selectBoxs = [];
        var $target = $(e.target);
        var $checkboxItem = $('.checkbox-item');
        if ($target[0].checked == true) {
            $checkboxItem.prop('checked', true);
            $checkboxItem.each(function (i, v) {
                var id = $(v).data('id');
                $scope.selectBoxs.push(id);
            });
        } else {
            $checkboxItem.prop('checked', false);
            $scope.selectBoxs = [];
        }
    };

    /*搜索*/
    $scope.searchText = '';
    var searchType = '';
    $scope.changeSearchKey = function (e, flag) {
        $('.js-search-flag.active').removeClass('active');
        $(e.target).addClass('active');
        switch (flag) {
            case 'all':
                searchType = '';
                break;
            case 'breath':
                searchType = 2;
                break;
            case 'heart':
                searchType = 1;
                break;
            default:
                searchType = '';
        }
    };
    $scope.soundTableSearch = function (reset) {
        if ($scope.tableType) {
            if ($scope.searchText == '心音') {
                fillSoundSourceData({
                    page: 0,
                    pageNum: soundPageNum,
                    key: '',
                    type: 1
                });
            } else if ($scope.searchText == '呼吸音') {
                fillSoundSourceData({
                    page: 0,
                    pageNum: soundPageNum,
                    key: '',
                    type: 2
                });

            } else {
                if (reset) {
                    $scope.searchText = '';
                }
                fillSoundSourceData({
                    page: 0,
                    pageNum: soundPageNum,
                    key: $scope.searchText,
                    type: ''
                });
            }

        } else {
            if (reset) {
                $scope.searchText = '';
            }
            fillIllCaseData({
                page: 0,
                pageNum: illPageNum,
                key: $scope.searchText
            });
        }
    };


    /*翻页请求数据*/
    $scope.getUserData = function (page) {
        $scope.selectBoxs = [];
        /*1是音源*/
        $('[type=checkbox]').prop('checked', false);
        if ($scope.tableType) {
            if ($scope.searchText == '心音' || $stateParams.pointId == '心音') {
                fillSoundSourceData({
                    page: page - 1,
                    pageNum: soundPageNum,
                    key: '',
                    type: 1
                });
            } else if ($scope.searchText == '呼吸音' || $stateParams.pointId == '呼吸音') {
                fillSoundSourceData({
                    page: page - 1,
                    pageNum: soundPageNum,
                    key: '',
                    type: 2
                });

            } else {
                fillSoundSourceData({
                    page: page - 1,
                    pageNum: soundPageNum,
                })
            }

        } else {
            fillIllCaseData({
                page: page - 1,
                pageNum: illPageNum,
            })
        }

    };


    /*添加*/
    $scope.addItem = function () {
        $state.go('main.sound.soundSource');
    };

    $scope.editSoundSource = function (id) {
        $state.go('main.sound.soundSource', {editId: id});
    }

    /*病例的修改*/
    $scope.editCase = function (id) {
        $state.go('main.sound.case', {editId: id});
    };


    $scope.viewSoundSource = function (id) {
        $state.go('main.sound.soundSource', {editId: id, isView: true});
    };

    $scope.viewCase = function (id) {
        $state.go('main.sound.case', {editId: id, isView: true});
    };

    $scope.showSoundSourceTable = function (e) {
        if ($scope.tableType = 0) {
            $scope.selectBoxs = [];
        }
        $scope.tableType = 1;
        $scope.paginationConf.currentPage = 1;
        fillSoundSourceData({
            page: 0,
            pageNum: soundPageNum
        });
    };

    $scope.showIllCaseTable = function () {
        if ($scope.tableType = 1) {
            $scope.selectBoxs = [];
        }
        $scope.tableType = 0;
        $scope.paginationConf.currentPage = 1;
        fillIllCaseData({
            page: 0,
            pageNum: illPageNum
        });
    };


    $scope.updateCheckBox = function (e, data) {
        var target = e.target;

        if (target.checked != true) {
            var idx = $.inArray(data.id, $scope.selectBoxs);
            if (idx != -1) {
                $scope.selectBoxs.splice(idx, 1);
                target.checkedid = null;
            }
        } else {
            $scope.selectBoxs.push(data.id);
            target.checkedid = data.id;
        }

        var checkBoxNums = $('.js-checkbox').length;
        if ($scope.selectBoxs.length < checkBoxNums) {
            $('.js-select-all').prop("checked", false);
        } else {
            $('.js-select-all').prop("checked", true);
        }
    };

    /*删除*/
    var deleteItem = function (id, type) {
        if (type == 'sound') {
            var isDeleteSuc = false;
            $scope.resData.forEach(function (v, i) {
                if (i == id) {
                    $scope.resData.splice(i, 1);
                    isDeleteSuc = true;
                }
            });
            return isDeleteSuc;
        } else if (type == 'case') {
            var isDeleteSuc = false;
            $scope.illCaseArr.forEach(function (v, i) {
                if (i == id) {
                    $scope.illCaseArr.splice(i, 1);
                    isDeleteSuc = true;
                }
            });
            return isDeleteSuc;
        }

    };

    $scope.deleteItem = function (index, e, id, type) {

        promptMessage({
            title: '确认删除?',
            hasCancel: true,
            confirmCallback: function () {
                var target = e.target;
                var checkboxId = $(target).parents('.content-edit-delete').siblings('.js-checkbox').children('input')[0].checkedid;
                if ($scope.selectBoxs != '') {
                    $scope.selectBoxs.forEach(function (v, i) {
                        if (v == checkboxId) {
                            $scope.selectBoxs.splice(i, 1);
                        }
                    });
                }
                if (type == 'sound') {
                    msoundSource.delete({
                        id: id
                    }).$promise.then(function (data) {
                        console.log(data);
                        if (deleteItem(index, 'sound')) {
                        }
                    }, function (err) {
                        console.log(err);
                    })
                } else if (type == 'case') {
                    illCase.delete({
                        id: id
                    }).$promise.then(function (data) {
                        console.log(data);
                        if (deleteItem(index, 'case')) {
                        }
                    }, function (err) {
                        promptMessage({
                            title: '删除失败'
                        });
                    })
                }
            }
        });

    };

    $scope.deleteItems = function () {
        if ($scope.selectBoxs == '') {
            promptMessage({
                title: '请选择需要删除的音源或病例'
            });
            return;
        }

        promptMessage({
            title: '确认删除?',
            hasCancel: true,
            confirmCallback: function () {
                loadingService.show();
                //tableType == 1 的时候为音源
                if ($scope.tableType == 1) {

                    cms.soundSourceDeletes($scope.selectBoxs).then(function (data) {
                        loadingService.hide();
                        for (var i = 0; i < $scope.selectBoxs.length; i++) {
                            for (var j = 0; j < $scope.resData.length; j++) {
                                var v = $scope.resData[j];
                                if (v.id == $scope.selectBoxs[i]) {
                                    $scope.resData.splice(j, 1);
                                }
                            }
                        }
                        $scope.selectBoxs = [];
                        $scope.$apply(function () {
                            promptMessage({
                                title: '删除成功'
                            });
                        });
                    }, function (err) {
                        console.log(err);
                        loadingService.hide();
                        $scope.$apply(function () {
                            promptMessage({
                                title: '删除失败'
                            });
                        });
                    });
                } else if ($scope.tableType == 0) {
                    cms.illDeletes($scope.selectBoxs).then(function (data) {
                        for (var i = 0; i < $scope.selectBoxs.length; i++) {
                            for (var j = 0; j < $scope.illCaseArr.length; j++) {
                                var v = $scope.illCaseArr[j];
                                if (v.id == $scope.selectBoxs[i]) {
                                    $scope.illCaseArr.splice(j, 1);
                                }
                            }
                        }
                        $scope.selectBoxs = [];
                        loadingService.hide();
                        $scope.$apply(function () {
                            promptMessage({
                                title: '删除成功'
                            });
                        });
                    }, function (error) {
                        $scope.$apply(function () {
                            promptMessage({
                                title: '删除失败'
                            });
                        });
                        loadingService.hide();
                    });
                }
            }
        });


    };

    if (!isLogin()) {
        $state.go('login');
    }

}]);
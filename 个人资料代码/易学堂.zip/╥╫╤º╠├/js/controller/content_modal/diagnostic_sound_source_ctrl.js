var routerApp = angular.module('routerApp');
routerApp.controller('diagnosticSoundSourceCtrl', ['$scope', '$state', 'FileUploader', 'loadCtrl', 'contentModelService', 'loadingService', '$stateParams', function ($scope, $state, FileUploader,loadCtrl, cms, loadingService, $stateParams) {

    var msubject = cms.msubject;
    var qiniu = cms.qiniu;
    var msoundSource = cms.msoundSource;
    var msoundSourceChangeStatus = cms.msoundSourceChangeStatus;

    var qiniuSoundSourceUploadUrl = cms.qiniuSoundSourceUploadUrl;
    var getQiniuHeartUrl = cms.qiniuHeartUrl;

    var uploadImgFile = cms.uploadImgFile;
    var getImgUrl = cms.getQiniuImgUrl;

    $scope.isView = $stateParams.isView;


    /*声音控件*/
    /*添加音源的audio*/
    var $soundSourceAudio = $('.sound_panel audio');

    $scope.editMode = false;
    $scope.editModeClear = true;
    /*先判断是否是编辑模式*/
    if ($stateParams.editId) {
        $scope.editMode = true;
        msoundSource.get({
            id: $stateParams.editId
        }).$promise.then(function (data) {
            console.log(data);
            $scope.setSSO.soundName = data.name;
            $scope.setSSO.diagResult = data.result;
            $scope.setSSO.analysisDiag = data.content;
            $soundSourceAudio.attr({
                src: data.audioPath,
                controls: 'controls'
            });
            var mData = data.mAuscultationList.mAuscultationList;
            mData.forEach(function (v, i) {
                $scope.selectedDiagPoint.push({
                    id: v.id
                });
            });
            var oData = data.mOptionList.mOptionList;
            oData.forEach(function (v, i) {
                $scope.setSSO.identifyDiag.push({
                    id: v.id,
                    value: v.content
                });
            });
            $scope.editModeClear = false;
            // $scope.setSSO.identifyDiag.push()
        }, function (err) {
            console.log(err)
        });
    } else {

    }

    var isValid = false;
    /*获取听诊点*/
    /*此处获取配置数据*/
    $scope.selectedDiagPoint = [];
    $scope.diagPoint = [];

    function fillModuleData(moduleId) {
        loadingService.show();
        return msubject.get({moduleId: moduleId, page: 0, pageNum: 30}).$promise.then(function (data) {
            loadingService.hide();
            var mData = data.mAuscultationList;
            mData.forEach(function (v, i) {
                $scope.diagPoint.push({
                    mid: moduleId,
                    moudleName: moduleId == 1 ? '心音' : '呼吸音',
                    id: v.id,
                    name: v.name
                });
            });
        }).catch(function (err) {
            promptMessage({
                title: '网络中断'
            });
        });
    }


    var heartSound = fillModuleData(1);
    var breathSound = fillModuleData(2);



    $scope.$watch('contentName', function (newVal, oldVal) {
        switch (newVal.name) {
            case '音源':
                $state.go('main.sound.soundSource');
                break;
            case '病例':
                $state.go('main.sound.case');
                break;
        }
    });

    $scope.promptMessage = '';
    function promptMessage(message) {
        $scope.promptMessage = message;
        $('#soundSourcePromptModal').modal('show');
    }

    /*定义viewModel 获得后台数据*/
    /*SSO soundSourceObj attr*/
    var getSSO = {};

    $scope.contentNameArray = [
        {id: 1, name: '音源'},
        {id: 2, name: '病例'}
    ];
    $scope.contentName = $scope.contentNameArray[0];
    var setSSO = $scope.setSSO =  $.extend({
        soundName: '',
        diagResult: '',
        analysisDiag: '',
        identifyDiag: [
            {
                id: Date.now()
            }
        ]
    }, getSSO);

    $scope.selectedDiagPoint = [];
    /*所有音乐文件字段*/
    $scope.musicFiles = [];
    $scope.pic3dFile = '';
    /*单选题*/

    /*初始化字段*/
    $scope.diagPoint = [];



    /*所有的即见即所得的编辑器*/
    /*通用配置*/
    var htmlRichTextOptions = {
        lang: 'zh-CN',
        popover: [
            ['imagesize', []]
        ],
        dialogsInBody: true,
        dialogsFade: false,
        airMode: false,
        disableDragAndDrop: true,
        toolbar: [
            ['style',['bold']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['link', ['linkDialogShow', 'picture']]
        ],
    };

    $scope.analysisEditor = null;

    $scope.analysisFileLimit = function (files, value) {
        var file = files[0];
        if (!file) {
           return;
        }
        console.log(file.type.indexOf('image'));
        if (file.type.indexOf('image') == -1) {
            $scope.$apply(function () {
                promptMessage({
                    title: '请上传图片类型文件'
                });
            });
           var $file = $('#picUploadContainer').find('[type=file]');
           $file[0].value = null;
            return ;
        }
        if (parseInt(file.size / 1024) > 100) {
            $scope.$apply(function () {
                promptMessage({
                    title: '请传小于100kb的图片'
                });
            });
            var $file = $('#picUploadContainer').find('[type=file]');
            $file[0].value = null;
            return;
        }
        uploadImgFile(file).then(function (data) {
            var imgUrl = getImgUrl + data.key;
            $scope.analysisEditor.summernote('insertImage', imgUrl, function ($img) {
                $img.css({
                    "max-width": "100%"
                })
            });
        });

    };

    $scope.analysisDiagOption = angular.extend(htmlRichTextOptions, {
        placeholder: '请输入诊断解析',
        height: '187px',
    });


    /*音源对象*/
    var soundSourceMusic = $scope.soundSourceMusic = new FileUploader({
        url: '',
        queueLimit: 1,     //文件个数
        removeAfterUpload: true   //上传后删除文件
    });

    soundSourceMusic.onAfterAddingFile = displayMusic.bind(null, $('.sound_panel audio'));

    var $audio = null;
    function displayMusic(audioObj, fileItem) {
        var file = $scope.musicFile = fileItem._file;

        if (file.type.indexOf("audio") != -1) {
            $scope.soundSize = parseInt(file.size / 1024);
            var url = window.URL.createObjectURL(file);
            $audio = $(audioObj);
            $audio[0].src = url;
            $audio[0].controls = 'controls';
        } else {
            promptMessage({
                title: '请添加常规的音频文件'
            });
        }

    }

    $scope.clearSoundMusicQueue = function () {
        soundSourceMusic.clearQueue(); //重新选择文件时，清空队列，达到覆盖文件的效果
    }


    /*event*/

    $scope.identifyDiagAdd = function () {
        if (!$scope.isView) {
            setSSO.identifyDiag.push({
                id: Date.now(),
                value: ''
            });
        }
    };

    $scope.identifyDiagMinus = function (index) {
        if (!$scope.isView) {
            setSSO.identifyDiag.splice(index, 1);
        }
    }


    function isEmpty() {

        if (!!$scope.setSSO.soundName == '') {
            promptMessage({
                title: '请填写音源名称'
            });
            return false;
        }

        var isOnly = [];
        if ($scope.selectedDiagPoint == '') {
            promptMessage({
                title: '请选择所属听诊点',
            });
            return false;
        }
        if (!!$scope.setSSO.diagResult == '') {
            promptMessage({
                title: '请填写诊断结果'
            });
            return false;
        }

        for (var sdp in $scope.selectedDiagPoint) {
            if ($scope.selectedDiagPoint[sdp].mid == 1) {
                isOnly[0] = 1;
            } else if ($scope.selectedDiagPoint[sdp].mid == 2) {
                isOnly[1] = 2;
            }
        }

        if ( typeof isOnly[0] != 'undefined' && typeof isOnly[1] != 'undefined') {
            promptMessage({
                title: '一个音源不能同时属于心音和呼吸音'
            });
            return false;
        }
        if ($soundSourceAudio.attr('src') == '') {
            promptMessage({
                title: '请添加音源'
            });
            return false;
        }

        var mid = $scope.selectedDiagPoint[0].mid;
        /*听诊点id数组*/
        var mids = [];
        for (var v in $scope.selectedDiagPoint) {
            mids.push($scope.selectedDiagPoint[v].id);
        }
        /*界别听诊的value*/
        var identifyDiagList = [];
        for (var v in $scope.setSSO.identifyDiag) {
            if (v != 0) {
                identifyDiagList.push($scope.setSSO.identifyDiag[v].value)
            }
        }

        if (mids == '') {
            promptMessage({
                title: '请添加所属听诊点',
            });
            return false;
        }

        if ($scope.setSSO.analysisDiag == '') {
            promptMessage({
                title: '请填写诊断解析',
            });
            return false;
        }

        var isEmpty = identifyDiagList.some(function (element) {
           return element == '';
        });
        if (isEmpty || identifyDiagList == '') {
            promptMessage({
                title: '请添加鉴别听诊'
            });
            return false;
        }


        return {
            mid: mid,
            mids: mids,
            identifyDiagList: identifyDiagList
        };
    }

    /**
     *
     * @param isValid 如果是true 就是发布
     */
    function saveData(isValid, callback) {
        if (!callback) {
            callback = function () {
                $state.go('main.sound.table');
            };
        }
        var transferObj = {};
        var formData = new FormData();
        var valueNotEmpty = isEmpty();

        if (!valueNotEmpty) {
            return ;
        }

        var mid = valueNotEmpty.mid;
        var mids = valueNotEmpty.mids;
        var identifyDiagList = valueNotEmpty.identifyDiagList;

        loadingService.show();
        qiniu.get({type: 1}).$promise.then(function (data) {
            var token = data.uptoken;
            console.log(data);
            formData.append('token', token);
            formData.append('file', $scope.musicFile);
            return $.ajax({
                url: qiniuSoundSourceUploadUrl,
                type: 'POST',
                contentType: false,
                processData: false,
                data: formData
            });
        }).then(function (data) {
            var url = '';
            /*心音*/
            // console.log(mid);
            // if (mid == 1) {
            url = getQiniuHeartUrl + data.key;

            // } else if (mid == 2) {
            //     url = qiniuLung + data.key;
            // }

            if ($scope.editMode) {
                url = $soundSourceAudio[0].src;
            }
            const regExp = /font-size:\s*\w+.?\w+;/;
            var content = $scope.setSSO.analysisDiag.replace(regExp, 'font-size:15px;');
            content = encodeURIComponent(content);
            transferObj = {
                audioPath: url,
                name: $scope.setSSO.soundName,
                aids: mids,
                result: $scope.setSSO.diagResult,
                content: content,
                options: identifyDiagList,
                isValid: isValid ? 0 : 1,
                second: parseInt($soundSourceAudio[0].duration),
                size: $scope.soundSize
            };
            if ($scope.editMode) {
                var editData = angular.extend(transferObj, {
                    id: $stateParams.editId
                });
                msoundSource
                    .editSoundSource(editData)
                    .$promise
                    .then(function (data) {
                        console.log(data);
                        loadingService.hide();
                        promptMessage({
                            title: '成功',
                            confirmCallback: callback
                        });
                    },function (err) {
                        console.log(err);
                        if (err.data && err.data.message == '音源名称已存在,音源名称不能重复') {
                            promptMessage({
                                title: err.data.message
                            });
                        } else {
                            promptMessage({
                                title: '失败'
                            });
                        }
                        loadingService.hide();
                    });
            } else {
                msoundSource
                    .addSoundSource(transferObj)
                    .$promise
                    .then(function (data) {
                        console.log(data);
                        loadingService.hide();
                        promptMessage({
                            title: '成功',
                            confirmCallback: callback
                        });
                    }, function (err) {
                        console.log(err);
                        if (err.data && err.data.message == '音源名称已存在,音源名称不能重复') {
                            promptMessage({
                                title: err.data.message
                            });
                        } else {
                            promptMessage({
                                title: '失败'
                            });
                        }
                        loadingService.hide();
                    });
            }
        });
    }

    $scope.previewData = {};

    $scope.previewClick = function () {

        var src = './img/heart_sound.jpg';
        var $option = $('[value='+ $scope.selectedDiagPoint[0].id +']');
        var label = $option.parent('optgroup')[0].label;
        console.log(label);
        if (label != '心音') {
            src = './img/lung_sound.jpg';
        }
        $scope.previewHtml =
            '' +
            '<div class="diag-process">' +
            '<img class="diag-demo-img" src=\"'+ src +'\"/>'+
            '<div class="diag-title">诊断解析</div>' +
            '<div class="diag-body">'+ $scope.setSSO.analysisDiag +'</div>',
        '</div>'
        + '';

        $scope.previewData.title = '音源详情';
        $scope.previewData.hasNav = true;
        $scope.previewData.name =  $scope.setSSO.soundName || '只是站位';
        var duration =$soundSourceAudio[0].duration;
        var minute = parseInt(duration / 60) || 0;
        var second = parseInt(duration % 60) || 0;
        var durationStr = '00:00/' + (minute < 1 ? '00' : minute < 10 ? '0' + minute : minute) + ':' + (second < 10 ? '0' + second : second);
        $scope.previewData.duration = durationStr;

        $('#soundSourcePreviewModal').modal('show');
    };

    /*保存*/
    $scope.soundSave = function () {
        saveData(false);
    };

    $scope.soundEditSave = function () {
        saveData(false);
    };

    $scope.saveEditSoundAndGo = function () {
        saveData(false, function () {
           console.log('goon')
        });
    };

    $scope.soundSaveThenGoOn = function () {
        saveData(false, clearSoundSourceModalData);
    };

    function clearSoundSourceModalData() {
        $scope.setSSO.soundName = '';
        $scope.setSSO.diagResult = '';
        $scope.setSSO.analysisDiag = '';
        $scope.setSSO.identifyDiag = [
            {
                id: Date.now()
            }
        ];
    }

    $scope.publishSoundSource = function () {
        /*发布*/
            saveData(true);
    };

    $scope.soundCancel = function () {

        $scope.clearSoundMusicQueue();


        $state.go('main.sound.table');
    }

    if(!isLogin())
    {
        $state.go('login');
    }
}]);
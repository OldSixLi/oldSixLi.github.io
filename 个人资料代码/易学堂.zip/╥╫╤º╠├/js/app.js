/**
 * Created by Axiny on 2015/7/28.
 */
'use strict';//严格模式
angular.module('routerApp',[
    'ui.router',
    'summernote',
    'angularFileUpload',
    'oc.lazyLoad',
    'ngResource',
    'ngSanitize'
])
.config([
        '$stateProvider',
        '$urlRouterProvider',
        '$compileProvider',
        function($statProvider,$urlRouterProvider,$compileProvider){
            $compileProvider.aHrefSanitizationWhitelist(/^\s*(https?|ftp|mailto|javascript):/);
            //更改默认安全协议
            $urlRouterProvider.otherwise('/login');
            //路由默认跳转
            /*路由部分
             $statProvider
                 .state('',{
                 url:'浏览器内路径'
                 templateUrl:'实际页面路径'
                 controller:'控制器'
                 })*/


            $statProvider
                .state('login',{
                    url:'/login',
                    templateUrl:'view/login.html',
                    controller:'loginCtrl'
                })
                .state('main',{
                    url:'/main',
                    templateUrl:'view/main.html',
                    controller:'mainCtrl'
                })
                .state('main.home',{
                    url:'/home',
                    templateUrl:'view/home.html',
                    controller:'homeCtrl'
                })
                .state('main.countAddUser',{
                    url:'/countAddUser',
                    templateUrl:'view/count_addUser.html',
                    controller:"countAddUserCtrl"
                })
                .state('main.countTotalUser',{
                    url:'/countTotalUser',
                    templateUrl:'view/count_totalUser.html',
                    controller:"countTotalUserCtrl"
                })
                .state('main.countSilentUser',{
                    url:'/countSilentUser',
                    templateUrl:'view/count_silentUser.html',
                    controller:"countSilentUserCtrl"
                })
                .state('main.countStartUp',{
                    url:'/countStartUp',
                    templateUrl:'view/count_startUp.html',
                    controller:"countStartUpCtrl"
                })
                .state('main.countWeekUser',{
                    url:'/countWeekUser',
                    templateUrl:'view/count_weekUser.html',
                    controller:"countWeekUserCtrl"
                })
                .state('main.countActiveUser',{
                    url:'/countActiveUser',
                    templateUrl:'view/count_activeUser.html',
                    controller:"countActiveUserCtrl"
                })
                .state('main.countRetainedUser',{
                    url:'/countRetainedUser',
                    templateUrl:'view/count_retainedUser.html',
                    controller:"countRetainedUserCtrl"
                })
                .state('main.countNextDayKeepUser',{
                    url:'/countNextDayKeepUser',
                    templateUrl:'view/count_nextDayKeepUser.html',
                    controller:"countNextDayKeepUserCtrl"
                })
                .state('main.countNowAddUser',{
                    url:'/countNowAddUser',
                    templateUrl:'view/count_nowAddUser.html',
                    controller:"countNowAddUserCtrl"
                })
                .state('main.userSetting',{
                    url:'/userSetting',
                    templateUrl:"view/userSetting.html",
                    controller:"userSettingCtrl",
                    resolve: {
                        pageInfo: [
                            'userSettingService',
                            '$q',
                            function (userSettingService, $q) {
                                var getpage =
                                {
                                    page:0,
                                    pageNum:10,
                                    key:"",
                                    role:0,
                                    sex:0,
                                    regstartDate:"",
                                    regendDate:""
                                };
                                var defer = $q.defer();
                                userSettingService.getUserData(getpage).then(function (res) {
                                    defer.resolve(res);
                                });
                                return defer.promise;
                            }
                        ]
                    }
                })
                .state('main.classSetting',{
                    url:"/classSetting",
                    templateUrl:"view/classSetting.html",
                    controller:"classSettingCtrl",
                    resolve: {
                        classPageInfo: [
                            'classSettingService',
                            '$q',
                            function (classSettingService, $q) {
                                var getGroupPage =
                                {
                                    page:0,
                                    pageNum:10,
                                    key:"",
                                    state:0
                                };
                                var defer = $q.defer();
                                classSettingService.getClassData(getGroupPage).then(function (res) {
                                    defer.resolve(res);
                                });
                                return defer.promise;
                            }
                        ],
                        pageInfo: [
                            'userSettingService',
                            '$q',
                            function (userSettingService, $q) {
                                var getpage =
                                {
                                    page:0,
                                    pageNum:10,
                                    key:"",
                                    role:0,
                                    sex:0,
                                    regstartDate:"",
                                    regendDate:""
                                };
                                var defer = $q.defer();
                                userSettingService.getUserData(getpage).then(function (res) {
                                    defer.resolve(res);
                                });
                                return defer.promise;
                            }
                        ]
                    }
                })
                .state('main.message',{
                    url:"/message",
                    templateUrl:"view/message.html",
                    controller:"messageCtrl",
                    resolve: {
                        messagePageInfo: [
                            'messageService',
                            '$q',
                            function (messageService, $q) {
                                var getMesPage =
                                {
                                    page:0,
                                    pageNum:10,
                                    key:"",
                                    state:0,
                                    obj:0,
                                    startDate:"",
                                    endDate:""
                                };
                                var defer = $q.defer();
                                messageService.getMessageList(getMesPage).then(function (res) {
                                    defer.resolve(res);
                                });
                                return defer.promise;
                            }
                        ]
                    }
                })
                .state('main.systemSetting',{
                    url:"/systemSetting",
                    templateUrl:"view/systemSetting.html",
                    controller:"systemSettingCtrl"
                });
        }
    ]);
    //登录时保存用户名和密码至cookie
    function save_key(name, value) {
        addCookie(name, encodeURI(value));
    }

    //cookie时效为半小时
    var expiresHours = 1800;	////单位s，在一个页面停留超过半个小时，则需要重新登录
    //添加用户名和密码至cookie
    function addCookie(c_name,value)
    {
        var exdate=new Date();
        exdate.setDate(exdate.getTime() + expiresHours * 1000);
        document.cookie = c_name+ "=" +escape(value)+";expires="+exdate.toGMTString();
    }

    //删除cookie
    function deleteCookie(name) {
        var exp = new Date();
        exp.setTime(exp.getTime() - 1);
        var cval=getCookie(name);
        if(cval!=null){
            document.cookie= name + "="+cval+";expires="+exp.toGMTString();
    }
    }

    ////解析cookie里对应项
    //function getQueryString(name) {
    //    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    //    var r = window.location.search.substr(1).match(reg);
    //    if (r != null) return unescape(r[2]); return null;
    //}
        //读取cookies
        function getCookie(name)
        {
            var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");

            if(arr=document.cookie.match(reg)){

                return unescape(arr[2]);
        } else{
                return null;
        }
        }
        function isLogin()
        {
            if(getCookie("userName")!= null&&getCookie("password")!= null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
/**
 * Created by Axiny on 2016/8/30.
 */

/**
 * 数据服务接口路径
 * @type {string}
 */
// var serviceURL = "https://101.201.78.224:443/api";
 var serviceURL = "https://www.medschoolcloud.com/api";//公司内侧使用
//var serviceURL = 'http://101.201.78.224:8081/estudyserver/api';//客户使用
/**
 * 获取请求头信息
 * @type {{contentType: string, sign: Function, timestamp: Function, accessKey: Function}}
 *
 * sign = MD5(HTTP_METHOD + timestamp + queryParameters + postParameters + securityKey):
 * sign 具体要求在 swagger 的 readme 中查看
 */
var HEADERS = {
    "contentType":"application/x-www-form-urlencoded",
    "sign": function (method,data){
        return hex_md5(method + Math.round(new Date().getTime()/1000).toString() + data + localStorage.securityKey);
    },
    "timestamp":function (){
        return Math.round(new Date().getTime()/1000).toString();
    },
    "accessKey": function(){
        return localStorage.accessKey;
    }
};

/**
 * 浏览器关闭/刷新事件 清空身份码
 */
window.onunload = function() {
    localStorage.securityKey = "";
};
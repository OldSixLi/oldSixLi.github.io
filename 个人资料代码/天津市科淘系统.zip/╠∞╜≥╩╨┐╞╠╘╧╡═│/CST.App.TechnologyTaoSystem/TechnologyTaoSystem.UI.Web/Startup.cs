﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(TechnologyTaoSystem.UI.Web.Startup))]
namespace TechnologyTaoSystem.UI.Web
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}

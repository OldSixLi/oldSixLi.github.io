/*
 * @Author:马少博 (ma.shaobo@qq.com)
 * @Date: 2018年3月20日17:19:11
 * @Last Modified by: 马少博
 * @Last Modified time:2018年3月20日17:19:17
 * 学习过程中的练习
 */
/* jshint esversion: 6 */
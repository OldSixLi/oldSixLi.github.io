/* @flow */

import Vue from './runtime/index'
/*Github:https://github.com/answershuto*/
export default Vue

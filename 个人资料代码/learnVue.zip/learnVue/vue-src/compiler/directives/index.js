/* @flow */

import bind from './bind'
import { noop } from 'shared/util'
/*Github:https://github.com/answershuto*/
export default {
  bind,
  cloak: noop
}
